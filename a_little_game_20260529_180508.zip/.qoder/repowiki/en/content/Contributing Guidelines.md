# Contributing Guidelines

<cite>
**Referenced Files in This Document**
- [backend/app/main.py](file://backend/app/main.py)
- [backend/app/router.py](file://backend/app/router.py)
- [backend/app/models.py](file://backend/app/models.py)
- [backend/app/talents.py](file://backend/app/talents.py)
- [backend/app/game_engine.py](file://backend/app/game_engine.py)
- [backend/app/endings.py](file://backend/app/endings.py)
- [backend/app/events/all_events.json](file://backend/app/events/all_events.json)
- [frontend/src/App.tsx](file://frontend/src/App.tsx)
- [frontend/src/main.tsx](file://frontend/src/main.tsx)
- [frontend/src/utils/api.ts](file://frontend/src/utils/api.ts)
- [frontend/src/pages/GameScreen.tsx](file://frontend/src/pages/GameScreen.tsx)
- [frontend/src/utils/types.ts](file://frontend/src/utils/types.ts)
- [frontend/package.json](file://frontend/package.json)
- [docker-compose.yml](file://docker-compose.yml)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Development Workflow](#development-workflow)
8. [Code Standards](#code-standards)
9. [Pull Request and Review Process](#pull-request-and-review-process)
10. [Issue Reporting Procedures](#issue-reporting-procedures)
11. [Extending the JSON-Based Event System](#extending-the-json-based-event-system)
12. [Integrating New Talents](#integrating-new-talents)
13. [Developing New UI Components](#developing-new-ui-components)
14. [Testing Strategy](#testing-strategy)
15. [Quality Assurance Measures](#quality-assurance-measures)
16. [Maintaining Backward Compatibility](#maintaining-backward-compatibility)
17. [Performance Optimization Standards](#performance-optimization-standards)
18. [Documentation Requirements](#documentation-requirements)
19. [Common Contribution Scenarios](#common-contribution-scenarios)
20. [Modular Architecture Design Principles](#modular-architecture-design-principles)
21. [Troubleshooting Guide](#troubleshooting-guide)
22. [Conclusion](#conclusion)

## Introduction
This document provides comprehensive contributing guidelines for A Little Game, a cultivation-themed life simulator built with a Python FastAPI backend and a React TypeScript frontend. It covers development workflow, code standards, pull request processes, issue reporting, extending the JSON-based event system, integrating new talents, developing UI components, testing, code review, quality assurance, backward compatibility, performance optimization, and documentation requirements. It also outlines the modular architecture and extension points for future enhancements.

## Project Structure
The project follows a clear separation of concerns:
- Backend: FastAPI application exposing game APIs, game engine logic, models, and JSON-based events.
- Frontend: React application with TypeScript, Vite build tooling, Tailwind CSS styling, and a simple routing model via a top-level App component.
- Orchestration: Docker Compose for local development and deployment.

```mermaid
graph TB
subgraph "Backend"
MAIN["backend/app/main.py"]
ROUTER["backend/app/router.py"]
MODELS["backend/app/models.py"]
TALENTS["backend/app/talents.py"]
ENGINE["backend/app/game_engine.py"]
ENDINGS["backend/app/endings.py"]
EVENTS["backend/app/events/all_events.json"]
end
subgraph "Frontend"
APP["frontend/src/App.tsx"]
MAIN_TS["frontend/src/main.tsx"]
API["frontend/src/utils/api.ts"]
TYPES["frontend/src/utils/types.ts"]
GAMESCREEN["frontend/src/pages/GameScreen.tsx"]
end
subgraph "DevOps"
DOCKER["docker-compose.yml"]
end
APP --> API
API --> ROUTER
ROUTER --> ENGINE
ENGINE --> MODELS
ENGINE --> TALENTS
ENGINE --> ENDINGS
ENGINE --> EVENTS
DOCKER --> MAIN
DOCKER --> APP
```

**Diagram sources**
- [backend/app/main.py:1-26](file://backend/app/main.py#L1-L26)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/models.py:1-171](file://backend/app/models.py#L1-L171)
- [backend/app/talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [backend/app/game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [backend/app/endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [backend/app/events/all_events.json:1-800](file://backend/app/events/all_events.json#L1-L800)
- [frontend/src/App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)
- [frontend/src/main.tsx:1-11](file://frontend/src/main.tsx#L1-L11)
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [frontend/src/utils/types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)
- [frontend/src/pages/GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)

**Section sources**
- [backend/app/main.py:1-26](file://backend/app/main.py#L1-L26)
- [frontend/src/App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)

## Core Components
- Backend entrypoint and CORS configuration.
- API routes for talents, starting a game, advancing a year, and retrieving summaries.
- Data models for realms, attributes, talents, events, game state, and responses.
- Talent definitions and selection logic.
- Game engine orchestrating events, cultivation progression, death checks, breakthroughs, and summaries.
- Endings and scoring logic.
- JSON-based event catalog organized by categories and types.
- Frontend App lifecycle managing game phases and navigation.
- Frontend API utilities for backend communication.
- Frontend GameScreen rendering state, progress bars, and controls.
- Frontend types shared across components and API.

**Section sources**
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/models.py:1-171](file://backend/app/models.py#L1-L171)
- [backend/app/talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [backend/app/game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [backend/app/endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [backend/app/events/all_events.json:1-800](file://backend/app/events/all_events.json#L1-L800)
- [frontend/src/App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [frontend/src/pages/GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [frontend/src/utils/types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)

## Architecture Overview
The system is a client-server architecture:
- The frontend is a SPA that communicates with the backend via REST endpoints.
- The backend exposes typed endpoints for game lifecycle operations and serves as the authoritative source of game logic and data.
- Events are loaded from JSON files at runtime, enabling easy extension without code changes.
- Docker Compose runs both services concurrently.

```mermaid
sequenceDiagram
participant Browser as "Browser"
participant Frontend as "React App"
participant API as "API Router"
participant Engine as "Game Engine"
participant Store as "In-Memory State"
Browser->>Frontend : "User clicks Start"
Frontend->>API : "POST /api/game/start"
API->>Engine : "create_game(attributes, talents)"
Engine->>Store : "Persist GameState"
Engine-->>API : "GameState"
API-->>Frontend : "Game state payload"
Browser->>Frontend : "User clicks Next Year"
Frontend->>API : "POST /api/game/next-year"
API->>Engine : "advance_year(game_id)"
Engine->>Engine : "check_death()"
Engine->>Engine : "select_events()"
Engine->>Engine : "apply_event_effects()"
Engine->>Engine : "check_realm_breakthrough()"
Engine->>Store : "Update GameState"
Engine-->>API : "NextYearResponse"
API-->>Frontend : "Events + state"
```

**Diagram sources**
- [backend/app/router.py:18-68](file://backend/app/router.py#L18-L68)
- [backend/app/game_engine.py:311-393](file://backend/app/game_engine.py#L311-L393)
- [frontend/src/utils/api.ts:11-47](file://frontend/src/utils/api.ts#L11-L47)

**Section sources**
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)

## Detailed Component Analysis

### Backend API Layer
- Routes expose endpoints for talents, starting games, advancing years, and fetching summaries.
- Validation ensures attribute totals and talent counts meet constraints.
- Responses are strongly typed via Pydantic models.

```mermaid
flowchart TD
Start(["POST /api/game/start"]) --> Validate["Validate attributes and talents"]
Validate --> Valid{"Valid?"}
Valid --> |No| Error["HTTP 400 with detail"]
Valid --> |Yes| Create["create_game()"]
Create --> ReturnStart["Return game state"]
```

**Diagram sources**
- [backend/app/router.py:18-44](file://backend/app/router.py#L18-L44)

**Section sources**
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)

### Game Engine Logic
- Loads events from JSON at startup.
- Manages in-memory game states keyed by game_id.
- Implements event condition checks, effect application, death detection, cultivation gain, breakthrough mechanics, and end-of-life summary generation.

```mermaid
flowchart TD
Entry(["advance_year(game_id)"]) --> Lookup["Lookup GameState"]
Lookup --> Over{"Over?"}
Over --> |Yes| Raise["Raise ValueError"]
Over --> |No| AgeInc["age += 1"]
AgeInc --> DeathCheck["check_death()"]
DeathCheck --> Dead{"Dead?"}
Dead --> |Yes| LogDeath["Append death event"] --> ReturnDead["Return NextYearResponse(is_dead=true)"]
Dead --> |No| Gain["process_cultivation_gain()"]
Gain --> Select["select_events(count)"]
Select --> Apply["apply_event_effects()"]
Apply --> Breakthrough["check_realm_breakthrough()"]
Breakthrough --> Ascended{"Ascended?"}
Ascended --> |Yes| ReturnAsc["Return is_ascended=true"]
Ascended --> |No| ReturnAlive["Return NextYearResponse"]
```

**Diagram sources**
- [backend/app/game_engine.py:311-393](file://backend/app/game_engine.py#L311-L393)

**Section sources**
- [backend/app/game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)

### Talent System
- Centralized talent definitions with rarity tiers and tags.
- Random selection logic weights by rarity and ensures at least one rare+ talent in the pool.

```mermaid
classDiagram
class Talent {
+string id
+string name
+string description
+int rarity
+dict effects
+string[] tags
}
class TalentPool {
+get_random_talents(count) dict[]
}
TalentPool --> Talent : "selects"
```

**Diagram sources**
- [backend/app/talents.py:51-85](file://backend/app/talents.py#L51-L85)

**Section sources**
- [backend/app/talents.py:1-85](file://backend/app/talents.py#L1-L85)

### Frontend Application Flow
- App manages four phases: start, creation, playing, summary.
- Uses a centralized API utility to communicate with backend endpoints.
- GameScreen renders realm, cultivation, attributes, and event logs with responsive controls.

```mermaid
sequenceDiagram
participant App as "App"
participant Creation as "CharacterCreation"
participant API as "api.ts"
participant Screen as "GameScreen"
participant Summary as "SummaryScreen"
App->>Creation : "Render phase='creation'"
Creation->>API : "startGame(attributes, talents)"
API-->>Creation : "game_id, state"
Creation-->>App : "Set phase='playing', gameId"
App->>Screen : "Render with gameId"
Screen->>API : "nextYear(gameId)"
API-->>Screen : "NextYearResponse"
Screen-->>App : "onGameEnd(gameId)"
App->>Summary : "Render with gameId"
```

**Diagram sources**
- [frontend/src/App.tsx:24-68](file://frontend/src/App.tsx#L24-L68)
- [frontend/src/utils/api.ts:11-56](file://frontend/src/utils/api.ts#L11-L56)
- [frontend/src/pages/GameScreen.tsx:40-74](file://frontend/src/pages/GameScreen.tsx#L40-L74)

**Section sources**
- [frontend/src/App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [frontend/src/pages/GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)

## Dependency Analysis
- Backend depends on Pydantic for data modeling, JSON for event catalogs, and Python standard libraries for randomness and UUIDs.
- Frontend depends on React, TypeScript, Tailwind CSS, and Vite for building and linting.
- Docker Compose ties frontend and backend together, exposing ports and defining service dependencies.

```mermaid
graph LR
FE["frontend/src/utils/api.ts"] --> BE["backend/app/router.py"]
BE --> GE["backend/app/game_engine.py"]
GE --> EV["backend/app/events/all_events.json"]
GE --> TM["backend/app/talents.py"]
GE --> ED["backend/app/endings.py"]
DC["docker-compose.yml"] --> FE
DC --> BE
```

**Diagram sources**
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [backend/app/events/all_events.json:1-800](file://backend/app/events/all_events.json#L1-L800)
- [backend/app/talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [backend/app/endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)

**Section sources**
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)

## Development Workflow
- Fork and branch from the default branch.
- Install dependencies:
  - Backend: see requirements in backend directory.
  - Frontend: install dependencies via package manager.
- Run locally:
  - Use Docker Compose to start both services.
  - Frontend runs on port 80; backend runs on port 8000.
- Make changes following code standards and testing requirements.
- Open a Pull Request with a clear description, test coverage, and impact assessment.

**Section sources**
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)
- [frontend/package.json:1-33](file://frontend/package.json#L1-L33)

## Code Standards
- Backend (Python/FastAPI):
  - Use type hints and Pydantic models for data contracts.
  - Keep functions pure where possible; isolate side effects (state updates).
  - Validate inputs early with explicit HTTP exceptions.
  - Use enums for finite sets (e.g., Realm).
- Frontend (TypeScript/React):
  - Define interfaces for props and responses.
  - Use functional components with hooks.
  - Keep UI logic minimal; delegate heavy logic to utilities and services.
  - Use Tailwind utilities for styling; avoid inline styles.
- JSON Event Catalog:
  - Maintain consistent keys: id, text, category, conditions, weight, effects, tags, event_type.
  - Group related events into category-specific files under events/.
  - Keep ids unique and descriptive.

**Section sources**
- [backend/app/models.py:1-171](file://backend/app/models.py#L1-L171)
- [backend/app/router.py:18-44](file://backend/app/router.py#L18-L44)
- [frontend/src/utils/types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)

## Pull Request and Review Process
- Branch naming: feature/short-description, fix/short-description, chore/short-description.
- PR checklist:
  - Describe changes and rationale.
  - Link related issues.
  - Include tests and verification steps.
  - Document breaking changes and migration notes.
- Review criteria:
  - Correctness, maintainability, performance, security, and adherence to standards.
  - Ensure new events and talents are balanced and consistent with existing themes.
- Merge requires at least one approval.

## Issue Reporting Procedures
- Use GitHub Issues with templates:
  - Bug report: steps to reproduce, expected vs actual, logs/screenshots.
  - Feature request: motivation, proposed solution, trade-offs.
  - Question: context and desired clarification.
- Label issues appropriately (bug, enhancement, question, documentation).

## Extending the JSON-Based Event System
To add new events:
1. Choose or create a category file under backend/app/events/ (e.g., common.json, calamity.json, etc.).
2. Add entries with:
   - id: unique identifier
   - text: narrative description
   - category: one of the supported categories
   - conditions: min/max age, realm, cultivation, required/excluded talents/tags, min_attribute
   - weight: selection weight
   - effects: numeric adjustments to attributes or cultivation
   - tags: metadata for filtering
   - event_type: normal, important, danger, fortune
3. Optionally add a dedicated category file if none exists yet.
4. Verify by starting a new game and progressing through years; confirm the event appears under intended conditions.

```mermaid
flowchart TD
AddEvent["Add event to JSON"] --> Conditions["Define conditions"]
Conditions --> Effects["Define effects"]
Effects --> Weight["Set weight"]
Weight --> Test["Test in-game"]
Test --> Balance{"Balanced?"}
Balance --> |No| Iterate["Iterate on conditions/effects/weight"]
Balance --> |Yes| Commit["Commit and open PR"]
```

**Diagram sources**
- [backend/app/game_engine.py:80-116](file://backend/app/game_engine.py#L80-L116)
- [backend/app/game_engine.py:119-153](file://backend/app/game_engine.py#L119-L153)
- [backend/app/events/all_events.json:1-800](file://backend/app/events/all_events.json#L1-L800)

**Section sources**
- [backend/app/game_engine.py:80-153](file://backend/app/game_engine.py#L80-L153)
- [backend/app/events/all_events.json:1-800](file://backend/app/events/all_events.json#L1-L800)

## Integrating New Talents
To add a new talent:
1. Append a new talent object to the talent pool with:
   - id: unique lowercase identifier
   - name: localized name
   - description: flavor text
   - rarity: 1–4 tier
   - effects: attribute adjustments
   - tags: categorization for filtering and interactions
2. Ensure the pool maintains variety by keeping weighted distribution intact.
3. Test that the talent applies correctly during character creation and affects gameplay.

```mermaid
classDiagram
class TalentDefinition {
+string id
+string name
+string description
+int rarity
+dict effects
+string[] tags
}
class TalentSelection {
+get_random_talents(count) dict[]
}
TalentSelection --> TalentDefinition : "selects from"
```

**Diagram sources**
- [backend/app/talents.py:3-48](file://backend/app/talents.py#L3-L48)
- [backend/app/talents.py:51-85](file://backend/app/talents.py#L51-L85)

**Section sources**
- [backend/app/talents.py:1-85](file://backend/app/talents.py#L1-L85)

## Developing New UI Components
Follow existing patterns:
- Define TypeScript interfaces for props and responses in frontend/src/utils/types.ts.
- Create a new page component under frontend/src/pages/ if it represents a distinct phase.
- Use the API utility in frontend/src/utils/api.ts to communicate with backend endpoints.
- Reuse styling constants (REALM_NAMES, REALM_COLORS, ATTR_NAMES) for consistency.
- Keep components declarative; manage state in App or page-level components.
- Add Tailwind classes for layout and responsiveness.

```mermaid
graph LR
Types["frontend/src/utils/types.ts"] --> Page["New Page Component"]
API["frontend/src/utils/api.ts"] --> Page
Page --> App["frontend/src/App.tsx"]
```

**Diagram sources**
- [frontend/src/utils/types.ts:65-113](file://frontend/src/utils/types.ts#L65-L113)
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [frontend/src/App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)

**Section sources**
- [frontend/src/utils/types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [frontend/src/App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)

## Testing Strategy
- Backend:
  - Unit tests for event condition checks, effect application, death checks, breakthrough logic, and talent selection.
  - Integration tests for API endpoints validating request/response shapes and error handling.
  - Load tests to verify event selection and advancement performance under high throughput.
- Frontend:
  - Component tests for GameScreen and other interactive screens.
  - E2E tests for the full flow: start game, advance year(s), handle end-of-life, and summary.
  - Linting and type checks via ESLint and TypeScript compiler.
- CI/CD:
  - Run linters and unit tests on pull requests.
  - Build and test Docker images for both frontend and backend.

**Section sources**
- [frontend/package.json:6-10](file://frontend/package.json#L6-L10)

## Quality Assurance Measures
- Code reviews: Ensure all PRs are reviewed and approved.
- Static analysis: Enforce linting and TypeScript strict mode.
- Security: Validate inputs, sanitize outputs, and avoid exposing secrets.
- Accessibility: Use semantic HTML and ARIA labels where applicable.
- Internationalization: Keep localized strings in JSON or components; avoid hardcoded strings in logic.

## Maintaining Backward Compatibility
- API:
  - Do not remove or rename fields in Pydantic models without deprecation notices.
  - Add new optional fields; avoid changing defaults that affect gameplay.
- Events:
  - Do not change ids of existing events; introduce new ids for variants.
  - Keep conditions and effects compatible with existing logic.
- Frontend:
  - Do not remove or rename props; add new optional props.
  - Maintain consistent response shapes for API utilities.

## Performance Optimization Standards
- Backend:
  - Prefer in-memory storage for game states; avoid disk I/O on hot paths.
  - Optimize event selection by precomputing weights and avoiding repeated scans.
  - Use efficient data structures (lists/dicts) for frequent lookups.
- Frontend:
  - Memoize expensive computations; avoid unnecessary re-renders.
  - Virtualize long lists (event logs) when scaling.
  - Minimize DOM updates; batch state changes.

## Documentation Requirements
- Update this guide when introducing new extension points or changing workflows.
- Add inline comments for complex logic in backend game engine.
- Document new API endpoints and their request/response schemas.
- Provide examples for contributors adding events, talents, and UI components.

## Common Contribution Scenarios
- Adding new cultivation realms:
  - Extend the Realm enum and related mappings in models.py.
  - Update thresholds and max ages in the game engine.
  - Add localized names and colors in frontend types.
  - Add breakthrough and ascension messages in the engine.
- Creating custom event types:
  - Define conditions and effects in JSON.
  - Adjust weighting to balance frequency and impact.
  - Test across different ages, realms, and attribute combinations.
- Implementing new UI features:
  - Define new interfaces in types.ts.
  - Create a page component following GameScreen pattern.
  - Wire it into App phase management and API utilities.

**Section sources**
- [backend/app/models.py:7-45](file://backend/app/models.py#L7-L45)
- [backend/app/game_engine.py:35-45](file://backend/app/game_engine.py#L35-L45)
- [frontend/src/utils/types.ts:65-98](file://frontend/src/utils/types.ts#L65-L98)

## Modular Architecture Design Principles
- Clear separation between API, engine, models, and UI.
- Event-driven design: events are data-driven and decoupled from logic.
- Extensible talent system: new talents can be added without code changes.
- JSON-based configuration: easy to iterate on content without redeploying code.
- Minimal coupling: components depend on interfaces and utilities, not on each other’s internals.

## Troubleshooting Guide
- Backend errors:
  - Missing game_id or invalid game state: verify API calls and game_id propagation.
  - HTTP 400 on start: check attribute totals and talent count constraints.
  - HTTP 404 on next-year/summary: ensure game is still active.
- Frontend errors:
  - API failures: inspect network tab and error messages returned by backend.
  - UI not updating: verify state updates and re-render triggers.
- Local development:
  - Ensure Docker Compose is running both services and ports are free.
  - Confirm CORS settings allow frontend-origin access.

**Section sources**
- [backend/app/router.py:18-68](file://backend/app/router.py#L18-L68)
- [frontend/src/utils/api.ts:24-56](file://frontend/src/utils/api.ts#L24-L56)

## Conclusion
By following these guidelines, contributors can safely extend A Little Game’s backend logic, event system, talent pool, and frontend UI while maintaining performance, reliability, and a consistent developer experience. Adhering to the modular architecture and established workflows ensures smooth integration of new features and cultivates a sustainable ecosystem for future enhancements.