# Configuration and Deployment

<cite>
**Referenced Files in This Document**
- [docker-compose.yml](file://docker-compose.yml)
- [Dockerfile.backend](file://Dockerfile.backend)
- [Dockerfile.frontend](file://Dockerfile.frontend)
- [backend/requirements.txt](file://backend/requirements.txt)
- [frontend/package.json](file://frontend/package.json)
- [frontend/vite.config.ts](file://frontend/vite.config.ts)
- [frontend/nginx.conf](file://frontend/nginx.conf)
- [frontend/src/utils/api.ts](file://frontend/src/utils/api.ts)
- [backend/app/main.py](file://backend/app/main.py)
- [backend/app/router.py](file://backend/app/router.py)
- [backend/app/models.py](file://backend/app/models.py)
- [backend/app/game_engine.py](file://backend/app/game_engine.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [CI/CD and Rollback Procedures](#cicd-and-rollback-procedures)
10. [Conclusion](#conclusion)

## Introduction
This document provides a comprehensive guide to configuring and deploying the multi-service Dockerized architecture for the application. It covers Docker Compose orchestration of Nginx (frontend), backend (FastAPI), and frontend (React/Vite) services, including port mappings, service dependencies, and runtime behavior. It also documents the Dockerfile configurations for backend and frontend, build processes, image optimization strategies, environment variable configuration, and development versus production differences. Finally, it outlines deployment topology options, scaling considerations, monitoring approaches, CI/CD integration, automated testing setup, rollback procedures, troubleshooting guidance, performance tuning recommendations, and production security considerations.

## Project Structure
The repository is organized into three primary areas:
- Backend: Python FastAPI application with routing and game engine logic.
- Frontend: React application built via Vite with TypeScript, served by Nginx in production.
- Containerization: Top-level Docker Compose orchestration and Dockerfiles for backend and frontend.

```mermaid
graph TB
subgraph "Compose Services"
FE["frontend (Nginx)"]
BE["backend (FastAPI uvicorn)"]
end
subgraph "Backend App"
MAIN["app/main.py"]
ROUTER["app/router.py"]
MODELS["app/models.py"]
ENGINE["app/game_engine.py"]
end
subgraph "Frontend App"
API["src/utils/api.ts"]
VITE["vite.config.ts"]
NGINXCONF["nginx.conf"]
end
FE --> BE
API --> FE
FE --> NGINXCONF
BE --> MAIN
MAIN --> ROUTER
ROUTER --> MODELS
ROUTER --> ENGINE
```

**Diagram sources**
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)
- [Dockerfile.backend:1-8](file://Dockerfile.backend#L1-L8)
- [Dockerfile.frontend:1-13](file://Dockerfile.frontend#L1-L13)
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [frontend/vite.config.ts:1-16](file://frontend/vite.config.ts#L1-L16)
- [frontend/nginx.conf:1-27](file://frontend/nginx.conf#L1-L27)
- [backend/app/main.py:1-26](file://backend/app/main.py#L1-L26)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/models.py:1-171](file://backend/app/models.py#L1-L171)
- [backend/app/game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)

**Section sources**
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)
- [Dockerfile.backend:1-8](file://Dockerfile.backend#L1-L8)
- [Dockerfile.frontend:1-13](file://Dockerfile.frontend#L1-L13)

## Core Components
- Docker Compose orchestration defines two services:
  - frontend: Nginx-based static site with SPA fallback and API proxy to backend.
  - backend: Python FastAPI application using Uvicorn, exposed on port 8000.
- Environment variables:
  - PYTHONUNBUFFERED=1 is set for the backend container to ensure logs stream properly.
- Ports:
  - frontend: host 80 mapped to container 80.
  - backend: host 8000 mapped to container 8000.
- Dependencies:
  - frontend depends_on backend to ensure the API is reachable during startup.

**Section sources**
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)

## Architecture Overview
The system follows a classic frontend-backend pattern with Nginx serving the SPA and proxying API requests to the backend. The backend exposes a REST-like interface under /api/game.

```mermaid
graph TB
Client["Browser"]
Nginx["Nginx (frontend)"]
Backend["FastAPI (backend)"]
Client --> Nginx
Nginx --> |SPA fallback| Nginx
Nginx --> |/api/* proxy| Backend
Backend --> |"GET /"| Backend
Backend --> |"/api/game/*"| Backend
```

**Diagram sources**
- [frontend/nginx.conf:1-27](file://frontend/nginx.conf#L1-L27)
- [backend/app/main.py:1-26](file://backend/app/main.py#L1-L26)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)

## Detailed Component Analysis

### Docker Compose Orchestration
- Service: frontend
  - Build context: ./frontend
  - Dockerfile: ../Dockerfile.frontend
  - Ports: 80:80
  - Depends on: backend
  - Restart policy: unless-stopped
- Service: backend
  - Build context: .
  - Dockerfile: Dockerfile.backend
  - Ports: 8000:8000
  - Restart policy: unless-stopped
  - Environment: PYTHONUNBUFFERED=1

Operational implications:
- The frontend container waits for the backend to become reachable before serving the SPA.
- Port exposure enables local development and production deployments.
- Restart policy ensures services remain available unless manually stopped.

**Section sources**
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)

### Backend Service (FastAPI + Uvicorn)
- Image base: python:3.11-slim
- Working directory: /app
- Dependencies: installed from backend/requirements.txt
- Application entrypoint: uvicorn serving app.main:app on 0.0.0.0:8000
- CORS middleware allows all origins for development convenience.

Key endpoints:
- GET "/": Health/status endpoint returning application metadata.
- GET "/api/game/talents": Returns a randomized talent pool for character creation.
- POST "/api/game/start": Starts a new game with validated attributes and talents.
- POST "/api/game/next-year": Advances the game by one year.
- GET "/api/game/summary/{game_id}": Retrieves life summary after game completion.

Runtime behavior:
- In-memory game state storage keyed by game_id.
- Real-time event selection and effect application.
- Realm progression and breakthrough mechanics.

**Section sources**
- [Dockerfile.backend:1-8](file://Dockerfile.backend#L1-L8)
- [backend/requirements.txt:1-5](file://backend/requirements.txt#L1-L5)
- [backend/app/main.py:1-26](file://backend/app/main.py#L1-L26)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/models.py:1-171](file://backend/app/models.py#L1-L171)
- [backend/app/game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)

### Frontend Service (React + Vite + Nginx)
- Multi-stage build:
  - Builder stage: node:20-alpine, installs dependencies, builds the app.
  - Runtime stage: nginx:alpine, serves built assets and proxies API.
- Static asset caching and SPA fallback configured in nginx.conf.
- Vite dev server configured with proxy to backend at http://localhost:8000.

API client behavior:
- Uses /api/game base path for all backend calls.
- Handles errors from backend responses and surfaces user-friendly messages.

**Section sources**
- [Dockerfile.frontend:1-13](file://Dockerfile.frontend#L1-L13)
- [frontend/package.json:1-33](file://frontend/package.json#L1-L33)
- [frontend/vite.config.ts:1-16](file://frontend/vite.config.ts#L1-L16)
- [frontend/nginx.conf:1-27](file://frontend/nginx.conf#L1-L27)
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)

### API Workflow Sequence
```mermaid
sequenceDiagram
participant Browser as "Browser"
participant Nginx as "Nginx (frontend)"
participant Backend as "FastAPI (backend)"
Browser->>Nginx : "GET /"
Nginx-->>Browser : "Serve index.html"
Browser->>Nginx : "GET /api/game/talents"
Nginx->>Backend : "Proxy to /api/game/talents"
Backend-->>Nginx : "JSON talents"
Nginx-->>Browser : "200 talents"
Browser->>Nginx : "POST /api/game/start"
Nginx->>Backend : "Proxy to /api/game/start"
Backend-->>Nginx : "Game state"
Nginx-->>Browser : "200 game data"
Browser->>Nginx : "POST /api/game/next-year"
Nginx->>Backend : "Proxy to /api/game/next-year"
Backend-->>Nginx : "Yearly result"
Nginx-->>Browser : "200 result"
Browser->>Nginx : "GET /api/game/summary/ : id"
Nginx->>Backend : "Proxy to /api/game/summary/ : id"
Backend-->>Nginx : "Life summary"
Nginx-->>Browser : "200 summary"
```

**Diagram sources**
- [frontend/nginx.conf:1-27](file://frontend/nginx.conf#L1-L27)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)

## Dependency Analysis
- Frontend-to-backend dependency:
  - Compose ensures the frontend service depends_on backend.
  - Nginx proxy configuration forwards /api/ paths to backend:8000.
- Backend internal dependencies:
  - Router imports models and game engine modules.
  - Game engine loads event JSON files and maintains in-memory state.
- Frontend build-time dependencies:
  - Vite and React toolchain defined in package.json.
  - Proxy target in Vite dev server aligns with backend port.

```mermaid
graph LR
FE["frontend (Nginx)"] --> |proxy /api/*| BE["backend (FastAPI)"]
BE --> MODELS["models.py"]
BE --> ENGINE["game_engine.py"]
FE --> NGINXCONF["nginx.conf"]
FE --> VITECFG["vite.config.ts"]
```

**Diagram sources**
- [docker-compose.yml:8-9](file://docker-compose.yml#L8-L9)
- [frontend/nginx.conf:12-19](file://frontend/nginx.conf#L12-L19)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/models.py:1-171](file://backend/app/models.py#L1-L171)
- [backend/app/game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [frontend/vite.config.ts:7-14](file://frontend/vite.config.ts#L7-L14)

**Section sources**
- [docker-compose.yml:8-9](file://docker-compose.yml#L8-L9)
- [frontend/nginx.conf:12-19](file://frontend/nginx.conf#L12-L19)
- [frontend/vite.config.ts:7-14](file://frontend/vite.config.ts#L7-L14)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)

## Performance Considerations
- Image optimization:
  - slim base images reduce attack surface and build times.
  - Multi-stage frontend build minimizes runtime image size.
- Caching:
  - Nginx caches static assets for extended TTLs.
  - SPA fallback prevents unnecessary backend calls for client-side routes.
- Resource allocation:
  - Scale backend replicas behind a reverse proxy for horizontal scaling.
  - Use separate volumes for persistent data if needed (not currently configured).
- Logging:
  - PYTHONUNBUFFERED=1 ensures timely log output in containers.
- Network:
  - Keep frontend and backend on the same Docker network for low-latency communication.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common deployment issues and resolutions:
- Frontend cannot reach backend:
  - Verify Nginx proxy target matches backend service name and port.
  - Confirm Compose service dependency ordering.
- CORS errors in development:
  - The backend allows all origins; ensure the browser is requesting from the expected origin.
- SPA routing failures:
  - Ensure Nginx try_files directive includes /index.html for client-side routes.
- Build failures:
  - Check frontend Dockerfile stages and package installation steps.
  - Validate Vite proxy target in development matches backend port.
- API errors:
  - Inspect backend response details returned in JSON and surface them to the UI.

**Section sources**
- [frontend/nginx.conf:7-10](file://frontend/nginx.conf#L7-L10)
- [frontend/nginx.conf:12-19](file://frontend/nginx.conf#L12-L19)
- [frontend/vite.config.ts:7-14](file://frontend/vite.config.ts#L7-L14)
- [backend/app/main.py:12-18](file://backend/app/main.py#L12-L18)
- [frontend/src/utils/api.ts:29-33](file://frontend/src/utils/api.ts#L29-L33)

## CI/CD and Rollback Procedures
Recommended CI/CD integration:
- Build stages:
  - Build backend image using Dockerfile.backend.
  - Build frontend image using Dockerfile.frontend.
- Test stages:
  - Run linter and unit tests for backend (pytest-compatible structure).
  - Run linter and build for frontend (Vite build).
- Deploy stages:
  - Push images to registry.
  - Deploy using Compose or Kubernetes manifests.
- Rollback:
  - Tag previous working images and redeploy.
  - Use Compose pull and up with pinned image tags for deterministic rollbacks.

Automated testing setup:
- Backend: configure pytest and FastAPI test client to validate endpoints.
- Frontend: configure Vitest/Jest and React Testing Library for component tests.

[No sources needed since this section provides general guidance]

## Conclusion
The deployment configuration establishes a clean separation between the frontend and backend, with Nginx handling static delivery and API proxying. The Dockerfiles and Compose setup are optimized for simplicity and maintainability. For production, consider adding secrets management, persistent volumes, health checks, load balancing, and observability (logging, metrics, tracing). The provided troubleshooting and CI/CD guidance helps ensure reliable deployments and smooth operations.