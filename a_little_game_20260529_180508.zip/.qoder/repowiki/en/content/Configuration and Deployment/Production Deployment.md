# Production Deployment

<cite>
**Referenced Files in This Document**
- [docker-compose.yml](file://docker-compose.yml)
- [Dockerfile.backend](file://Dockerfile.backend)
- [Dockerfile.frontend](file://Dockerfile.frontend)
- [backend/app/main.py](file://backend/app/main.py)
- [backend/app/router.py](file://backend/app/router.py)
- [backend/requirements.txt](file://backend/requirements.txt)
- [frontend/nginx.conf](file://frontend/nginx.conf)
- [frontend/vite.config.ts](file://frontend/vite.config.ts)
- [frontend/package.json](file://frontend/package.json)
- [frontend/src/utils/api.ts](file://frontend/src/utils/api.ts)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document provides a production-focused deployment guide for the application using Docker Compose. It covers the multi-service architecture with Nginx reverse proxy, a backend FastAPI service, and a frontend React application. It explains containerization strategies, networking, port mappings, build configurations, and operational best practices for production environments including security, monitoring, logging, scaling, and performance tuning.

## Project Structure
The repository organizes the stack into three primary parts:
- Backend: Python FastAPI application with Uvicorn ASGI server
- Frontend: React application built via Vite and served by Nginx
- Orchestration: Docker Compose to coordinate services, expose ports, and manage dependencies

```mermaid
graph TB
subgraph "Host"
Internet["Internet"]
end
subgraph "Docker Compose"
Nginx["Nginx Reverse Proxy<br/>Port 80 -> 80"]
Backend["FastAPI Backend<br/>Port 8000 -> 8000"]
end
subgraph "Container Networking"
FESvc["frontend service"]
BEApi["backend service"]
end
Internet --> Nginx
Nginx --> |"/api/* proxy"| Backend
Nginx --> |SPA fallback| FESvc
FESvc --> |depends_on| BEApi
```

**Diagram sources**
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)
- [Dockerfile.frontend:1-13](file://Dockerfile.frontend#L1-L13)
- [Dockerfile.backend:1-8](file://Dockerfile.backend#L1-L8)

**Section sources**
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)
- [Dockerfile.backend:1-8](file://Dockerfile.backend#L1-L8)
- [Dockerfile.frontend:1-13](file://Dockerfile.frontend#L1-L13)

## Core Components
- Nginx reverse proxy and static asset server
  - Serves the React SPA, handles SPA routing fallback, proxies API requests to the backend, and caches static assets.
  - Configuration file defines proxy pass, headers, and caching behavior.
  - See [frontend/nginx.conf:1-27](file://frontend/nginx.conf#L1-L27).

- Backend FastAPI service
  - Exposes REST endpoints under /api/game prefixed routes.
  - Includes CORS middleware and runs with Uvicorn.
  - See [backend/app/main.py:1-26](file://backend/app/main.py#L1-L26) and [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69).

- Frontend React application
  - Built with Vite and TypeScript, served by Nginx.
  - Uses a proxy configured for development that targets the backend port.
  - API client uses a base path of /api/game for all requests.
  - See [frontend/vite.config.ts:1-16](file://frontend/vite.config.ts#L1-L16), [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57), and [frontend/package.json:1-33](file://frontend/package.json#L1-L33).

**Section sources**
- [frontend/nginx.conf:1-27](file://frontend/nginx.conf#L1-L27)
- [backend/app/main.py:1-26](file://backend/app/main.py#L1-L26)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [frontend/vite.config.ts:1-16](file://frontend/vite.config.ts#L1-L16)
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [frontend/package.json:1-33](file://frontend/package.json#L1-L33)

## Architecture Overview
The production architecture uses a single-host Docker Compose setup:
- Nginx listens on host port 80 and serves the React SPA.
- API requests under /api/ are proxied to the backend service on port 8000.
- The frontend service depends on the backend service and restarts unless stopped.
- The backend service exposes port 8000 and runs Uvicorn with host binding to 0.0.0.0.

```mermaid
graph TB
Client["Browser"]
FE["Nginx (frontend)<br/>:80 -> :80"]
BE["FastAPI (backend)<br/>:8000 -> :8000"]
Client --> FE
FE --> |"/api/* -> backend:8000"| BE
FE --> |"SPA fallback"| FE
```

**Diagram sources**
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)
- [Dockerfile.frontend:1-13](file://Dockerfile.frontend#L1-L13)
- [Dockerfile.backend:1-8](file://Dockerfile.backend#L1-L8)

**Section sources**
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)
- [Dockerfile.frontend:1-13](file://Dockerfile.frontend#L1-L13)
- [Dockerfile.backend:1-8](file://Dockerfile.backend#L1-L8)

## Detailed Component Analysis

### Nginx Reverse Proxy and Static Asset Serving
- Port mapping: Host 80 -> Container 80.
- SPA routing: Nginx tries static files first, then falls back to index.html for client-side routing.
- API proxy: Requests under /api/ are forwarded to backend:8000 with standard proxy headers.
- Caching: Static assets (.js, .css, images, fonts) are cached for one year with immutable cache-control.
- Configuration file path: [frontend/nginx.conf:1-27](file://frontend/nginx.conf#L1-L27).

```mermaid
flowchart TD
Start(["Incoming Request"]) --> PathCheck{"Path starts with /api/ ?"}
PathCheck --> |Yes| Proxy["Proxy to backend:8000<br/>with X-Forwarded-* headers"]
PathCheck --> |No| SPA["Serve SPA<br/>try_files -> index.html"]
Proxy --> End(["Response"])
SPA --> End
```

**Diagram sources**
- [frontend/nginx.conf:12-19](file://frontend/nginx.conf#L12-L19)
- [frontend/nginx.conf:7-10](file://frontend/nginx.conf#L7-L10)

**Section sources**
- [frontend/nginx.conf:1-27](file://frontend/nginx.conf#L1-L27)

### Backend FastAPI Service
- Base image: python:3.11-slim.
- Dependencies installed from requirements.txt with pip and no-cache.
- Application entrypoint: Uvicorn running the FastAPI app module bound to 0.0.0.0:8000.
- CORS: Configured broadly for development; tighten in production.
- Routes: Under /api/game with endpoints for talents, starting a game, advancing a year, and retrieving summaries.
- Environment: PYTHONUNBUFFERED=1 for stdout/stderr streaming.

```mermaid
sequenceDiagram
participant Client as "Browser"
participant Nginx as "Nginx Proxy"
participant API as "FastAPI Backend"
Client->>Nginx : GET /api/game/talents
Nginx->>API : GET /api/game/talents
API-->>Nginx : JSON response
Nginx-->>Client : 200 OK
Client->>Nginx : POST /api/game/start
Nginx->>API : POST /api/game/start
API-->>Nginx : Game state JSON
Nginx-->>Client : 200 OK
```

**Diagram sources**
- [backend/app/router.py:11-44](file://backend/app/router.py#L11-L44)
- [frontend/nginx.conf:12-19](file://frontend/nginx.conf#L12-L19)

**Section sources**
- [Dockerfile.backend:1-8](file://Dockerfile.backend#L1-L8)
- [backend/requirements.txt:1-5](file://backend/requirements.txt#L1-L5)
- [backend/app/main.py:1-26](file://backend/app/main.py#L1-L26)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [docker-compose.yml:12-21](file://docker-compose.yml#L12-L21)

### Frontend React Application
- Multi-stage build:
  - Builder stage: node:20-alpine with npm ci and build.
  - Runtime stage: nginx:alpine serving /usr/share/nginx/html.
- Copies built SPA and Nginx config into runtime image.
- Exposes port 80 and runs nginx -g "daemon off;".
- Development proxy configuration targets backend port 8000 for local dev.
- API client uses /api/game base path for all endpoints.

```mermaid
flowchart TD
Dev["Developer Machine"] --> Build["Build Stage<br/>node:20-alpine + npm ci + npm run build"]
Build --> Runtime["Runtime Stage<br/>nginx:alpine + copy dist + nginx.conf"]
Runtime --> Serve["Serve on :80<br/>daemon off"]
```

**Diagram sources**
- [Dockerfile.frontend:1-13](file://Dockerfile.frontend#L1-L13)

**Section sources**
- [Dockerfile.frontend:1-13](file://Dockerfile.frontend#L1-L13)
- [frontend/vite.config.ts:1-16](file://frontend/vite.config.ts#L1-L16)
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)

### Service Dependencies and Network Topology
- The frontend service declares depends_on: backend, ensuring startup order.
- Services communicate over Docker Compose’s default network using service names:
  - Nginx proxies /api/ to backend:8000.
- Ports exposed to host:
  - frontend: 80:80
  - backend: 8000:8000

```mermaid
graph LR
FE["frontend service"] -- "depends_on" --> BE["backend service"]
FE -- "exposes 80" --> Host["Host Port 80"]
BE -- "exposes 8000" --> Host2["Host Port 8000"]
```

**Diagram sources**
- [docker-compose.yml:8-10](file://docker-compose.yml#L8-L10)
- [docker-compose.yml:6-7](file://docker-compose.yml#L6-L7)
- [docker-compose.yml:16-17](file://docker-compose.yml#L16-L17)

**Section sources**
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)

## Dependency Analysis
- Frontend-to-backend dependency:
  - The frontend relies on the backend being reachable at backend:8000 via the proxy configuration.
- Internal dependencies:
  - Backend depends on FastAPI, Uvicorn, Pydantic, and multipart parsing libraries as defined in requirements.txt.
- Build-time dependencies:
  - Frontend build requires Node.js and npm; runtime requires Nginx.

```mermaid
graph TB
FE["frontend (Nginx)"] --> |"/api/ -> backend:8000"| BE["backend (FastAPI/Uvicorn)"]
BE --> Libs["Python Libraries<br/>FastAPI, Uvicorn, Pydantic"]
```

**Diagram sources**
- [frontend/nginx.conf:12-19](file://frontend/nginx.conf#L12-L19)
- [backend/requirements.txt:1-5](file://backend/requirements.txt#L1-5)

**Section sources**
- [frontend/nginx.conf:12-19](file://frontend/nginx.conf#L12-L19)
- [backend/requirements.txt:1-5](file://backend/requirements.txt#L1-L5)

## Performance Considerations
- Static asset caching:
  - Configure long-lived caching for JS/CSS/fonts/images with immutable cache-control headers.
  - Reference: [frontend/nginx.conf:21-25](file://frontend/nginx.conf#L21-L25)
- Gzip/Brotli compression:
  - Enable gzip and optionally Brotli in Nginx for reduced payload sizes.
- CDN integration:
  - Serve static assets via CDN for global distribution and reduced origin load.
- Load balancing:
  - For horizontal scaling, place a reverse proxy (e.g., Nginx or HAProxy) in front of multiple backend instances behind a load balancer.
- Resource allocation:
  - Assign CPU/memory limits per service in Docker Compose for predictable performance.
  - Scale backend replicas behind a shared session store if needed.
- Health checks:
  - Add readiness/liveness probes to the backend (e.g., curl / on 8000) and expose metrics endpoints if desired.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
- CORS errors in browser console:
  - The backend currently allows all origins. Tighten allow_origins in production.
  - Reference: [backend/app/main.py:12-18](file://backend/app/main.py#L12-L18)
- API 404 or proxy failures:
  - Verify Nginx proxy_pass target matches backend service name and port.
  - Reference: [frontend/nginx.conf:14](file://frontend/nginx.conf#L14)
- SPA route not found after refresh:
  - Confirm Nginx try_files fallback to index.html is active.
  - Reference: [frontend/nginx.conf:8-10](file://frontend/nginx.conf#L8-L10)
- Backend not reachable:
  - Ensure backend is healthy and listening on 0.0.0.0:8000.
  - Reference: [Dockerfile.backend:7](file://Dockerfile.backend#L7)
- Logging:
  - Enable access logs and error logs in Nginx and stream container logs.
  - For backend, ensure PYTHONUNBUFFERED=1 is set for real-time logs.
  - Reference: [docker-compose.yml:19-20](file://docker-compose.yml#L19-L20)

**Section sources**
- [backend/app/main.py:12-18](file://backend/app/main.py#L12-L18)
- [frontend/nginx.conf:8-10](file://frontend/nginx.conf#L8-L10)
- [frontend/nginx.conf:14](file://frontend/nginx.conf#L14)
- [Dockerfile.backend:7](file://Dockerfile.backend#L7)
- [docker-compose.yml:19-20](file://docker-compose.yml#L19-L20)

## Conclusion
The current deployment model uses a straightforward single-host Docker Compose setup with Nginx proxying API traffic to a FastAPI backend and serving the React SPA. For production, focus on tightening CORS, enabling HTTPS/TLS termination at Nginx, adding health checks, implementing monitoring/logging, and preparing for horizontal scaling behind a load balancer. Integrate CDN for static assets and apply resource limits for stability.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Security Hardening Guidelines
- TLS/SSL:
  - Terminate TLS at Nginx using certificates from a trusted CA or ACME automation.
  - Redirect HTTP to HTTPS and enforce strong ciphers.
- CORS:
  - Restrict allow_origins to specific domains in production.
  - Reference: [backend/app/main.py:12-18](file://backend/app/main.py#L12-L18)
- Secrets and environment:
  - Externalize secrets via Docker secrets or environment files; avoid committing sensitive data.
- Network policies:
  - Limit inbound ports to 80 (and 443 if TLS enabled) and restrict backend exposure.
- Rate limiting and WAF:
  - Enable rate limiting and consider a Web Application Firewall at the edge.

[No sources needed since this section provides general guidance]

### Backup Strategies and Disaster Recovery
- Database backups:
  - If the backend stores data externally, back up the database regularly and test restoration procedures.
- Application artifacts:
  - Store container images in a private registry with immutable tags.
- Disaster recovery:
  - Document restore steps for containers, volumes, and external databases.
  - Maintain a minimal recovery environment with Docker Compose and secrets management.

[No sources needed since this section provides general guidance]

### Monitoring Setup and Logging
- Metrics:
  - Expose Prometheus metrics from the backend if applicable.
  - Track Nginx stub_status or use a monitoring agent.
- Logs:
  - Stream container logs to a centralized log collector (e.g., ELK or Loki).
  - Enable Nginx access/error logs and rotate logs with logrotate.
- Health checks:
  - Add readiness probe to the backend (curl /) and liveness probe to restart unhealthy containers.

[No sources needed since this section provides general guidance]

### Scaling and Resource Allocation Recommendations
- Horizontal scaling:
  - Run multiple backend replicas behind a load balancer.
  - Use sticky sessions only if required; otherwise design stateless endpoints.
- Resource limits:
  - Set memory and CPU limits per service in Docker Compose.
- Storage:
  - Persist logs and any generated artifacts to named volumes.

[No sources needed since this section provides general guidance]