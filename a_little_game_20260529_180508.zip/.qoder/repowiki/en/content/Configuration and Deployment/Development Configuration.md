# Development Configuration

<cite>
**Referenced Files in This Document**
- [vite.config.ts](file://frontend/vite.config.ts)
- [package.json](file://frontend/package.json)
- [tsconfig.json](file://frontend/tsconfig.json)
- [tsconfig.app.json](file://frontend/tsconfig.app.json)
- [tsconfig.node.json](file://frontend/tsconfig.node.json)
- [eslint.config.js](file://frontend/eslint.config.js)
- [nginx.conf](file://frontend/nginx.conf)
- [main.py](file://backend/app/main.py)
- [router.py](file://backend/app/router.py)
- [requirements.txt](file://backend/requirements.txt)
- [docker-compose.yml](file://docker-compose.yml)
- [Dockerfile.backend](file://Dockerfile.backend)
- [Dockerfile.frontend](file://Dockerfile.frontend)
- [api.ts](file://frontend/src/utils/api.ts)
- [types.ts](file://frontend/src/utils/types.ts)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document provides comprehensive development configuration guidance for setting up a local development environment and build processes for a full-stack application featuring a React frontend and a FastAPI backend. It covers frontend tooling (Vite, TypeScript, ESLint), backend Python environment (FastAPI, Uvicorn), development workflow (hot reload, debugging, environment variables), code quality tools, pre-commit hooks, development database configuration, local API testing, and troubleshooting tips.

## Project Structure
The project follows a clear separation between frontend and backend:
- Frontend: React application built with Vite, TypeScript, and Tailwind CSS, configured via dedicated tsconfig files and ESLint flat config.
- Backend: FastAPI application with CORS middleware, route definitions under a /api/game prefix, and dependency management via requirements.txt.
- Containerization: Docker Compose orchestrates frontend (Nginx serving built assets) and backend (Uvicorn) services, exposing ports 80 and 8000 respectively.

```mermaid
graph TB
subgraph "Frontend"
FE_PKG["package.json scripts"]
FE_VITE["vite.config.ts"]
FE_TS["tsconfig.*.json"]
FE_ESLINT["eslint.config.js"]
FE_NGINX["nginx.conf"]
end
subgraph "Backend"
BE_REQ["requirements.txt"]
BE_MAIN["app/main.py"]
BE_ROUTER["app/router.py"]
end
subgraph "Containerization"
DC["docker-compose.yml"]
DF_BE["Dockerfile.backend"]
DF_FE["Dockerfile.frontend"]
end
FE_PKG --> FE_VITE
FE_VITE --> FE_TS
FE_VITE --> FE_ESLINT
FE_VITE --> FE_NGINX
BE_REQ --> BE_MAIN
BE_MAIN --> BE_ROUTER
DC --> DF_BE
DC --> DF_FE
```

**Diagram sources**
- [package.json:1-33](file://frontend/package.json#L1-L33)
- [vite.config.ts:1-16](file://frontend/vite.config.ts#L1-L16)
- [tsconfig.json:1-8](file://frontend/tsconfig.json#L1-L8)
- [eslint.config.js:1-23](file://frontend/eslint.config.js#L1-L23)
- [nginx.conf:1-27](file://frontend/nginx.conf#L1-L27)
- [requirements.txt:1-5](file://backend/requirements.txt#L1-L5)
- [main.py:1-26](file://backend/app/main.py#L1-L26)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)
- [Dockerfile.backend:1-8](file://Dockerfile.backend#L1-L8)
- [Dockerfile.frontend:1-13](file://Dockerfile.frontend#L1-L13)

**Section sources**
- [package.json:1-33](file://frontend/package.json#L1-L33)
- [vite.config.ts:1-16](file://frontend/vite.config.ts#L1-L16)
- [tsconfig.json:1-8](file://frontend/tsconfig.json#L1-L8)
- [eslint.config.js:1-23](file://frontend/eslint.config.js#L1-L23)
- [nginx.conf:1-27](file://frontend/nginx.conf#L1-L27)
- [requirements.txt:1-5](file://backend/requirements.txt#L1-L5)
- [main.py:1-26](file://backend/app/main.py#L1-L26)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)
- [Dockerfile.backend:1-8](file://Dockerfile.backend#L1-L8)
- [Dockerfile.frontend:1-13](file://Dockerfile.frontend#L1-L13)

## Core Components
- Frontend development server and proxy:
  - Vite dev server with React plugin and Tailwind integration.
  - Proxy configuration to forward /api requests to the backend service.
- TypeScript configuration:
  - Separate tsconfig files for application and Node/Vite tooling with strict linting options.
- Code quality:
  - ESLint flat config with TypeScript, React Hooks, React Refresh, and browser globals.
- Backend API:
  - FastAPI app with CORS enabled and a /api/game router with endpoints for talents, starting a game, advancing years, and retrieving summaries.
- Containerization:
  - Docker Compose defines frontend and backend services with port mappings and environment variables.
  - Nginx serves built frontend assets and proxies API requests to the backend container.

**Section sources**
- [vite.config.ts:1-16](file://frontend/vite.config.ts#L1-L16)
- [package.json:6-11](file://frontend/package.json#L6-L11)
- [tsconfig.app.json:1-26](file://frontend/tsconfig.app.json#L1-L26)
- [tsconfig.node.json:1-25](file://frontend/tsconfig.node.json#L1-L25)
- [eslint.config.js:8-22](file://frontend/eslint.config.js#L8-L22)
- [main.py:6-20](file://backend/app/main.py#L6-L20)
- [router.py:8-69](file://backend/app/router.py#L8-L69)
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)
- [nginx.conf:12-19](file://frontend/nginx.conf#L12-L19)

## Architecture Overview
The development architecture supports hot module replacement and live reloading for rapid iteration. The frontend communicates with the backend via a development proxy, while production builds are served by Nginx with API proxying to the backend container.

```mermaid
graph TB
Dev["Developer Browser"]
ViteDev["Vite Dev Server<br/>frontend:5173"]
Proxy["Vite Proxy /api -> http://localhost:8000"]
FE_API["Frontend API Client<br/>fetch('/api/game/*')"]
BE_Main["FastAPI App<br/>app/main.py"]
BE_Router["Router /api/game/*<br/>app/router.py"]
Uvicorn["Uvicorn ASGI Server<br/>0.0.0.0:8000"]
Dev --> ViteDev
ViteDev --> Proxy
FE_API --> Proxy
Proxy --> BE_Main
BE_Main --> BE_Router
BE_Router --> Uvicorn
```

**Diagram sources**
- [vite.config.ts:7-14](file://frontend/vite.config.ts#L7-L14)
- [api.ts:3](file://frontend/src/utils/api.ts#L3)
- [main.py:6-20](file://backend/app/main.py#L6-L20)
- [router.py:8](file://backend/app/router.py#L8)
- [Dockerfile.backend:7](file://Dockerfile.backend#L7)

**Section sources**
- [vite.config.ts:1-16](file://frontend/vite.config.ts#L1-L16)
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [main.py:1-26](file://backend/app/main.py#L1-L26)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [Dockerfile.backend:1-8](file://Dockerfile.backend#L1-L8)

## Detailed Component Analysis

### Frontend Development Tools: Vite, TypeScript, ESLint
- Vite configuration:
  - Plugins include React and Tailwind CSS.
  - Development server proxy forwards /api to the backend on port 8000.
- TypeScript configuration:
  - Root tsconfig aggregates app and node configs.
  - Application tsconfig sets bundler mode, JSX transform, and strict linting flags.
  - Node tsconfig configures Vite tooling and Node types.
- ESLint configuration:
  - Flat config extends recommended rules for JavaScript/TypeScript, React Hooks, React Refresh, and browser globals.
  - Ignores dist output during linting.

```mermaid
flowchart TD
Start(["Run frontend dev"]) --> Install["Install dependencies"]
Install --> BuildTS["TypeScript compile (tsc)"]
BuildTS --> ViteDev["Start Vite dev server"]
ViteDev --> ProxySetup["Enable /api proxy to backend"]
ProxySetup --> Serve["Serve React app on 5173"]
Serve --> Lint["ESLint check on save"]
Lint --> HotReload["Hot reload on file change"]
```

**Diagram sources**
- [package.json:6-11](file://frontend/package.json#L6-L11)
- [vite.config.ts:5-15](file://frontend/vite.config.ts#L5-L15)
- [tsconfig.json:3-6](file://frontend/tsconfig.json#L3-L6)
- [eslint.config.js:8-22](file://frontend/eslint.config.js#L8-L22)

**Section sources**
- [vite.config.ts:1-16](file://frontend/vite.config.ts#L1-L16)
- [package.json:1-33](file://frontend/package.json#L1-L33)
- [tsconfig.json:1-8](file://frontend/tsconfig.json#L1-L8)
- [tsconfig.app.json:1-26](file://frontend/tsconfig.app.json#L1-L26)
- [tsconfig.node.json:1-25](file://frontend/tsconfig.node.json#L1-L25)
- [eslint.config.js:1-23](file://frontend/eslint.config.js#L1-L23)

### Backend Python Development Environment: FastAPI, Dependencies, Testing
- FastAPI application:
  - Creates an app with title, description, and version.
  - Enables CORS for all origins/methods/headers.
  - Includes the game router under /api/game.
- Route definitions:
  - GET /api/game/talents returns a random set of talents.
  - POST /api/game/start validates attributes and talents, then initializes a game state.
  - POST /api/game/next-year advances the game by one year.
  - GET /api/game/summary/{game_id} returns the life summary.
- Dependencies:
  - FastAPI, Uvicorn, Pydantic, and python-multipart pinned in requirements.txt.
- Local testing:
  - Run the backend locally using Uvicorn on port 8000 or via Docker Compose.

```mermaid
sequenceDiagram
participant FE as "Frontend"
participant API as "FastAPI Router"
participant GE as "Game Engine"
FE->>API : "POST /api/game/start"
API->>API : "Validate attributes and talents"
API->>GE : "create_game(attributes, talents)"
GE-->>API : "GameState"
API-->>FE : "JSON response"
FE->>API : "POST /api/game/next-year"
API->>GE : "advance_year(game_id)"
GE-->>API : "NextYearResponse"
API-->>FE : "JSON response"
FE->>API : "GET /api/game/summary/{game_id}"
API->>GE : "get_life_summary(game_id)"
GE-->>API : "LifeSummary"
API-->>FE : "JSON response"
```

**Diagram sources**
- [router.py:11-69](file://backend/app/router.py#L11-L69)
- [main.py:6-20](file://backend/app/main.py#L6-L20)

**Section sources**
- [main.py:1-26](file://backend/app/main.py#L1-L26)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [requirements.txt:1-5](file://backend/requirements.txt#L1-L5)

### Development Workflow: Hot Reload, Debugging, Environment Variables
- Hot reload:
  - Vite dev server enables fast HMR for React components.
  - ESLint runs on save to catch issues early.
- Debugging:
  - Frontend: Use browser devtools and React DevTools.
  - Backend: Use Python debuggers or IDE breakpoints; Uvicorn logs are unbuffered via environment variable.
- Environment variables:
  - PYTHONUNBUFFERED=1 ensures real-time logs in containers.
  - Frontend uses a proxy for API calls during development.

```mermaid
flowchart TD
DevStart["Start dev stack"] --> FE_Dev["npm run dev (Vite)"]
DevStart --> BE_Run["uvicorn app.main:app --host 0.0.0.0 --port 8000"]
FE_Dev --> ProxyCfg["Proxy /api -> http://localhost:8000"]
ProxyCfg --> LiveReload["Hot reload on file change"]
BE_Run --> Logs["Unbuffered logs via PYTHONUNBUFFERED"]
```

**Diagram sources**
- [package.json:7](file://frontend/package.json#L7)
- [Dockerfile.backend:7](file://Dockerfile.backend#L7)
- [vite.config.ts:7-14](file://frontend/vite.config.ts#L7-L14)

**Section sources**
- [package.json:6-11](file://frontend/package.json#L6-L11)
- [Dockerfile.backend:20](file://docker-compose.yml#L20)
- [vite.config.ts:7-14](file://frontend/vite.config.ts#L7-L14)

### Code Quality Tools and Pre-commit Hooks
- ESLint:
  - Flat config enforces recommended rules for TS/JS, React Hooks, React Refresh, and browser globals.
  - Ignores dist output to avoid linting generated files.
- Suggested pre-commit hooks:
  - Run ESLint and TypeScript checks before committing.
  - Optional: Add Prettier for formatting and a linter for Python (e.g., ruff/flake8) in CI.

**Section sources**
- [eslint.config.js:8-22](file://frontend/eslint.config.js#L8-L22)

### Development Database Configuration and Local API Testing
- Database:
  - No explicit database configuration is present in the repository. If persistence is needed, configure a local database and set environment variables accordingly.
- Local API testing:
  - Use the frontend proxy to call backend endpoints under /api/game.
  - Example endpoints: GET /api/game/talents, POST /api/game/start, POST /api/game/next-year, GET /api/game/summary/{game_id}.
  - Frontend API client methods handle errors and return typed responses.

```mermaid
sequenceDiagram
participant Client as "Frontend API Client"
participant Proxy as "Vite Proxy /api"
participant Backend as "FastAPI Backend"
Client->>Proxy : "GET /api/game/talents"
Proxy->>Backend : "Forward request"
Backend-->>Proxy : "Talents JSON"
Proxy-->>Client : "Talents JSON"
Client->>Proxy : "POST /api/game/start"
Proxy->>Backend : "Forward request"
Backend-->>Proxy : "Game state JSON"
Proxy-->>Client : "Game state JSON"
```

**Diagram sources**
- [api.ts:5-34](file://frontend/src/utils/api.ts#L5-L34)
- [vite.config.ts:8-13](file://frontend/vite.config.ts#L8-L13)
- [router.py:11-44](file://backend/app/router.py#L11-L44)

**Section sources**
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)
- [router.py:1-69](file://backend/app/router.py#L1-L69)

## Dependency Analysis
- Frontend dependencies:
  - React, React DOM, Vite, @vitejs/plugin-react, Tailwind CSS, TypeScript, ESLint, and related plugins.
- Backend dependencies:
  - FastAPI, Uvicorn, Pydantic, python-multipart.
- Containerization:
  - Frontend image builds assets with Nginx serving them; backend image runs Uvicorn.

```mermaid
graph LR
subgraph "Frontend"
React["react"]
Vite["vite"]
ESL["eslint"]
TS["typescript"]
Tail["tailwindcss"]
end
subgraph "Backend"
FA["fastapi"]
UV["uvicorn"]
PD["pydantic"]
MP["python-multipart"]
end
React --> Vite
Vite --> ESL
ESL --> TS
Tail --> Vite
FA --> UV
FA --> PD
FA --> MP
```

**Diagram sources**
- [package.json:12-31](file://frontend/package.json#L12-L31)
- [requirements.txt:1-5](file://backend/requirements.txt#L1-L5)

**Section sources**
- [package.json:1-33](file://frontend/package.json#L1-L33)
- [requirements.txt:1-5](file://backend/requirements.txt#L1-L5)

## Performance Considerations
- Frontend:
  - Use Vite’s built-in HMR for fast iteration; avoid unnecessary re-renders in React components.
  - Keep TypeScript strictness high to catch issues early.
- Backend:
  - Run Uvicorn with appropriate workers for development; keep logging unbuffered for observability.
- Containerization:
  - Use development compose overrides to mount volumes for faster rebuilds.
  - Nginx caching for static assets improves load times in production builds.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
- Frontend proxy not working:
  - Verify Vite proxy target matches backend port (8000).
  - Ensure the frontend dev server is running before making API calls.
- Backend not reachable:
  - Confirm Uvicorn is listening on 0.0.0.0:8000.
  - Check CORS configuration if cross-origin requests fail.
- API errors:
  - Inspect returned error messages from endpoints; frontend API client throws on non-OK responses.
- Docker Compose issues:
  - Ensure ports 80 and 8000 are free; confirm images build successfully.
  - Check PYTHONUNBUFFERED environment variable is set for readable logs.

**Section sources**
- [vite.config.ts:7-14](file://frontend/vite.config.ts#L7-L14)
- [main.py:12-18](file://backend/app/main.py#L12-L18)
- [api.ts:29-33](file://frontend/src/utils/api.ts#L29-L33)
- [docker-compose.yml:16-20](file://docker-compose.yml#L16-L20)

## Conclusion
This development configuration establishes a robust local environment combining Vite for frontend hot reload, TypeScript for type safety, ESLint for code quality, and FastAPI/Uvicorn for backend development. The proxy setup and containerization streamline the workflow, enabling efficient iteration and testing. Following the outlined practices and troubleshooting steps will help maintain a smooth development experience.