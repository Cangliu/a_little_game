# Getting Started

<cite>
**Referenced Files in This Document**
- [docker-compose.yml](file://docker-compose.yml)
- [Dockerfile.backend](file://Dockerfile.backend)
- [Dockerfile.frontend](file://Dockerfile.frontend)
- [backend/requirements.txt](file://backend/requirements.txt)
- [backend/app/main.py](file://backend/app/main.py)
- [backend/app/router.py](file://backend/app/router.py)
- [frontend/package.json](file://frontend/package.json)
- [frontend/vite.config.ts](file://frontend/vite.config.ts)
- [frontend/nginx.conf](file://frontend/nginx.conf)
- [frontend/src/utils/api.ts](file://frontend/src/utils/api.ts)
- [frontend/src/App.tsx](file://frontend/src/App.tsx)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Prerequisites](#prerequisites)
3. [Local Development Setup](#local-development-setup)
4. [Docker Compose Orchestration](#docker-compose-orchestration)
5. [Environment Variables and Ports](#environment-variables-and-ports)
6. [Build Process](#build-process)
7. [Quick Start Examples](#quick-start-examples)
8. [Verification Steps](#verification-steps)
9. [Troubleshooting Guide](#troubleshooting-guide)
10. [Conclusion](#conclusion)

## Introduction
This guide helps you set up the A Little Game development environment locally. It covers prerequisites, local development setup for both backend and frontend, Docker Compose orchestration, environment variables, ports, build process, and troubleshooting tips. After following this guide, you will be able to run the application locally and access the frontend and backend services.

## Prerequisites
Ensure the following tools are installed on your machine:
- Python 3.11 or newer
- Node.js (with npm)
- Docker and Docker Compose

These versions are required because:
- The backend Docker image is based on python:3.11-slim.
- The frontend Docker image uses node:20-alpine for building assets.
- The frontend development server proxies API requests to the backend on port 8000.

**Section sources**
- [Dockerfile.backend:1](file://Dockerfile.backend#L1)
- [Dockerfile.frontend:1](file://Dockerfile.frontend#L1)
- [backend/requirements.txt:1](file://backend/requirements.txt#L1)

## Local Development Setup
Follow these steps to run the application locally using Docker Compose.

### Step 1: Clone and prepare the repository
- Clone the repository to your local machine.
- Navigate to the project root directory.

### Step 2: Build and start services
- Use Docker Compose to build and start the frontend and backend services.
- The frontend service exposes port 80 and depends on the backend service.
- The backend service exposes port 8000.

### Step 3: Access the application
- Open your browser and navigate to http://localhost to access the frontend.
- The frontend proxies API requests under /api/ to the backend service at http://localhost:8000.

Notes:
- The frontend container serves static assets via Nginx.
- The backend container runs the FastAPI application using Uvicorn.

**Section sources**
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)
- [frontend/nginx.conf:12-19](file://frontend/nginx.conf#L12-L19)

## Docker Compose Orchestration
The Docker Compose configuration defines two primary services: frontend and backend. The frontend service builds from the frontend directory and uses a multi-stage build to produce optimized static assets served by Nginx. The backend service builds from the project root using the backend Dockerfile and exposes the FastAPI application.

```mermaid
graph TB
subgraph "Host Machine"
Browser["Browser<br/>Port 80"]
end
subgraph "Docker Network"
Nginx["Nginx Container<br/>Port 80"]
Backend["Backend Container<br/>Port 8000"]
end
Browser --> |HTTP| Nginx
Nginx --> |/api/ proxy| Backend
```

**Diagram sources**
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)
- [frontend/nginx.conf:12-19](file://frontend/nginx.conf#L12-L19)

Key orchestration details:
- The frontend service depends_on the backend service to ensure startup order.
- The frontend service maps host port 80 to container port 80.
- The backend service maps host port 8000 to container port 8000.

**Section sources**
- [docker-compose.yml:6-18](file://docker-compose.yml#L6-L18)

## Environment Variables and Ports
- Backend environment variable:
  - PYTHONUNBUFFERED=1: Ensures Python output is not buffered, which is useful for logging in containers.
- Port mappings:
  - Frontend: host 80 -> container 80 (Nginx)
  - Backend: host 8000 -> container 8000 (Uvicorn)

These settings are defined in the Docker Compose configuration and Dockerfiles.

**Section sources**
- [docker-compose.yml:19-20](file://docker-compose.yml#L19-L20)
- [Dockerfile.backend:6](file://Dockerfile.backend#L6)
- [Dockerfile.frontend:11](file://Dockerfile.frontend#L11)

## Build Process
There are two build modes: development and production.

### Production Build (Containerized)
- Backend:
  - The backend Dockerfile installs Python dependencies from requirements.txt and runs the FastAPI app with Uvicorn.
- Frontend:
  - The frontend Dockerfile performs a multi-stage build:
    - Stage 1: Installs Node.js dependencies and builds the application.
    - Stage 2: Copies built assets into an Nginx base image and configures Nginx with the included nginx.conf.

After building, both services are orchestrated by Docker Compose.

**Section sources**
- [Dockerfile.backend:1-8](file://Dockerfile.backend#L1-L8)
- [Dockerfile.frontend:1-13](file://Dockerfile.frontend#L1-L13)
- [backend/requirements.txt:1](file://backend/requirements.txt#L1)

### Development Build (Local)
- Backend:
  - Install Python dependencies using the requirements file.
  - Run the FastAPI application locally with Uvicorn on port 8000.
- Frontend:
  - Install Node.js dependencies using npm.
  - Start the Vite development server, which proxies API requests to http://localhost:8000.

Proxy configuration ensures frontend API calls reach the backend during local development.

**Section sources**
- [backend/requirements.txt:1](file://backend/requirements.txt#L1)
- [frontend/package.json:6-10](file://frontend/package.json#L6-L10)
- [frontend/vite.config.ts:7-14](file://frontend/vite.config.ts#L7-L14)

## Quick Start Examples
Run the application locally using Docker Compose:
- Build and start services:
  - docker-compose up --build
- Stop services:
  - docker-compose down

Access the application:
- Frontend: http://localhost
- Backend health endpoint: http://localhost (root route returns a message and version)

Note: The frontend proxies /api/ requests to the backend service at http://backend:8000 inside the Docker network. From outside the container network, use http://localhost:8000 for direct backend access.

**Section sources**
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)
- [backend/app/main.py:23-25](file://backend/app/main.py#L23-L25)
- [frontend/nginx.conf:12-19](file://frontend/nginx.conf#L12-L19)

## Verification Steps
To verify a successful installation:
- Confirm the frontend is reachable at http://localhost.
- Verify the backend root endpoint returns a message and version.
- Ensure the frontend can call /api/game endpoints (e.g., talents, start, next-year, summary).
- Check that the Nginx configuration properly serves static assets and proxies API requests.

If the frontend fails to load or API calls fail:
- Confirm the backend service is healthy and listening on port 8000.
- Verify the frontend depends_on backend in Docker Compose.
- Validate the proxy configuration in nginx.conf and Vite proxy settings.

**Section sources**
- [backend/app/main.py:23-25](file://backend/app/main.py#L23-L25)
- [backend/app/router.py:11-15](file://backend/app/router.py#L11-L15)
- [frontend/nginx.conf:12-19](file://frontend/nginx.conf#L12-L19)
- [frontend/vite.config.ts:7-14](file://frontend/vite.config.ts#L7-L14)

## Troubleshooting Guide
Common issues and resolutions:
- Port conflicts:
  - If ports 80 or 8000 are in use on the host, change the port mappings in docker-compose.yml to avoid conflicts.
- CORS errors:
  - The backend enables permissive CORS middleware. If you encounter CORS issues, verify the backend is running and serving the API.
- API proxy not working:
  - Ensure the frontend proxy target matches the backend address. In Docker, the frontend proxies to http://backend:8000; locally, Vite proxies to http://localhost:8000.
- Static assets not loading:
  - Confirm the Nginx configuration copies built assets and that the build completed successfully.
- Backend health checks:
  - Access the backend root endpoint to confirm it responds. If not, inspect logs from the backend container.

**Section sources**
- [docker-compose.yml:6-18](file://docker-compose.yml#L6-L18)
- [backend/app/main.py:12-18](file://backend/app/main.py#L12-L18)
- [frontend/nginx.conf:12-19](file://frontend/nginx.conf#L12-L19)
- [frontend/vite.config.ts:7-14](file://frontend/vite.config.ts#L7-L14)

## Conclusion
You now have the necessary steps to set up the A Little Game development environment locally using Docker Compose. The frontend and backend are orchestrated with clear port mappings and proxy configurations. Use the verification steps to confirm everything is working, and refer to the troubleshooting guide for common issues. For development, you can also run the backend and frontend locally with their respective tools.