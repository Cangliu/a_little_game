# Event Processing Pipeline

<cite>
**Referenced Files in This Document**
- [event_generator.py](file://backend/app/event_generator.py)
- [event_generator_ext.py](file://backend/app/event_generator_ext.py)
- [event_generator_final.py](file://backend/app/event_generator_final.py)
- [event_generator_last.py](file://backend/app/event_generator_last.py)
- [event_generator_mega.py](file://backend/app/event_generator_mega.py)
- [event_generator_ultra.py](file://backend/app/event_generator_ultra.py)
- [game_engine.py](file://backend/app/game_engine.py)
- [models.py](file://backend/app/models.py)
- [router.py](file://backend/app/router.py)
- [talents.py](file://backend/app/talents.py)
- [endings.py](file://backend/app/endings.py)
- [all_events.json](file://backend/app/events/all_events.json)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the event processing pipeline that drives the cultivation life simulator. It covers how events are generated, filtered by conditions, selected using weighted random sampling, and applied to modify player state. It also documents the integration between multiple event generator modules, the condition evaluation system, and the mathematical formulas used for probability and weight adjustments.

## Project Structure
The event processing pipeline spans several modules:
- Event generators: produce thousands of events across categories (common, cultivation, social, fortune, calamity, death, world).
- Game engine: loads events, evaluates conditions, selects events, applies effects, and manages lifecycle.
- Models: define data structures for state, attributes, events, and API responses.
- Router: exposes REST endpoints for game lifecycle.
- Talents and endings: influence event selection and scoring.

```mermaid
graph TB
subgraph "Event Generation"
EG1["event_generator.py"]
EG2["event_generator_ext.py"]
EG3["event_generator_final.py"]
EG4["event_generator_last.py"]
EG5["event_generator_mega.py"]
EG6["event_generator_ultra.py"]
end
subgraph "Event Storage"
EJSON["all_events.json"]
end
subgraph "Game Engine"
GE["game_engine.py"]
MODELS["models.py"]
TALENTS["talents.py"]
ENDINGS["endings.py"]
end
subgraph "API Layer"
ROUTER["router.py"]
MAIN["main.py"]
end
EG1 --> EJSON
EG2 --> EJSON
EG3 --> EJSON
EG4 --> EJSON
EG5 --> EJSON
EG6 --> EJSON
EJSON --> GE
MODELS --> GE
TALENTS --> GE
ENDINGS --> GE
GE --> ROUTER
ROUTER --> MAIN
```

**Diagram sources**
- [event_generator.py:1-879](file://backend/app/event_generator.py#L1-L879)
- [event_generator_ext.py:1-705](file://backend/app/event_generator_ext.py#L1-L705)
- [event_generator_final.py:1-420](file://backend/app/event_generator_final.py#L1-L420)
- [event_generator_last.py:1-166](file://backend/app/event_generator_last.py#L1-L166)
- [event_generator_mega.py:1-314](file://backend/app/event_generator_mega.py#L1-L314)
- [event_generator_ultra.py:1-227](file://backend/app/event_generator_ultra.py#L1-L227)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [endings.py:1-55](file://backend/app/endings.py#L1-L55)

**Section sources**
- [event_generator.py:1-879](file://backend/app/event_generator.py#L1-L879)
- [game_engine.py:15-29](file://backend/app/game_engine.py#L15-L29)
- [router.py:1-69](file://backend/app/router.py#L1-L69)

## Core Components
- Event generators: produce structured events with conditions, weights, effects, and tags. They use combinatorial templates to scale toward 3000+ events.
- Game engine: loads events, filters by conditions, performs weighted random selection, applies effects, checks death/breakthrough, and advances the timeline.
- Models: define typed structures for state, attributes, events, and API responses.
- Router: exposes endpoints to start games, advance years, and fetch summaries.
- Talents: provide attribute bonuses and tags that influence event availability and selection.
- Endings: compute titles and scores based on final state.

**Section sources**
- [event_generator.py:14-800](file://backend/app/event_generator.py#L14-L800)
- [game_engine.py:19-29](file://backend/app/game_engine.py#L19-L29)
- [models.py:48-171](file://backend/app/models.py#L48-L171)
- [router.py:11-69](file://backend/app/router.py#L11-L69)
- [talents.py:3-85](file://backend/app/talents.py#L3-L85)
- [endings.py:29-55](file://backend/app/endings.py#L29-L55)

## Architecture Overview
The pipeline follows a modular design:
- Event generation modules write to a central JSON file.
- The game engine loads events at startup and maintains an in-memory cache.
- Each year, the engine filters eligible events, adjusts weights by attributes, selects events without replacement, and applies effects.

```mermaid
sequenceDiagram
participant Client as "Client"
participant Router as "router.py"
participant Engine as "game_engine.py"
participant Events as "all_events.json"
participant Models as "models.py"
Client->>Router : POST /api/game/start
Router->>Engine : create_game(attributes, talents)
Engine->>Models : apply talent effects to attributes
Engine-->>Router : GameState
Router-->>Client : initial state
loop Yearly cycle
Client->>Router : POST /api/game/next-year
Router->>Engine : advance_year(game_id)
Engine->>Events : load events (cached)
Engine->>Engine : check_event_conditions(event, state)
Engine->>Engine : select_events(state, count)
Engine->>Engine : apply_event_effects(event, state)
Engine->>Engine : check_death(state)
Engine->>Engine : check_realm_breakthrough(state)
Engine-->>Router : NextYearResponse
Router-->>Client : events and state
end
```

**Diagram sources**
- [router.py:18-69](file://backend/app/router.py#L18-L69)
- [game_engine.py:48-394](file://backend/app/game_engine.py#L48-L394)
- [models.py:116-171](file://backend/app/models.py#L116-L171)
- [all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)

## Detailed Component Analysis

### Event Generation Modules
The system uses six generator modules to build a large, diverse event pool:
- Base generator: common life, cultivation stages, social, fortune, calamity, death, and template variations.
- Extended generator: adds meditation insights, combat encounters, pill consumption, skills, social interactions, world lore, special talent-specific events, and miscellaneous flavor.
- Final generator: realm progression flavor, expanded combat, resources, setbacks/recovery, mysterious events, sect daily life, high-realm events, weather combos, time passage, herbs, reputation, and extra death reasons.
- Last generator: gossip, philosophical questions, terrain exploration, idle/rest, creature encounters, books, and more.
- Mega generator: massive combinatorial matrices for combat, meditation, NPC interactions, resource gathering, techniques, auctions, and tribulations.
- Ultra generator: ultra-scale combinatorial coverage to exceed 3000 events.

Key characteristics:
- Each event defines conditions (age, realm, attributes, talents/tags), weight, effects, tags, and event type (normal, important, danger, fortune).
- Combinatorial templates multiply scenarios while maintaining categorization and thematic coherence.

**Section sources**
- [event_generator.py:14-800](file://backend/app/event_generator.py#L14-L800)
- [event_generator_ext.py:11-525](file://backend/app/event_generator_ext.py#L11-L525)
- [event_generator_final.py:11-378](file://backend/app/event_generator_final.py#L11-L378)
- [event_generator_last.py:6-129](file://backend/app/event_generator_last.py#L6-L129)
- [event_generator_mega.py:6-277](file://backend/app/event_generator_mega.py#L6-L277)
- [event_generator_ultra.py:6-189](file://backend/app/event_generator_ultra.py#L6-L189)

### Condition Evaluation System
Events are filtered by a comprehensive set of conditions:
- Age bounds: min_age and max_age.
- Realm bounds: min_realm and max_realm.
- Cultivation threshold: min_cultivation.
- Required talents: required_talents.
- Required tags: required_tags.
- Excluded tags: excluded_tags.
- Minimum attribute thresholds: min_attribute.

The evaluator checks each condition against the current GameState and returns true only if all applicable conditions pass.

```mermaid
flowchart TD
Start(["Evaluate Conditions"]) --> CheckMinAge["Check min_age"]
CheckMinAge --> MinAgeOK{"Age >= min_age?"}
MinAgeOK --> |No| Reject["Reject"]
MinAgeOK --> |Yes| CheckMaxAge["Check max_age"]
CheckMaxAge --> MaxAgeOK{"Age <= max_age?"}
MaxAgeOK --> |No| Reject
MaxAgeOK --> |Yes| CheckMinRealm["Check min_realm"]
CheckMinRealm --> MinRealmOK{"Realm >= min_realm?"}
MinRealmOK --> |No| Reject
MinRealmOK --> |Yes| CheckMaxRealm["Check max_realm"]
CheckMaxRealm --> MaxRealmOK{"Realm <= max_realm?"}
MaxRealmOK --> |No| Reject
MaxRealmOK --> |Yes| CheckMinCult["Check min_cultivation"]
CheckMinCult --> MinCultOK{"Cultivation >= min_cultivation?"}
MinCultOK --> |No| Reject
MinCultOK --> |Yes| CheckTalents["Check required_talents"]
CheckTalents --> HasTalents{"All required talents present?"}
HasTalents --> |No| Reject
HasTalents --> |Yes| CheckTagsReq["Check required_tags"]
CheckTagsReq --> HasTagsReq{"All required tags present?"}
HasTagsReq --> |No| Reject
HasTagsReq --> |Yes| CheckTagsExcl["Check excluded_tags"]
CheckTagsExcl --> HasExcl{"Any excluded tag present?"}
HasExcl --> |Yes| Reject
HasExcl --> |No| CheckMinAttr["Check min_attribute"]
CheckMinAttr --> AttrOK{"All min_attribute thresholds met?"}
AttrOK --> |No| Reject
AttrOK --> |Yes| Accept["Accept"]
```

**Diagram sources**
- [game_engine.py:80-117](file://backend/app/game_engine.py#L80-L117)

**Section sources**
- [game_engine.py:80-117](file://backend/app/game_engine.py#L80-L117)
- [models.py:68-79](file://backend/app/models.py#L68-L79)

### Weighted Random Selection Algorithm
The selection algorithm:
- Filters eligible events using condition evaluation.
- Adjusts weights by player attributes:
  - Fortune increases weight for "fortune" events.
  - Fortune decreases weight for "danger" events.
- Performs weighted selection without replacement:
  - Computes total weight, picks a random value, accumulates weights until reaching/exceeding it, selects the event, and removes it from the pool.

Mathematical formulation:
- Weight adjustment for "fortune" events: $ w_{\text{adj}} = w \times (1 + k_1 \times \text{fortune}) $
- Weight adjustment for "danger" events: $ w_{\text{adj}} = w \times \max(0.5, 1 - k_2 \times \text{fortune}) $
- Selection probability for event $ i $: $ P(i) = \frac{w_i}{\sum w_j} $

Where $ k_1 $ and $ k_2 $ are small positive constants derived from the implementation.

```mermaid
flowchart TD
StartSel(["Select Events"]) --> Filter["Filter eligible events"]
Filter --> CheckEmpty{"Eligible empty?"}
CheckEmpty --> |Yes| Fallback["Return fallback event"]
CheckEmpty --> |No| Adjust["Adjust weights by attributes"]
Adjust --> ComputeTotal["Compute total weight"]
ComputeTotal --> Pick["Pick random value in [0, total)"]
Pick --> Accumulate["Accumulate weights until >= value"]
Accumulate --> SelectOne["Select event and remove from pool"]
SelectOne --> More{"More selections needed?"}
More --> |Yes| ComputeTotal
More --> |No| DoneSel["Return selected events"]
```

**Diagram sources**
- [game_engine.py:256-295](file://backend/app/game_engine.py#L256-L295)

**Section sources**
- [game_engine.py:256-295](file://backend/app/game_engine.py#L256-L295)

### Event Effect Application
Effects are applied to the GameState:
- Attribute modifications: adds/subtracts values to/from attributes (lifespan, constitution, comprehension, fortune, charisma, willpower).
- Tag management: adds or removes tags based on effects.
- Realm progression: increments realm and resets cultivation upon successful breakthrough.
- Death handling: marks the player dead and sets death reason when triggered.

```mermaid
flowchart TD
StartApp(["Apply Effects"]) --> AddCult["Add to cultivation if present"]
AddCult --> ClampCult{"Clamp to >= 0"}
ClampCult --> ApplyAttrs["Apply attribute deltas"]
ApplyAttrs --> Tags["Manage tags (add/remove)"]
Tags --> RealmUp{"Check realm_up?"}
RealmUp --> |Yes| IncrementRealm["Increment realm and reset cultivation"]
RealmUp --> |No| EndApp["Done"]
IncrementRealm --> EndApp
```

**Diagram sources**
- [game_engine.py:119-153](file://backend/app/game_engine.py#L119-L153)

**Section sources**
- [game_engine.py:119-153](file://backend/app/game_engine.py#L119-L153)

### Integration Between Generator Modules
The generators progressively expand the event pool:
- Base generator seeds the pool with thematic categories and variations.
- Extended generator adds more combinatorial depth across domains.
- Final generator introduces flavor and high-realm content.
- Last and Mega generators push the total beyond 3000 events.
- Ultra generator provides ultra-scale coverage.

All generators write to the same central JSON file, which the engine loads once at startup.

```mermaid
graph LR
Base["Base Generator<br/>event_generator.py"] --> Pool["all_events.json"]
Ext["Extended Generator<br/>event_generator_ext.py"] --> Pool
Final["Final Generator<br/>event_generator_final.py"] --> Pool
Last["Last Generator<br/>event_generator_last.py"] --> Pool
Mega["Mega Generator<br/>event_generator_mega.py"] --> Pool
Ultra["Ultra Generator<br/>event_generator_ultra.py"] --> Pool
```

**Diagram sources**
- [event_generator.py:14-800](file://backend/app/event_generator.py#L14-L800)
- [event_generator_ext.py:657-701](file://backend/app/event_generator_ext.py#L657-L701)
- [event_generator_final.py:381-416](file://backend/app/event_generator_final.py#L381-L416)
- [event_generator_last.py:131-162](file://backend/app/event_generator_last.py#L131-L162)
- [event_generator_mega.py:279-310](file://backend/app/event_generator_mega.py#L279-L310)
- [event_generator_ultra.py:192-223](file://backend/app/event_generator_ultra.py#L192-L223)

**Section sources**
- [event_generator_ext.py:657-701](file://backend/app/event_generator_ext.py#L657-L701)
- [event_generator_final.py:381-416](file://backend/app/event_generator_final.py#L381-L416)
- [event_generator_last.py:131-162](file://backend/app/event_generator_last.py#L131-L162)
- [event_generator_mega.py:279-310](file://backend/app/event_generator_mega.py#L279-L310)
- [event_generator_ultra.py:192-223](file://backend/app/event_generator_ultra.py#L192-L223)

### Mathematical Formulas Used
- Weight adjustments:
  - $ w_{\text{adj, fortune}} = w \times (1 + 0.05 \times \text{fortune}) $
  - $ w_{\text{adj, danger}} = w \times \max(0.5, 1 - 0.02 \times \text{fortune}) $
- Death chance (mortals > 30): $ p = k_1 \times \left(\frac{\text{age}}{\text{max\_age}}\right)^2 \times \text{age\_ratio} $
- Death chance (cultivators): $ p = k_2 \times \left(\frac{\text{age}}{\text{max\_age}}\right)^3 \times \text{age\_ratio} \times (1 - 0.03 \times \text{fortune}) $
- Breakthrough chance: $ p = \min(0.85, 0.3 + 0.05 \times \text{comprehension} + 0.03 \times \text{fortune}) $
- Base cultivation gain: $ \text{gain} = 5 + 2 \times \text{comprehension} + \text{constitution} \times (1 + 0.3 \times \text{realm}) $

Where $ k_1 $, $ k_2 $, and $ \text{age\_ratio} $ are derived from the implementation.

**Section sources**
- [game_engine.py:270-279](file://backend/app/game_engine.py#L270-L279)
- [game_engine.py:231-242](file://backend/app/game_engine.py#L231-L242)
- [game_engine.py:174-178](file://backend/app/game_engine.py#L174-L178)
- [game_engine.py:298-308](file://backend/app/game_engine.py#L298-L308)

### API Workflow
The API orchestrates game lifecycle:
- GET /api/game/talents: returns a random talent pool.
- POST /api/game/start: validates attributes and talents, creates a GameState, and returns initial state.
- POST /api/game/next-year: advances one year, selects and applies events, checks death/breakthrough, and returns updated state.
- GET /api/game/summary/{game_id}: returns a life summary with title and score.

```mermaid
sequenceDiagram
participant Client as "Client"
participant Router as "router.py"
participant Engine as "game_engine.py"
Client->>Router : GET /api/game/talents
Router-->>Client : talents
Client->>Router : POST /api/game/start
Router->>Engine : create_game(...)
Engine-->>Router : GameState
Router-->>Client : initial state
loop Yearly advancement
Client->>Router : POST /api/game/next-year
Router->>Engine : advance_year(game_id)
Engine-->>Router : NextYearResponse
Router-->>Client : events and state
end
Client->>Router : GET /api/game/summary/{game_id}
Router->>Engine : get_life_summary(game_id)
Engine-->>Router : LifeSummary
Router-->>Client : summary
```

**Diagram sources**
- [router.py:11-69](file://backend/app/router.py#L11-L69)
- [game_engine.py:48-394](file://backend/app/game_engine.py#L48-L394)

**Section sources**
- [router.py:11-69](file://backend/app/router.py#L11-L69)
- [game_engine.py:48-394](file://backend/app/game_engine.py#L48-L394)

## Dependency Analysis
- Event generators depend on the events directory and write to all_events.json.
- Game engine depends on models, talents, and endings; it loads all_events.json once at import.
- Router depends on game_engine and models.
- No circular dependencies were identified among these modules.

```mermaid
graph TD
EG["event_generator*.py"] --> JSON["all_events.json"]
JSON --> GE["game_engine.py"]
GE --> MODELS["models.py"]
GE --> TALENTS["talents.py"]
GE --> ENDINGS["endings.py"]
GE --> ROUTER["router.py"]
ROUTER --> MAIN["main.py"]
```

**Diagram sources**
- [event_generator.py:10-11](file://backend/app/event_generator.py#L10-L11)
- [game_engine.py:15-29](file://backend/app/game_engine.py#L15-L29)
- [router.py:4](file://backend/app/router.py#L4)

**Section sources**
- [event_generator.py:10-11](file://backend/app/event_generator.py#L10-L11)
- [game_engine.py:15-29](file://backend/app/game_engine.py#L15-L29)
- [router.py:4](file://backend/app/router.py#L4)

## Performance Considerations
- Event loading: all_events.json is loaded once at import and cached in memory for fast access.
- Weighted selection: linear scan over eligible events; acceptable for current scale. For larger pools, consider a binary-indexed tree or alias method for O(log n) selection.
- Attribute-based weight adjustments: constant-time operations per event.
- Death/breakthrough checks: constant-time comparisons and random draws.
- Recommendations:
  - Precompute eligible events per year if the number of events grows substantially.
  - Cache condition evaluations keyed by state snapshot to avoid repeated checks.
  - Use a heap or sorted structure for weighted selection if frequent re-ranking is needed.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- No events selected: Verify conditions are not overly restrictive (age, realm, attributes, talents/tags). The engine falls back to a neutral event when eligible events are empty.
- Unexpected event types: Check event_type modifiers for fortune/danger weights and ensure attributes are within expected ranges.
- Death occurring too early: Review death chance formula and attribute modifiers (fortune reduces death chance).
- Breakthrough not triggering: Confirm cultivation thresholds and breakthrough chance formula; ensure comprehension/fortune are sufficiently high.
- Talent effects missing: Ensure talents are included in the start request and applied during GameState creation.

**Section sources**
- [game_engine.py:262-269](file://backend/app/game_engine.py#L262-L269)
- [game_engine.py:231-242](file://backend/app/game_engine.py#L231-L242)
- [game_engine.py:174-178](file://backend/app/game_engine.py#L174-L178)
- [router.py:18-44](file://backend/app/router.py#L18-L44)

## Conclusion
The event processing pipeline combines modular event generation with robust filtering, weighted selection, and effect application. The system scales efficiently through combinatorial templates and maintains balance via attribute-driven weight adjustments and probabilistic mechanics. By understanding the condition evaluation, selection algorithm, and effect application, developers can optimize event distribution and improve gameplay balance.