# Event Data Models and Structure

<cite>
**Referenced Files in This Document**
- [models.py](file://backend/app/models.py)
- [game_engine.py](file://backend/app/game_engine.py)
- [event_generator.py](file://backend/app/event_generator.py)
- [event_generator_ext.py](file://backend/app/event_generator_ext.py)
- [all_events.json](file://backend/app/events/all_events.json)
- [common.json](file://backend/app/events/common.json)
- [cultivation.json](file://backend/app/events/cultivation.json)
- [social.json](file://backend/app/events/social.json)
- [fortune.json](file://backend/app/events/fortune.json)
- [calamity.json](file://backend/app/events/calamity.json)
- [world.json](file://backend/app/events/world.json)
- [death.json](file://backend/app/events/death.json)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document describes the event data structure and modeling system used in the cultivation life simulator. It defines the JSON schema for event objects, explains the condition system (age, realm, talents, tags, and attribute thresholds), details the effects system (attribute modifications and state changes), documents the tag system for permanent effects and state tracking, and clarifies the event_type classification (normal, fortune, important, danger) and its impact on weighting and player perception. It also covers validation rules, error handling for malformed event data, and the relationship between event data models and the Pydantic models used in the backend. Guidance is included for extending the event schema while maintaining backward compatibility.

## Project Structure
The event system spans two layers:
- Backend data models and runtime logic: Pydantic models define typed structures for events, conditions, effects, and game state. Runtime logic validates eligibility and applies effects.
- Event data files: JSON files define thousands of events grouped by category and merged into a master list.

```mermaid
graph TB
subgraph "Backend Models"
A["models.py<br/>Pydantic models"]
B["game_engine.py<br/>Event selection & application"]
end
subgraph "Event Data"
C["all_events.json<br/>Master list"]
D["common.json"]
E["cultivation.json"]
F["social.json"]
G["fortune.json"]
H["calamity.json"]
I["world.json"]
J["death.json"]
end
A --> B
C --> B
D --> C
E --> C
F --> C
G --> C
H --> C
I --> C
J --> C
```

**Diagram sources**
- [models.py:48-113](file://backend/app/models.py#L48-L113)
- [game_engine.py:80-295](file://backend/app/game_engine.py#L80-L295)
- [all_events.json:1-50802](file://backend/app/events/all_events.json#L1-L50802)
- [common.json:1-3633](file://backend/app/events/common.json#L1-L3633)
- [cultivation.json:1-22088](file://backend/app/events/cultivation.json#L1-L22088)
- [social.json:1-8183](file://backend/app/events/social.json#L1-L8183)
- [fortune.json:1-9512](file://backend/app/events/fortune.json#L1-L9512)
- [calamity.json:1-5603](file://backend/app/events/calamity.json#L1-L5603)
- [world.json:1-1368](file://backend/app/events/world.json#L1-L1368)
- [death.json:1-427](file://backend/app/events/death.json#L1-L427)

**Section sources**
- [models.py:48-113](file://backend/app/models.py#L48-L113)
- [game_engine.py:80-295](file://backend/app/game_engine.py#L80-L295)
- [all_events.json:1-50802](file://backend/app/events/all_events.json#L1-L50802)

## Core Components
This section defines the canonical JSON schema for event objects and the Pydantic models that validate them.

- Event object schema (JSON)
  - id: string, unique identifier
  - text: string, narrative description
  - category: string, grouping (common, cultivation, social, fortune, calamity, world, death)
  - conditions: object, optional gating criteria
  - weight: integer, baseline selection weight
  - effects: object, optional attribute/state changes
  - branches: array of choice branches (optional)
  - tags: array of strings, persistent markers
  - event_type: string, classification (normal, fortune, important, danger)
  - death_reason: string, present for death events (optional)

- Conditions schema (JSON)
  - min_age: integer, inclusive lower bound for age
  - max_age: integer, inclusive upper bound for age
  - min_realm: integer, inclusive lower bound for realm
  - max_realm: integer, inclusive upper bound for realm
  - min_cultivation: integer, inclusive lower bound for cultivation progress
  - required_talents: array of strings, required talent identifiers
  - required_tags: array of strings, required persistent tags
  - excluded_tags: array of strings, disallowed persistent tags
  - min_attribute: object, minimum values per attribute key

- Effects schema (JSON)
  - cultivation: integer, change to cultivation progress
  - lifespan: integer, change to base max age modifier
  - constitution: integer, change to root/survival
  - comprehension: integer, change to learning speed
  - fortune: integer, change to luck
  - charisma: integer, change to social influence
  - willpower: integer, change to resistance/stamina
  - realm_up: boolean, attempt realm advancement
  - add_tag: string, add a persistent tag
  - remove_tag: string, remove a persistent tag
  - death: boolean, terminate life

- Tags system
  - Persistent markers stored in GameState.tags
  - Used for required/excluded conditions and permanent effects
  - Examples: birth, childhood, mortality, sect membership, encounters

- Event types and weighting
  - normal: neutral events
  - fortune: positive events, increase weight by attribute modifiers
  - important: significant events
  - danger: negative events, reduce weight by attribute modifiers
  - Weight is adjusted dynamically based on player attributes and event_type

- Branches (optional)
  - Array of EventBranch entries with text, effects, and result_text
  - Enables branching narrative choices

**Section sources**
- [models.py:68-113](file://backend/app/models.py#L68-L113)
- [game_engine.py:80-115](file://backend/app/game_engine.py#L80-L115)
- [all_events.json:1-50802](file://backend/app/events/all_events.json#L1-L50802)

## Architecture Overview
The event system integrates data-driven events with typed backend models and runtime selection logic.

```mermaid
sequenceDiagram
participant GE as "game_engine.py"
participant DS as "all_events.json"
participant PM as "models.py"
participant GS as "GameState"
GE->>DS : Load master event list
GE->>PM : Validate event against Pydantic models (where applicable)
GE->>GS : Read current state (age, realm, attributes, tags)
GE->>GE : check_event_conditions(event, state)
alt Eligible
GE->>GE : Weight by event_type and attributes
GE->>GE : Select events without replacement
GE->>GS : Apply effects (add/remove tags, modify attributes)
else Not eligible
GE->>GE : Skip or fallback to "nothing" event
end
```

**Diagram sources**
- [game_engine.py:80-295](file://backend/app/game_engine.py#L80-L295)
- [models.py:48-113](file://backend/app/models.py#L48-L113)
- [all_events.json:1-50802](file://backend/app/events/all_events.json#L1-L50802)

## Detailed Component Analysis

### Event Data Schema and Validation
- JSON schema enforcement
  - Backend uses Pydantic models for typed validation of event data structures during development and generation.
  - Runtime selection logic checks conditions and applies effects directly on JSON objects.
- Validation rules
  - Age bounds: min_age and max_age must encompass current age.
  - Realm bounds: min_realm and max_realm must encompass current realm.
  - Cultivation threshold: min_cultivation must be met.
  - Talents/tags: required_talents must be present in GameState.talents; required_tags must be present in GameState.tags; excluded_tags must not be present.
  - Attribute thresholds: min_attribute requires each named attribute to meet or exceed the specified minimum.
- Error handling
  - If no eligible events are found, a safe fallback "nothing" event is returned.
  - Death events are selected separately with explicit termination logic.

**Section sources**
- [models.py:68-113](file://backend/app/models.py#L68-L113)
- [game_engine.py:80-115](file://backend/app/game_engine.py#L80-L115)
- [game_engine.py:256-295](file://backend/app/game_engine.py#L256-L295)

### Condition System
- Age and realm gating
  - min_age/max_age and min_realm/max_realm ensure events occur at appropriate life stages or cultivation levels.
- Cultivation progress gating
  - min_cultivation allows events to require a minimum cultivation threshold.
- Talent and tag gating
  - required_talents ensures only players with specific talents see certain events.
  - required_tags and excluded_tags enable story-driven persistence and restrictions.
- Attribute thresholds
  - min_attribute enables events gated on specific attribute values.

```mermaid
flowchart TD
Start(["Evaluate Event"]) --> CheckAge["Check min_age / max_age"]
CheckAge --> AgeOK{"Within age bounds?"}
AgeOK --> |No| Reject["Reject"]
AgeOK --> |Yes| CheckRealm["Check min_realm / max_realm"]
CheckRealm --> RealmOK{"Within realm bounds?"}
RealmOK --> |No| Reject
RealmOK --> |Yes| CheckCult["Check min_cultivation"]
CheckCult --> CultOK{"Meets cultivation threshold?"}
CultOK --> |No| Reject
CultOK --> |Yes| CheckTalents["Check required_talents"]
CheckTalents --> TalentOK{"Has required talents?"}
TalentOK --> |No| Reject
TalentOK --> |Yes| CheckTags["Check required_tags / excluded_tags"]
CheckTags --> TagsOK{"Meets tag requirements?"}
TagsOK --> |No| Reject
TagsOK --> |Yes| CheckAttrs["Check min_attribute"]
CheckAttrs --> AttrsOK{"Meets attribute thresholds?"}
AttrsOK --> |No| Reject
AttrsOK --> |Yes| Accept["Accept"]
```

**Diagram sources**
- [game_engine.py:80-115](file://backend/app/game_engine.py#L80-L115)

**Section sources**
- [game_engine.py:80-115](file://backend/app/game_engine.py#L80-L115)

### Effects System
- Attribute modifications
  - Direct integer offsets applied to attributes: lifespan, constitution, comprehension, fortune, charisma, willpower.
- Cultivation and progression
  - cultivation modifies progress toward the next realm.
  - realm_up attempts advancement when thresholds are met.
- State changes
  - add_tag and remove_tag manage persistent tags.
  - death terminates the life simulation.
- Weighted selection impact
  - fortune events receive a multiplier based on the fortune attribute.
  - danger events receive a reduction based on the fortune attribute.

```mermaid
flowchart TD
Start(["Apply Event Effects"]) --> HasEffects{"Has effects?"}
HasEffects --> |No| End(["Done"])
HasEffects --> |Yes| ModifyAttrs["Modify attributes (lifespan, constitution, etc.)"]
ModifyAttrs --> ModifyCult["Modify cultivation"]
ModifyCult --> RealmUp{"realm_up?"}
RealmUp --> |Yes| AdvanceRealm["Advance realm if threshold met"]
RealmUp --> |No| Tags["add_tag / remove_tag"]
AdvanceRealm --> Tags
Tags --> Death{"death?"}
Death --> |Yes| Terminate["Set is_dead and death_reason"]
Death --> |No| End
```

**Diagram sources**
- [game_engine.py:256-295](file://backend/app/game_engine.py#L256-L295)
- [models.py:81-94](file://backend/app/models.py#L81-L94)

**Section sources**
- [models.py:81-94](file://backend/app/models.py#L81-L94)
- [game_engine.py:256-295](file://backend/app/game_engine.py#L256-L295)

### Tag System and State Tracking
- Purpose
  - Tags mark persistent story elements, affiliations, and state changes.
- Usage
  - Required/excluded conditions gate visibility and applicability.
  - add_tag/remove_tag in effects update GameState.tags.
- Examples
  - birth, childhood, mortality_life, sect_outer, has_master, encounter tags, etc.

**Section sources**
- [models.py:68-113](file://backend/app/models.py#L68-L113)
- [game_engine.py:80-115](file://backend/app/game_engine.py#L80-L115)

### Event Type Classification and Weighting
- Types
  - normal: neutral events
  - fortune: positive events that increase selection weight
  - important: significant events
  - danger: negative events that decrease selection weight
- Dynamic weighting
  - Weight is multiplied by a factor based on attribute modifiers and event_type.
  - Fortune increases weight; danger decreases weight proportionally to luck.

**Section sources**
- [models.py:103-113](file://backend/app/models.py#L103-L113)
- [game_engine.py:270-280](file://backend/app/game_engine.py#L270-L280)

### Examples of Well-Formed Event Definitions
- Common birth event (normal)
  - id: birth_000
  - text: narrative description
  - category: common
  - conditions: min_age 0, max_age 0
  - weight: 50
  - effects: none
  - tags: ["birth"]
  - event_type: normal

- Childhood event (fortune)
  - id: child_000_age3
  - text: narrative description
  - category: common
  - conditions: min_age 1, max_age 11
  - weight: 40
  - effects: {"fortune": 1}
  - tags: ["childhood"]
  - event_type: fortune

- Cultivation entry event (important)
  - id: cult_entry_002
  - text: narrative description
  - category: cultivation
  - conditions: min_age 8, max_age 30, max_realm 0, required_talents []
  - weight: 30
  - effects: {"add_tag": "sect_outer"}
  - tags: ["cultivation_start"]
  - event_type: important

- Fortune encounter event (fortune)
  - id: fortune_000
  - text: narrative description
  - category: fortune
  - conditions: min_realm 0
  - weight: 35
  - effects: {"cultivation": 40, "comprehension": 2}
  - tags: ["fortune", "encounter"]
  - event_type: fortune

- Danger calamity event (danger)
  - id: calamity_000
  - text: narrative description
  - category: calamity
  - conditions: min_realm 0
  - weight: 25
  - effects: {"willpower": 1, "constitution": -1}
  - tags: ["calamity", "danger"]
  - event_type: danger

- Death event (danger)
  - id: death_000
  - text: narrative description
  - category: death
  - conditions: min_realm 0
  - weight: 10
  - effects: {"death": true}
  - tags: ["death"]
  - event_type: danger
  - death_reason: "寿终正寝"

**Section sources**
- [all_events.json:1-50802](file://backend/app/events/all_events.json#L1-L50802)
- [common.json:1-3633](file://backend/app/events/common.json#L1-L3633)
- [cultivation.json:1-22088](file://backend/app/events/cultivation.json#L1-L22088)
- [fortune.json:1-9512](file://backend/app/events/fortune.json#L1-L9512)
- [calamity.json:1-5603](file://backend/app/events/calamity.json#L1-L5603)
- [death.json:1-427](file://backend/app/events/death.json#L1-L427)

### Patterns and Best Practices
- Age-gated events
  - Use min_age and max_age to anchor events to life stages (e.g., childhood).
- Realm-gated events
  - Use min_realm and max_realm to align events with cultivation progress.
- Attribute-gated events
  - Use min_attribute to create meaningful thresholds (e.g., requiring high constitution for dangerous trials).
- Tag-driven persistence
  - Use add_tag/remove_tag to model long-term story changes (e.g., joining a sect).
- Balanced weighting
  - Adjust weight and event_type to reflect desirability and risk.
- Branching narratives
  - Use branches to offer meaningful choices with distinct outcomes.

**Section sources**
- [models.py:68-113](file://backend/app/models.py#L68-L113)
- [game_engine.py:270-295](file://backend/app/game_engine.py#L270-L295)

### Relationship Between Event Data Models and Pydantic Models
- Pydantic models define strict schemas for typed validation during development and generation.
- Runtime selection logic operates on JSON objects loaded from files, validating conditions and applying effects directly.
- This separation allows flexible authoring of events while preserving type safety for backend structures.

**Section sources**
- [models.py:48-113](file://backend/app/models.py#L48-L113)
- [game_engine.py:80-115](file://backend/app/game_engine.py#L80-L115)

### Extending the Event Schema and Backward Compatibility
- Adding new fields
  - New JSON fields in event objects are ignored by the runtime if not explicitly handled.
  - To integrate new effects, extend the effects schema and update application logic accordingly.
- Maintaining compatibility
  - Keep existing fields unchanged.
  - Avoid renaming or removing required fields.
  - Use optional fields and defaults to preserve older event definitions.
- Validation and generation
  - Use the event generators to produce new events consistently with existing patterns.
  - Merge generated events into category files and the master list.

**Section sources**
- [event_generator.py:1-800](file://backend/app/event_generator.py#L1-L800)
- [event_generator_ext.py:1-705](file://backend/app/event_generator_ext.py#L1-L705)
- [all_events.json:1-50802](file://backend/app/events/all_events.json#L1-L50802)

## Dependency Analysis
The event system exhibits a clean separation of concerns:
- Data files define events and categories.
- Backend models provide typed validation and state representation.
- Runtime engine selects and applies events based on conditions and weights.

```mermaid
graph LR
AE["all_events.json"] --> GE["game_engine.py"]
CMN["common.json"] --> AE
CUL["cultivation.json"] --> AE
SOC["social.json"] --> AE
FOR["fortune.json"] --> AE
CAL["calamity.json"] --> AE
WRLD["world.json"] --> AE
DTH["death.json"] --> AE
MOD["models.py"] --> GE
GE --> ST["GameState"]
```

**Diagram sources**
- [all_events.json:1-50802](file://backend/app/events/all_events.json#L1-L50802)
- [common.json:1-3633](file://backend/app/events/common.json#L1-L3633)
- [cultivation.json:1-22088](file://backend/app/events/cultivation.json#L1-L22088)
- [social.json:1-8183](file://backend/app/events/social.json#L1-L8183)
- [fortune.json:1-9512](file://backend/app/events/fortune.json#L1-L9512)
- [calamity.json:1-5603](file://backend/app/events/calamity.json#L1-L5603)
- [world.json:1-1368](file://backend/app/events/world.json#L1-L1368)
- [death.json:1-427](file://backend/app/events/death.json#L1-L427)
- [models.py:48-129](file://backend/app/models.py#L48-L129)
- [game_engine.py:80-295](file://backend/app/game_engine.py#L80-L295)

**Section sources**
- [models.py:48-129](file://backend/app/models.py#L48-L129)
- [game_engine.py:80-295](file://backend/app/game_engine.py#L80-L295)
- [all_events.json:1-50802](file://backend/app/events/all_events.json#L1-L50802)

## Performance Considerations
- Event selection complexity
  - Selection without replacement involves cumulative weight computation; keep the number of eligible events reasonable.
- Weighted sampling
  - Weight adjustments are computed per event; caching or precomputing modifiers could improve performance for very large sets.
- Memory usage
  - Loading all_events.json into memory is efficient for typical sizes; avoid reloading frequently.

## Troubleshooting Guide
- No eligible events
  - Symptom: Fallback "nothing" event appears.
  - Cause: Conditions too restrictive or attributes/tags not matching.
  - Resolution: Relax conditions or adjust character state.
- Events not triggering
  - Symptom: Expected events do not appear.
  - Causes: Realm/age thresholds, missing required talents/tags, excluded tags, or attribute thresholds.
  - Resolution: Verify conditions and state tags/attributes.
- Death events
  - Symptom: Life ends unexpectedly.
  - Cause: Death events selected based on probability and conditions.
  - Resolution: Review danger events and attribute modifiers affecting selection.
- Weight imbalance
  - Symptom: Too many fortune or danger events.
  - Cause: High fortune attribute or low weight for danger events.
  - Resolution: Adjust attribute modifiers or event weights.

**Section sources**
- [game_engine.py:256-295](file://backend/app/game_engine.py#L256-L295)
- [death.json:1-427](file://backend/app/events/death.json#L1-L427)

## Conclusion
The event data model and system combine a flexible JSON schema with typed backend validation and robust runtime selection logic. Conditions, effects, tags, and event_type classifications work together to create dynamic, personalized experiences. By following the patterns and validation rules outlined here, authors can extend the event database while maintaining backward compatibility and balanced gameplay.