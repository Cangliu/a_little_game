# Event Categories

<cite>
**Referenced Files in This Document**
- [all_events.json](file://backend/app/events/all_events.json)
- [common.json](file://backend/app/events/common.json)
- [calamity.json](file://backend/app/events/calamity.json)
- [fortune.json](file://backend/app/events/fortune.json)
- [social.json](file://backend/app/events/social.json)
- [world.json](file://backend/app/events/world.json)
- [cultivation.json](file://backend/app/events/cultivation.json)
- [death.json](file://backend/app/events/death.json)
- [event_generator.py](file://backend/app/event_generator.py)
- [models.py](file://backend/app/models.py)
- [game_engine.py](file://backend/app/game_engine.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the event category system used by the cultivation life simulator. It covers eight distinct categories—common, calamity, fortune, social, world, cultivation, death, and breakthrough—and describes their characteristics, frequency patterns, thematic roles, and how they shape player engagement and game balance. Examples from each category illustrate typical event text, conditions, and effects, along with guidance on balancing these categories for meaningful gameplay.

## Project Structure
The event system is organized around JSON files grouped by category and a Python generator that builds and validates events. The runtime engine loads these events and applies them according to player state and conditions.

```mermaid
graph TB
subgraph "Events Directory"
ALL["all_events.json"]
COMMON["common.json"]
CALAMITY["calamity.json"]
FORTUNE["fortune.json"]
SOCIAL["social.json"]
WORLD["world.json"]
CULT["cultivation.json"]
DEATH["death.json"]
end
GEN["event_generator.py<br/>Generates and validates events"]
MODELS["models.py<br/>Event schema and types"]
ENGINE["game_engine.py<br/>Loads events and applies effects"]
GEN --> COMMON
GEN --> CALAMITY
GEN --> FORTUNE
GEN --> SOCIAL
GEN --> WORLD
GEN --> CULT
GEN --> DEATH
GEN --> ALL
ENGINE --> ALL
MODELS --> ENGINE
```

**Diagram sources**
- [event_generator.py:832-879](file://backend/app/event_generator.py#L832-L879)
- [models.py:103-114](file://backend/app/models.py#L103-L114)
- [game_engine.py:19-29](file://backend/app/game_engine.py#L19-L29)

**Section sources**
- [event_generator.py:832-879](file://backend/app/event_generator.py#L832-L879)
- [models.py:103-114](file://backend/app/models.py#L103-L114)
- [game_engine.py:19-29](file://backend/app/game_engine.py#L19-L29)

## Core Components
- Event schema: Each event includes id, text, category, conditions, weight, effects, optional branches, tags, and event_type.
- Conditions: Age bounds, realm thresholds, required/excluded tags, and minimum attributes govern when events can trigger.
- Effects: Numeric deltas to attributes, cultivation progress, realm transitions, and special flags (e.g., death).
- Weight: Controls selection probability during event generation.

Key categories and their roles:
- Common: Everyday life events (birth, childhood, aging, mortal life). Forms the backbone of gameplay.
- Calamity: Negative challenges and risks aligned with increasing realm difficulty.
- Fortune: Beneficial opportunities and discoveries.
- Social: Interactions with sects, masters, companions, rivals, and NPCs.
- World: Broader historical and environmental changes affecting the setting.
- Cultivation: Practice, breakthrough attempts, and realm progression.
- Death: Mortality mechanics with cause-of-death metadata.
- Breakthrough: Realm transitions and their outcomes.

**Section sources**
- [models.py:68-114](file://backend/app/models.py#L68-L114)
- [event_generator.py:800-829](file://backend/app/event_generator.py#L800-L829)

## Architecture Overview
The runtime engine loads all events, filters them by conditions, selects candidates by weight, and applies effects to the player state. The generator ensures balanced coverage across categories and realms.

```mermaid
sequenceDiagram
participant Engine as "GameEngine"
participant Loader as "EventLoader"
participant Events as "EventPool"
participant Player as "GameState"
Engine->>Loader : load_events()
Loader->>Events : read all_events.json
Events-->>Loader : list of events
Loader-->>Engine : ALL_EVENTS
Engine->>Engine : filter_by_conditions(event, Player)
Engine->>Engine : select_by_weight(candidates)
Engine->>Engine : apply_event_effects(event, Player)
Engine-->>Player : updated state
```

**Diagram sources**
- [game_engine.py:19-29](file://backend/app/game_engine.py#L19-L29)
- [game_engine.py:80-117](file://backend/app/game_engine.py#L80-L117)
- [game_engine.py:119-153](file://backend/app/game_engine.py#L119-L153)

**Section sources**
- [game_engine.py:19-29](file://backend/app/game_engine.py#L19-L29)
- [game_engine.py:80-117](file://backend/app/game_engine.py#L80-L117)
- [game_engine.py:119-153](file://backend/app/game_engine.py#L119-L153)

## Detailed Component Analysis

### Common Events
- Purpose: Establish baseline life experiences and character origins.
- Frequency pattern: High weight for foundational events; moderate weight for recurring life stages.
- Typical themes: Birth circumstances, childhood milestones, mortal life, aging.
- Example patterns:
  - Birth: Normal, fortune, important, danger variants.
  - Childhood: Fortunate discoveries, minor illnesses, mentor encounters, peer dynamics.
  - Mortal life: Work, marriage, children, seasonal hardships.
  - Aging: Physical decline, legacy, reflection.

Examples from the dataset:
- Birth: “You were born in a remote mountain village...” (normal/fortune/important/danger).
- Childhood: “At age X, you got lost in the mountains...” (fortune), “At age X, you fell ill...” (danger).
- Mortal life: “You worked in the fields...” (normal), “You married...” (fortune).
- Aging: “You feel your strength fading...” (normal), “Your spouse passed away...” (danger).

How they support gameplay:
- Provide narrative grounding and early attribute boosts or setbacks.
- Encourage replayability via age-specific templating.

**Section sources**
- [common.json:1-800](file://backend/app/events/common.json#L1-L800)
- [event_generator.py:14-141](file://backend/app/event_generator.py#L14-L141)

### Calamity Events
- Purpose: Introduce risk, challenge, and meaningful consequences aligned with player realm.
- Frequency pattern: Balanced across difficulties; higher-min_realm events appear later.
- Typical themes: Natural disasters, enemy encounters, internal struggles, forbidden knowledge, celestial wrath.
- Example patterns:
  - Low realm: Bandits, floods, minor heart attacks.
  - Mid realm: Heart attacks, mind corruption, forbidden lands.
  - High realm: Divine retribution, heavenly tribulations, cosmic threats.

Examples from the dataset:
- “A beast attacks the village...” (danger, low realm).
- “You encounter a mad immortal...” (danger, mid realm).
- “Heavenly tribulation strikes...” (danger, high realm).

How they support gameplay:
- Maintain tension and challenge scaling with progression.
- Provide meaningful losses that can reshape strategy.

**Section sources**
- [calamity.json:1-800](file://backend/app/events/calamity.json#L1-L800)
- [event_generator.py:440-479](file://backend/app/event_generator.py#L440-L479)

### Fortune Events
- Purpose: Reward exploration, skill, and luck with tangible benefits.
- Frequency pattern: Decreasing weight with increasing realm difficulty to preserve scarcity.
- Typical themes: Treasures, artifacts, rare techniques, divine boons, prophecies, natural blessings.
- Example patterns:
  - Early: Lost relics, ancient texts, healing herbs.
  - Mid: Celestial rains, bloodline awakening, hidden chambers.
  - Late: Dao insights, primordial essences, time-space anomalies.

Examples from the dataset:
- “You discover an ancient inheritance...” (fortune).
- “A celestial rain showers you...” (fortune).
- “You awaken a primordial power...” (important).

How they support gameplay:
- Reinforce positive playstyles (exploration, persistence).
- Offer meaningful upgrades that accelerate progression.

**Section sources**
- [fortune.json:1-800](file://backend/app/events/fortune.json#L1-L800)
- [event_generator.py:397-437](file://backend/app/event_generator.py#L397-L437)

### Social Events
- Purpose: Drive narrative and relationship mechanics among sects, mentors, companions, rivals, and NPCs.
- Frequency pattern: Moderate weight; often require minimum age/realm.
- Typical themes: Sect politics, master-disciple bonds, romantic entanglements, rivalries, NPC encounters.
- Example patterns:
  - Sect: Selection, trials, conflicts, rewards.
  - Master: Guidance, punishment, gifts, succession.
  - Romance: Attraction, partnership, loss, dual cultivation.
  - Rivalry: Challenges, victories, betrayals, reconciliation.
  - NPC encounters: Gifts, lessons, confrontations, warnings.

Examples from the dataset:
- “You are chosen to represent the sect...” (fortune).
- “Your master gives you a talisman...” (fortune).
- “You meet someone who catches your eye...” (normal).
- “A rival challenges you...” (danger).

How they support gameplay:
- Deepen storytelling and character development.
- Add strategic depth through faction dynamics and personal relationships.

**Section sources**
- [social.json:1-800](file://backend/app/events/social.json#L1-L800)
- [event_generator.py:345-394](file://backend/app/event_generator.py#L345-L394)

### World Events
- Purpose: Reflect macro-level changes in the setting—historical shifts, environmental phenomena, and cultural movements.
- Frequency pattern: Balanced mix of normal and important events.
- Typical themes: Major competitions, artifact discoveries, apocalyptic omens, natural blessings, seasonal influences, lore revelations.
- Example patterns:
  - Macro: Sect wars, legendary artifacts, flying platforms, prophecy fulfillment.
  - Nature: Storms, rainfall, earthquakes, meteor showers, ley line surges.
  - Seasonal: Seasonal cultivation bonuses and hazards.
  - Lore: Historical artifacts, ancient voices, secret maps.

Examples from the dataset:
- “An ancient ruin is discovered...” (normal/important).
- “A celestial omen appears...” (important).
- “A storm brews...” (danger/fortune depending on context).
- “Autumn brings reflection...” (normal/fortune).

How they support gameplay:
- Provide context and stakes beyond the personal.
- Encourage long-term planning and awareness of external forces.

**Section sources**
- [world.json:1-800](file://backend/app/events/world.json#L1-L800)
- [event_generator.py:803-829](file://backend/app/event_generator.py#L803-L829)

### Cultivation Events
- Purpose: Drive progression, practice, and realm transitions.
- Frequency pattern: High density across stages; breakthrough attempts are intentionally lower-weight to reflect risk.
- Typical themes: Qi refining, foundation building, golden core, nascent soul, high realms, daily practice, alchemy, artifacts, sect life, dreams/vision.
- Example patterns:
  - Qi refining: Minor breakthroughs, plateaus, mishaps, mentorship.
  - Foundation: Stabilization, trials, gains, setbacks.
  - Golden Core: Achievements, challenges, resources, doubles.
  - High realms: Grand insights, cosmic trials, legendary deeds.
  - Breakthrough: Attempts with varied outcomes.

Examples from the dataset:
- “Qi refining: You feel your meridians flowing more smoothly...” (normal/fortune).
- “Foundation: You stabilize your core...” (important/fortune).
- “Golden Core: Your core shines with light...” (important).
- “Breakthrough: You attempt to ascend...” (important/danger).

How they support gameplay:
- Define the core progression loop and maintain long-term engagement.
- Balance risk and reward to prevent grinding or stagnation.

**Section sources**
- [cultivation.json:1-800](file://backend/app/events/cultivation.json#L1-L800)
- [event_generator.py:144-342](file://backend/app/event_generator.py#L144-L342)

### Death Events
- Purpose: Enforce mortality mechanics and provide meaningful closure.
- Frequency pattern: Low absolute weight; increasing by realm difficulty to reflect higher stakes.
- Typical themes: Natural causes, accidents, illness, cultivation mishaps, heavenly judgment, war, sacrifice.
- Example patterns:
  - Mortal: Old age, plague, hunger.
  - Cultivator: Breakthrough failure, beast attack, tribulation, theft, collapse, divine punishment, battle, heartbreak, martyrdom, cosmic erasure, sealing duty.

Examples from the dataset:
- “You pass peacefully in your sleep...” (danger, cause: natural).
- “You fall victim to a heavenly tribulation...” (danger, cause: heavenly).
- “You die defending a principle...” (danger, cause: martyrdom).

How they support gameplay:
- Provide narrative stakes and prevent unbounded progression.
- Allow players to reflect on choices and legacies.

**Section sources**
- [death.json:1-427](file://backend/app/events/death.json#L1-L427)
- [event_generator.py:482-520](file://backend/app/event_generator.py#L482-L520)

### Breakthrough Events
- Purpose: Represent realm transitions and define major milestones.
- Frequency pattern: Very low weight per attempt; success chance depends on attributes and realm.
- Typical themes: Effort, luck, external interference, heavenly response.
- Example patterns:
  - Attempt: Success, near-success, failure, interruption, heavenly backlash.
  - Outcome: Automatic realm-up or reset with penalties.

Examples from the dataset:
- “You attempt to break through Qi Refining...” (important/danger).
- Engine handles success/failure dynamically.

How they support gameplay:
- Create epic moments and define pacing.
- Balance RNG with meaningful stats.

**Section sources**
- [event_generator.py:647-671](file://backend/app/event_generator.py#L647-L671)
- [game_engine.py:166-200](file://backend/app/game_engine.py#L166-L200)

## Dependency Analysis
- Event schema and types are defined centrally and consumed by the generator and engine.
- The generator produces category-specific JSON files and a combined pool.
- The engine loads the combined pool, filters by conditions, and applies effects.

```mermaid
graph LR
MODELS["models.py<br/>Event schema"] --> GEN["event_generator.py<br/>Generates events"]
GEN --> COMMON["common.json"]
GEN --> CALAMITY["calamity.json"]
GEN --> FORTUNE["fortune.json"]
GEN --> SOCIAL["social.json"]
GEN --> WORLD["world.json"]
GEN --> CULT["cultivation.json"]
GEN --> DEATH["death.json"]
GEN --> ALL["all_events.json"]
ENGINE["game_engine.py<br/>Loads and applies events"] --> ALL
ENGINE --> MODELS
```

**Diagram sources**
- [models.py:103-114](file://backend/app/models.py#L103-L114)
- [event_generator.py:832-879](file://backend/app/event_generator.py#L832-L879)
- [game_engine.py:19-29](file://backend/app/game_engine.py#L19-L29)

**Section sources**
- [models.py:103-114](file://backend/app/models.py#L103-L114)
- [event_generator.py:832-879](file://backend/app/event_generator.py#L832-L879)
- [game_engine.py:19-29](file://backend/app/game_engine.py#L19-L29)

## Performance Considerations
- Event filtering and selection: Keep condition checks efficient; avoid scanning the entire pool repeatedly.
- Weight normalization: Ensure weights remain reasonable to prevent extreme skewing.
- Category balance: Maintain appropriate ratios across categories to sustain long-term engagement.
- Memory footprint: Loading all_events.json is acceptable for current scale; consider pagination if growth demands.

## Troubleshooting Guide
Common issues and resolutions:
- Event never triggers:
  - Verify conditions (age, realm, required tags, excluded tags, attribute thresholds).
  - Confirm weight is not negligible compared to others.
- Unexpected attribute changes:
  - Inspect effects fields and confirm they target intended attributes.
- Breakthrough not occurring:
  - Check realm thresholds and player’s cultivation progress.
  - Review success chance calculation and attribute modifiers.
- Death occurs too often:
  - Adjust calamity weights and realm thresholds.
  - Consider introducing protective tags or talents that reduce risk.

**Section sources**
- [game_engine.py:80-117](file://backend/app/game_engine.py#L80-L117)
- [game_engine.py:119-153](file://backend/app/game_engine.py#L119-L153)
- [game_engine.py:166-200](file://backend/app/game_engine.py#L166-L200)

## Conclusion
The event category system creates a layered, scalable experience: common events ground the story, fortune and social events enrich the world, calamity maintains challenge, cultivation events define progression, world events broaden scope, death enforces stakes, and breakthroughs mark milestones. Together, they balance engagement, meaning, and long-term replayability.