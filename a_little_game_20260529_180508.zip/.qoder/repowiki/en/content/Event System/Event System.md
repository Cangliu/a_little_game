# Event System

<cite>
**Referenced Files in This Document**
- [event_generator.py](file://backend/app/event_generator.py)
- [all_events.json](file://backend/app/events/all_events.json)
- [common.json](file://backend/app/events/common.json)
- [calamity.json](file://backend/app/events/calamity.json)
- [fortune.json](file://backend/app/events/fortune.json)
- [social.json](file://backend/app/events/social.json)
- [world.json](file://backend/app/events/world.json)
- [cultivation.json](file://backend/app/events/cultivation.json)
- [death.json](file://backend/app/events/death.json)
- [game_engine.py](file://backend/app/game_engine.py)
- [models.py](file://backend/app/models.py)
- [router.py](file://backend/app/router.py)
- [talents.py](file://backend/app/talents.py)
- [endings.py](file://backend/app/endings.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction

The event system is the core dynamic mechanism that drives the cultivation life simulator's narrative progression and player engagement. It generates thousands of unique events across eight distinct categories, each with carefully balanced weighted probability distributions and conditional triggering mechanisms. The system seamlessly integrates with player attributes, talents, and cultivation realms to create personalized gameplay experiences while maintaining mathematical balance and difficulty progression.

This system transforms static game mechanics into a living, breathing narrative that evolves based on player choices, attributes, and cultivation progress. Events serve as both storytelling devices and meaningful gameplay decisions, affecting everything from daily life to major breakthrough moments and ultimate fate.

## Project Structure

The event system follows a modular JSON-based architecture with Python-based event generation and processing:

```mermaid
graph TB
subgraph "Event Generation Layer"
EG[event_generator.py]
EV[Event Templates]
end
subgraph "Storage Layer"
AJ[all_events.json]
CJ[common.json]
FJ[fortune.json]
SJ[social.json]
WJ[world.json]
CBJ[cultivation.json]
DJ[death.json]
EJ[calamity.json]
end
subgraph "Processing Layer"
GE[game_engine.py]
MD[models.py]
TL[talents.py]
end
subgraph "API Layer"
RT[router.py]
EN[endings.py]
end
EG --> EV
EV --> AJ
AJ --> GE
CJ --> GE
FJ --> GE
SJ --> GE
WJ --> GE
CBJ --> GE
DJ --> GE
EJ --> GE
TL --> GE
GE --> RT
GE --> EN
```

**Diagram sources**
- [event_generator.py:1-879](file://backend/app/event_generator.py#L1-L879)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [models.py:1-171](file://backend/app/models.py#L1-L171)

**Section sources**
- [event_generator.py:1-879](file://backend/app/event_generator.py#L1-L879)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [models.py:1-171](file://backend/app/models.py#L1-L171)

## Core Components

### Event Categories and Distribution

The system defines eight primary event categories, each serving distinct narrative and gameplay purposes:

| Category | Purpose | Event Count | Weight Range |
|----------|---------|-------------|--------------|
| **Common** | Daily life, coming-of-age, mortality | ~3,633 events | 30-60 weight |
| **Fortune** | Luck-based encounters, treasures, discoveries | ~9,512 events | 20-35 weight |
| **Calamity** | Dangers, disasters, setbacks, deaths | ~5,603 events | 20-25 weight |
| **Social** | Interactions with others, relationships, conflicts | ~8,183 events | 25-40 weight |
| **World** | Major world events, historical moments | ~1,368 events | 20-35 weight |
| **Cultivation** | Practice, breakthroughs, realm transitions | ~22,088 events | 15-60 weight |
| **Death** | Various causes of death, mortality | ~427 events | 8-10 weight |
| **Breakthrough** | Realm advancement, skill improvements | ~1,200+ events | 15-25 weight |

### Conditional Triggering System

Events utilize sophisticated conditional logic that evaluates multiple factors:

```mermaid
flowchart TD
Start([Event Evaluation]) --> CheckAge["Check Age Conditions<br/>min_age/max_age"]
CheckAge --> CheckRealm["Check Realm Conditions<br/>min_realm/max_realm"]
CheckRealm --> CheckAttributes["Check Attribute Requirements<br/>min_attribute"]
CheckAttributes --> CheckTalents["Check Required Talents<br/>required_talents"]
CheckTalents --> CheckTags["Check Tag Conditions<br/>required_tags/excluded_tags"]
CheckTags --> CheckCultivation["Check Cultivation Level<br/>min_cultivation"]
CheckCultivation --> Eligible{"Eligible?"}
Eligible --> |Yes| WeightCalc["Calculate Weight<br/>Base × Modifier"]
Eligible --> |No| Skip[Skip Event]
WeightCalc --> Select[Weighted Selection]
Select --> Apply[Apply Effects]
Apply --> End([Event Complete])
```

**Diagram sources**
- [game_engine.py:80-116](file://backend/app/game_engine.py#L80-L116)

### Weighted Probability Algorithm

The system implements a sophisticated weighted selection algorithm that considers multiple modifiers:

```mermaid
sequenceDiagram
participant Player as Player State
participant Engine as Game Engine
participant Event as Event Pool
participant Selector as Weighted Selector
Player->>Engine : Request Events
Engine->>Event : Filter Eligible Events
Event-->>Engine : Eligible Events List
Engine->>Selector : Calculate Weights
Selector->>Selector : Apply Fortune Modifier
Selector->>Selector : Apply Danger Modifier
Selector->>Selector : Apply Event Type Bias
Selector->>Selector : Normalize Weights
Selector-->>Engine : Weighted Event Pool
Engine->>Selector : Select Random Event
Selector-->>Engine : Selected Event
Engine->>Player : Apply Event Effects
```

**Diagram sources**
- [game_engine.py:256-295](file://backend/app/game_engine.py#L256-L295)

**Section sources**
- [event_generator.py:14-879](file://backend/app/event_generator.py#L14-L879)
- [game_engine.py:80-116](file://backend/app/game_engine.py#L80-L116)
- [game_engine.py:256-295](file://backend/app/game_engine.py#L256-L295)

## Architecture Overview

The event system architecture demonstrates a clean separation of concerns with clear data flow:

```mermaid
graph TB
subgraph "Data Layer"
A[JSON Event Definitions]
B[Template Generation]
C[Weight Calculation]
end
subgraph "Logic Layer"
D[Condition Evaluation]
E[Weighted Selection]
F[Effect Application]
end
subgraph "Integration Layer"
G[Attribute System]
H[Talent System]
I[Cultivation System]
J[Realm System]
end
subgraph "Presentation Layer"
K[API Responses]
L[Event Logging]
M[Progress Tracking]
end
A --> B
B --> C
C --> D
D --> E
E --> F
G --> D
H --> D
I --> D
J --> D
F --> G
F --> H
F --> I
F --> J
F --> K
F --> L
F --> M
```

**Diagram sources**
- [models.py:48-171](file://backend/app/models.py#L48-L171)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)

**Section sources**
- [models.py:48-171](file://backend/app/models.py#L48-L171)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)

## Detailed Component Analysis

### Event Generation Pipeline

The event generation system creates comprehensive coverage across all categories:

#### Common Events
Common events form the backbone of daily life progression, covering birth, childhood, adulthood, and aging phases. These events establish narrative foundations and character development arcs.

#### Cultivation Events
Cultivation events represent the core gameplay loop, with specialized events for each of the nine cultivation realms plus breakthrough mechanics. The system ensures appropriate challenge scaling through realm-based weighting.

#### Social Events
Social interactions drive relationship mechanics and world-building, featuring master-disciple dynamics, romantic storylines, rivalries, and organizational politics.

#### Fortune and Calamity Events
These complementary systems provide narrative balance through positive and negative life experiences, with weighted distributions that reflect the game's difficulty progression.

### Conditional Triggering Mechanisms

The condition evaluation system implements comprehensive filtering:

```mermaid
classDiagram
class EventCondition {
+int min_age
+int max_age
+int min_realm
+int max_realm
+int min_cultivation
+list required_talents
+list required_tags
+list excluded_tags
+dict min_attribute
}
class GameState {
+int age
+int realm
+int cultivation
+Attributes attributes
+list talents
+list tags
}
class EventEffect {
+int cultivation
+int lifespan
+int constitution
+int comprehension
+int fortune
+int charisma
+int willpower
+bool realm_up
+string add_tag
+string remove_tag
+bool death
}
GameState --> EventCondition : "evaluates against"
EventCondition --> GameState : "filters events"
EventEffect --> GameState : "applies to"
```

**Diagram sources**
- [models.py:68-94](file://backend/app/models.py#L68-L94)
- [models.py:116-129](file://backend/app/models.py#L116-L129)

### Weighted Selection Algorithm

The selection algorithm implements sophisticated probability mathematics:

#### Base Weight Calculation
Each event maintains a base weight representing its intrinsic probability. The system applies modifiers based on player state and event type:

- **Fortune Events**: Enhanced by player fortune attribute (1.05× per fortune point)
- **Danger Events**: Reduced by player fortune attribute (0.98× per fortune point)
- **Event Type Bias**: Normal events receive neutral weighting, while important and fortune events gain slight advantages

#### Selection Process
The algorithm performs weighted random selection without replacement, ensuring diverse yearly experiences while maintaining statistical balance.

**Section sources**
- [game_engine.py:256-295](file://backend/app/game_engine.py#L256-L295)
- [models.py:68-94](file://backend/app/models.py#L68-L94)

### Effect Application Logic

The effect application system handles complex state modifications:

```mermaid
flowchart TD
Start([Event Triggered]) --> ParseEffects["Parse Event Effects"]
ParseEffects --> CheckType{"Effect Type"}
CheckType --> |Attribute| ApplyAttr["Apply Attribute Changes<br/>+/- values to stats"]
CheckType --> |Cultivation| ApplyCult["Apply Cultivation Changes<br/>+/- values to progress"]
CheckType --> |Tag| ManageTags["Manage Tags<br/>add/remove special markers"]
CheckType --> |Realm| CheckBreakthrough["Check Realm Up<br/>threshold progression"]
CheckType --> |Death| MarkDeath["Mark Player Dead<br/>set death reason"]
ApplyAttr --> ValidateState["Validate State Bounds"]
ApplyCult --> ValidateState
ManageTags --> ValidateState
CheckBreakthrough --> ValidateState
MarkDeath --> ValidateState
ValidateState --> End([Effects Applied])
```

**Diagram sources**
- [game_engine.py:119-153](file://backend/app/game_engine.py#L119-L153)

### Integration with Player Attributes and Talents

The system integrates deeply with player characteristics:

#### Attribute Influence
- **Fortune**: Increases chance of beneficial events, decreases chance of dangerous events
- **Comprehension**: Enhances breakthrough probabilities and learning opportunities
- **Constitution**: Affects physical resilience and longevity
- **Willpower**: Provides resistance to mental challenges and tribulations
- **Charisma**: Influences social interactions and relationship outcomes
- **Lifespan**: Extends maximum playable age and affects mortality risk

#### Talent Integration
Talents modify base attributes and provide special tags that unlock unique events. The system supports:
- **Special Body Types**: Enhanced cultivation speeds and resistances
- **Elemental Affinities**: Realm-specific bonuses and event unlocks
- **Destiny Traits**: Increased luck and survival capabilities
- **Proficiency Skills**: Enhanced abilities in specific areas

**Section sources**
- [game_engine.py:119-153](file://backend/app/game_engine.py#L119-L153)
- [talents.py:1-85](file://backend/app/talents.py#L1-L85)

### Modular JSON-Based Design

The system employs a flexible JSON-based architecture:

#### Event Definition Schema
Each event follows a standardized structure:
- **id**: Unique identifier for tracking and debugging
- **text**: Narrative description displayed to players
- **category**: Event classification for filtering
- **conditions**: Triggering requirements and filters
- **weight**: Base probability weight
- **effects**: Stat changes and state modifications
- **tags**: Additional categorization for advanced filtering
- **event_type**: Normal, important, danger, or fortune classification

#### Extensibility Patterns
The modular design enables easy expansion:
- **New Categories**: Add JSON files and update generation scripts
- **Event Variations**: Template-based generation for combinatorial growth
- **Conditional Logic**: Flexible requirement systems for complex scenarios
- **Integration Points**: Clear interfaces for new mechanics and systems

**Section sources**
- [models.py:103-114](file://backend/app/models.py#L103-L114)
- [event_generator.py:523-879](file://backend/app/event_generator.py#L523-L879)

## Dependency Analysis

The event system demonstrates excellent modularity with clear dependency relationships:

```mermaid
graph TB
subgraph "Core Dependencies"
GE[game_engine.py]
MD[models.py]
TL[talents.py]
EN[endings.py]
end
subgraph "Event Data"
AJ[all_events.json]
CJ[common.json]
FJ[fortune.json]
SJ[social.json]
WJ[world.json]
CBJ[cultivation.json]
DJ[death.json]
EJ[calamity.json]
end
subgraph "Generation Scripts"
EG[event_generator.py]
end
subgraph "API Layer"
RT[router.py]
end
EG --> AJ
AJ --> GE
CJ --> GE
FJ --> GE
SJ --> GE
WJ --> GE
CBJ --> GE
DJ --> GE
EJ --> GE
TL --> GE
GE --> RT
EN --> GE
MD --> GE
```

**Diagram sources**
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [router.py:1-69](file://backend/app/router.py#L1-L69)

**Section sources**
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [router.py:1-69](file://backend/app/router.py#L1-L69)

## Performance Considerations

The event system implements several optimization strategies:

### Memory Management
- **Lazy Loading**: Events loaded on-demand rather than at startup
- **In-Memory Caching**: Loaded events cached for subsequent requests
- **Efficient Filtering**: Pre-computed eligibility checks minimize repeated calculations

### Computational Efficiency
- **Weighted Selection**: Optimized random selection algorithm with O(n) complexity
- **Condition Caching**: Frequently accessed conditions cached for reuse
- **Batch Processing**: Multiple events processed in single operation calls

### Scalability Features
- **Template-Based Generation**: Reduces manual JSON maintenance overhead
- **Modular Architecture**: Easy addition of new event types and categories
- **Configurable Weights**: Dynamic adjustment of event probabilities

## Troubleshooting Guide

### Common Issues and Solutions

#### Event Not Triggering
**Symptoms**: Expected events never appear in selections
**Causes**: 
- Age/realm conditions not met
- Required talents/tags missing
- Attribute requirements unmet
- Excessive fortune attribute reducing chances

**Solutions**:
- Verify player state meets all conditions
- Check talent/tag requirements
- Review attribute modifiers
- Adjust fortune attribute for desired event frequency

#### Weight Imbalance
**Symptoms**: Too many good/bad events
**Causes**: 
- Incorrect weight assignments
- Attribute modifiers skewing probabilities
- Event type bias overwhelming selection

**Solutions**:
- Review weight distributions per category
- Adjust attribute modifiers
- Fine-tune event type weights
- Test with different player builds

#### Performance Degradation
**Symptoms**: Slow event processing
**Causes**:
- Large event pools causing filtering overhead
- Complex condition evaluations
- Memory leaks in state management

**Solutions**:
- Optimize condition evaluation order
- Implement caching for frequently accessed events
- Monitor memory usage and garbage collection
- Consider event pool partitioning

**Section sources**
- [game_engine.py:80-116](file://backend/app/game_engine.py#L80-L116)
- [game_engine.py:256-295](file://backend/app/game_engine.py#L256-L295)

## Conclusion

The event system represents a sophisticated implementation of dynamic narrative generation for the cultivation life simulator. Its modular JSON-based architecture, combined with Python-based processing logic, creates a scalable and maintainable framework for generating thousands of unique gameplay experiences.

The system's strength lies in its mathematical precision and narrative balance. Through carefully tuned weighted probability distributions, comprehensive conditional triggering mechanisms, and deep integration with player attributes and talents, it creates meaningful choices that feel both random and purposeful.

The modular design ensures extensibility for future content additions, while the performance optimizations maintain responsiveness even with large event pools. This foundation provides an excellent platform for continued expansion and refinement of the cultivation simulation experience.

Key achievements include:
- Comprehensive coverage of eight distinct event categories
- Sophisticated weighted selection algorithms
- Deep integration with player progression systems
- Flexible JSON-based extensibility
- Performance-optimized processing pipeline
- Mathematical balance across difficulty progression

The system successfully transforms static game mechanics into a living narrative that adapts to player choices, creating unique and memorable cultivation journeys for each player.