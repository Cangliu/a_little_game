# Component Interactions

<cite>
**Referenced Files in This Document**
- [backend/app/main.py](file://backend/app/main.py)
- [backend/app/router.py](file://backend/app/router.py)
- [backend/app/game_engine.py](file://backend/app/game_engine.py)
- [backend/app/models.py](file://backend/app/models.py)
- [backend/app/talents.py](file://backend/app/talents.py)
- [backend/app/endings.py](file://backend/app/endings.py)
- [backend/app/events/all_events.json](file://backend/app/events/all_events.json)
- [frontend/src/App.tsx](file://frontend/src/App.tsx)
- [frontend/src/utils/api.ts](file://frontend/src/utils/api.ts)
- [frontend/src/pages/CharacterCreation.tsx](file://frontend/src/pages/CharacterCreation.tsx)
- [frontend/src/pages/GameScreen.tsx](file://frontend/src/pages/GameScreen.tsx)
- [frontend/src/pages/StartScreen.tsx](file://frontend/src/pages/StartScreen.tsx)
- [frontend/src/pages/SummaryScreen.tsx](file://frontend/src/pages/SummaryScreen.tsx)
- [frontend/src/utils/types.ts](file://frontend/src/utils/types.ts)
- [docker-compose.yml](file://docker-compose.yml)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains how A Little Game coordinates interactions between the frontend React application and the backend FastAPI service. It covers the request-response flow from React components through the API gateway to backend endpoints, then to the game engine and event systems. It also documents state management patterns, including in-memory game state synchronization, real-time updates via API polling, and component state propagation. Integration patterns between frontend screens (StartScreen, CharacterCreation, GameScreen, SummaryScreen) and backend services (talent selection, game progression, event processing) are detailed. Sequence diagrams illustrate typical user workflows such as character creation, year advancement, and game completion. Error handling strategies, retry mechanisms, and state consistency guarantees across component boundaries are addressed.

## Project Structure
The project is split into two primary parts:
- Backend: FastAPI application exposing REST endpoints for game lifecycle and state management.
- Frontend: React application managing UI phases and asynchronous interactions with the backend.

```mermaid
graph TB
subgraph "Frontend"
FE_App["App.tsx"]
FE_Start["StartScreen.tsx"]
FE_Char["CharacterCreation.tsx"]
FE_Game["GameScreen.tsx"]
FE_Summary["SummaryScreen.tsx"]
FE_API["utils/api.ts"]
FE_Types["utils/types.ts"]
end
subgraph "Backend"
BE_Main["app/main.py"]
BE_Router["app/router.py"]
BE_GameEngine["app/game_engine.py"]
BE_Models["app/models.py"]
BE_Talents["app/talents.py"]
BE_Endings["app/endings.py"]
BE_Events["app/events/all_events.json"]
end
subgraph "Deployment"
Compose["docker-compose.yml"]
end
FE_Start --> FE_App
FE_Char --> FE_App
FE_Game --> FE_App
FE_Summary --> FE_App
FE_App --> FE_API
FE_API --> BE_Main
BE_Main --> BE_Router
BE_Router --> BE_GameEngine
BE_GameEngine --> BE_Models
BE_GameEngine --> BE_Talents
BE_GameEngine --> BE_Endings
BE_GameEngine --> BE_Events
Compose --> FE_App
Compose --> BE_Main
```

**Diagram sources**
- [frontend/src/App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)
- [frontend/src/pages/StartScreen.tsx:1-193](file://frontend/src/pages/StartScreen.tsx#L1-L193)
- [frontend/src/pages/CharacterCreation.tsx:1-249](file://frontend/src/pages/CharacterCreation.tsx#L1-L249)
- [frontend/src/pages/GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [frontend/src/pages/SummaryScreen.tsx:1-177](file://frontend/src/pages/SummaryScreen.tsx#L1-L177)
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [frontend/src/utils/types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)
- [backend/app/main.py:1-26](file://backend/app/main.py#L1-L26)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [backend/app/models.py:1-171](file://backend/app/models.py#L1-L171)
- [backend/app/talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [backend/app/endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [backend/app/events/all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)

**Section sources**
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)
- [backend/app/main.py:1-26](file://backend/app/main.py#L1-L26)
- [frontend/src/App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)

## Core Components
- Frontend Application State and Navigation:
  - App orchestrates phases: start, character creation, playing, summary.
  - Manages game ID, initial attributes, and talents propagated to GameScreen.
- API Layer:
  - Provides typed wrappers for fetching talents, starting games, advancing years, and retrieving summaries.
- Backend Router:
  - Exposes endpoints for talent pool retrieval, game start, year advancement, and life summary.
- Game Engine:
  - Maintains in-memory GameState keyed by game_id.
  - Implements event selection, death checks, cultivation gains, realm breakthroughs, and end-of-life summary generation.
- Data Models:
  - Pydantic models define request/response shapes and constants for realms, thresholds, and attributes.
- Talents and Events:
  - Talent definitions and weighted pools.
  - Extensive event catalog loaded at runtime for dynamic storytelling.

Key implementation references:
- [App state transitions and handlers:11-50](file://frontend/src/App.tsx#L11-L50)
- [API functions for backend calls:5-56](file://frontend/src/utils/api.ts#L5-L56)
- [Router endpoints:11-68](file://backend/app/router.py#L11-L68)
- [Game engine state store and logic:31-424](file://backend/app/game_engine.py#L31-L424)
- [Models and constants:7-171](file://backend/app/models.py#L7-L171)
- [Talent pool generation:51-84](file://backend/app/talents.py#L51-L84)
- [Event catalog:1-200](file://backend/app/events/all_events.json#L1-L200)

**Section sources**
- [frontend/src/App.tsx:11-50](file://frontend/src/App.tsx#L11-L50)
- [frontend/src/utils/api.ts:5-56](file://frontend/src/utils/api.ts#L5-L56)
- [backend/app/router.py:11-68](file://backend/app/router.py#L11-L68)
- [backend/app/game_engine.py:31-424](file://backend/app/game_engine.py#L31-L424)
- [backend/app/models.py:7-171](file://backend/app/models.py#L7-L171)
- [backend/app/talents.py:51-84](file://backend/app/talents.py#L51-L84)
- [backend/app/events/all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)

## Architecture Overview
The system follows a client-server pattern:
- Frontend React components render UI and drive user actions.
- API requests are sent to the backend FastAPI server.
- Backend validates inputs, consults the game engine, and returns structured responses.
- Game engine maintains in-memory state and applies deterministic rules for events and progression.
- Real-time updates are achieved via polling (API polling) rather than server-sent events or WebSockets.

```mermaid
graph TB
FE["React Components<br/>StartScreen, CharacterCreation, GameScreen, SummaryScreen"]
API["Frontend API<br/>utils/api.ts"]
GW["FastAPI Router<br/>app/router.py"]
GE["Game Engine<br/>app/game_engine.py"]
MEM["In-Memory State Store<br/>GAME_STATES"]
MODELS["Models & Constants<br/>app/models.py"]
TALENTS["Talents<br/>app/talents.py"]
ENDINGS["Endings & Titles<br/>app/endings.py"]
EVENTS["Events Catalog<br/>app/events/all_events.json"]
FE --> API
API --> GW
GW --> GE
GE --> MEM
GE --> MODELS
GE --> TALENTS
GE --> ENDINGS
GE --> EVENTS
```

**Diagram sources**
- [frontend/src/pages/StartScreen.tsx:1-193](file://frontend/src/pages/StartScreen.tsx#L1-L193)
- [frontend/src/pages/CharacterCreation.tsx:1-249](file://frontend/src/pages/CharacterCreation.tsx#L1-L249)
- [frontend/src/pages/GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [frontend/src/pages/SummaryScreen.tsx:1-177](file://frontend/src/pages/SummaryScreen.tsx#L1-L177)
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [backend/app/models.py:1-171](file://backend/app/models.py#L1-L171)
- [backend/app/talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [backend/app/endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [backend/app/events/all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)

## Detailed Component Analysis

### Request-Response Flow: Character Creation to Game Start
This sequence shows how the frontend collects attributes and talents, requests a new game, and transitions to the playing screen.

```mermaid
sequenceDiagram
participant User as "User"
participant Start as "StartScreen.tsx"
participant Char as "CharacterCreation.tsx"
participant API as "utils/api.ts"
participant Router as "router.py"
participant Engine as "game_engine.py"
User->>Start : Click "Start"
Start->>Char : Navigate to CharacterCreation
Char->>API : fetchTalents()
API->>Router : GET /api/game/talents
Router->>Engine : get_random_talents()
Engine-->>Router : talents[]
Router-->>API : {talents}
API-->>Char : talents[]
User->>Char : Adjust attributes and select talents
Char->>API : startGame(attributes, talents)
API->>Router : POST /api/game/start
Router->>Engine : create_game(attributes, talents)
Engine-->>Router : GameState snapshot
Router-->>API : {game_id, age, realm, attributes, talents, ...}
API-->>Char : result
Char->>Start : onConfirm(result)
Start->>Game : Transition to GameScreen with gameId
```

**Diagram sources**
- [frontend/src/pages/StartScreen.tsx:173-178](file://frontend/src/pages/StartScreen.tsx#L173-L178)
- [frontend/src/pages/CharacterCreation.tsx:30-76](file://frontend/src/pages/CharacterCreation.tsx#L30-L76)
- [frontend/src/utils/api.ts:5-34](file://frontend/src/utils/api.ts#L5-L34)
- [backend/app/router.py:11-44](file://backend/app/router.py#L11-L44)
- [backend/app/game_engine.py:48-77](file://backend/app/game_engine.py#L48-L77)

**Section sources**
- [frontend/src/pages/CharacterCreation.tsx:30-76](file://frontend/src/pages/CharacterCreation.tsx#L30-L76)
- [frontend/src/utils/api.ts:5-34](file://frontend/src/utils/api.ts#L5-L34)
- [backend/app/router.py:11-44](file://backend/app/router.py#L11-L44)
- [backend/app/game_engine.py:48-77](file://backend/app/game_engine.py#L48-L77)

### Year Advancement Workflow: Polling-Based Updates
The GameScreen advances the year by polling the backend. It updates local state and reacts to game-ending conditions.

```mermaid
sequenceDiagram
participant User as "User"
participant Game as "GameScreen.tsx"
participant API as "utils/api.ts"
participant Router as "router.py"
participant Engine as "game_engine.py"
User->>Game : Click "Next Year" or Auto mode
Game->>API : nextYear(gameId)
API->>Router : POST /api/game/next-year
Router->>Engine : advance_year(game_id)
Engine->>Engine : check_death(), process_cultivation_gain(), select_events()
Engine->>Engine : check_realm_breakthrough()
Engine-->>Router : NextYearResponse
Router-->>API : NextYearResponse
API-->>Game : result
Game->>Game : Update age, realm, attributes, events
alt Game Over (dead or ascended)
Game->>Game : Set isGameOver, trigger onGameEnd(gameId)
else Continue
Game->>Game : Optionally continue auto-play
end
```

**Diagram sources**
- [frontend/src/pages/GameScreen.tsx:40-65](file://frontend/src/pages/GameScreen.tsx#L40-L65)
- [frontend/src/utils/api.ts:36-47](file://frontend/src/utils/api.ts#L36-L47)
- [backend/app/router.py:47-58](file://backend/app/router.py#L47-L58)
- [backend/app/game_engine.py:311-393](file://backend/app/game_engine.py#L311-L393)

**Section sources**
- [frontend/src/pages/GameScreen.tsx:40-65](file://frontend/src/pages/GameScreen.tsx#L40-L65)
- [frontend/src/utils/api.ts:36-47](file://frontend/src/utils/api.ts#L36-L47)
- [backend/app/router.py:47-58](file://backend/app/router.py#L47-L58)
- [backend/app/game_engine.py:311-393](file://backend/app/game_engine.py#L311-L393)

### Game Completion and Summary Retrieval
After the game ends, the SummaryScreen fetches the life summary and displays the title, stats, and key events.

```mermaid
sequenceDiagram
participant Game as "GameScreen.tsx"
participant API as "utils/api.ts"
participant Router as "router.py"
participant Engine as "game_engine.py"
participant Endings as "endings.py"
Game->>Game : isGameOver true
Game->>API : getSummary(gameId)
API->>Router : GET /api/game/summary/{game_id}
Router->>Engine : get_life_summary(game_id)
Engine->>Engine : Build events log, compute score
Engine->>Endings : get_title(), calculate_score()
Engine-->>Router : LifeSummary
Router-->>API : LifeSummary
API-->>Game : summary
Game->>Summary : Render SummaryScreen with summary
```

**Diagram sources**
- [frontend/src/pages/GameScreen.tsx:53-56](file://frontend/src/pages/GameScreen.tsx#L53-L56)
- [frontend/src/pages/SummaryScreen.tsx:16-21](file://frontend/src/pages/SummaryScreen.tsx#L16-L21)
- [frontend/src/utils/api.ts:49-56](file://frontend/src/utils/api.ts#L49-L56)
- [backend/app/router.py:61-68](file://backend/app/router.py#L61-L68)
- [backend/app/game_engine.py:396-423](file://backend/app/game_engine.py#L396-L423)
- [backend/app/endings.py:29-54](file://backend/app/endings.py#L29-L54)

**Section sources**
- [frontend/src/pages/SummaryScreen.tsx:16-21](file://frontend/src/pages/SummaryScreen.tsx#L16-L21)
- [frontend/src/utils/api.ts:49-56](file://frontend/src/utils/api.ts#L49-L56)
- [backend/app/router.py:61-68](file://backend/app/router.py#L61-L68)
- [backend/app/game_engine.py:396-423](file://backend/app/game_engine.py#L396-L423)
- [backend/app/endings.py:29-54](file://backend/app/endings.py#L29-L54)

### State Management Patterns
- In-Memory Game State Synchronization:
  - The backend maintains a dictionary keyed by game_id to store current GameState snapshots. This enables deterministic, fast lookups and updates during year advancement.
  - The frontend holds minimal transient state (current age, realm, attributes, events) and refreshes it via API polling.
- Real-Time Updates via API Polling:
  - GameScreen polls the backend on user action or auto-play cycles. The backend returns a NextYearResponse reflecting the latest state.
  - Auto-play toggles a flag and schedules the next call after a short delay, creating a smooth progression effect.
- Component State Propagation:
  - App manages phase transitions and passes game metadata (gameId, initial attributes, talents) down to GameScreen.
  - SummaryScreen receives the game_id and fetches the final LifeSummary for rendering.

References:
- [In-memory state store:31-32](file://backend/app/game_engine.py#L31-L32)
- [Polling in GameScreen:40-65](file://frontend/src/pages/GameScreen.tsx#L40-L65)
- [App state and navigation:11-50](file://frontend/src/App.tsx#L11-L50)

**Section sources**
- [backend/app/game_engine.py:31-32](file://backend/app/game_engine.py#L31-L32)
- [frontend/src/pages/GameScreen.tsx:40-65](file://frontend/src/pages/GameScreen.tsx#L40-L65)
- [frontend/src/App.tsx:11-50](file://frontend/src/App.tsx#L11-L50)

### Integration Patterns
- Frontend-to-Backend Contracts:
  - Typed interfaces define request/response shapes, ensuring consistent serialization/deserialization across fetch calls.
  - Example: StartGameRequest, NextYearResponse, LifeSummary.
- Talent Selection:
  - Backend provides a randomized talent pool; frontend allows users to pick up to three talents and randomize distribution.
- Event Processing:
  - Backend loads events from JSON and applies conditions/effects based on current GameState, including attribute modifiers, tags, and realm transitions.
- End-of-Life Summary:
  - Backend computes a title and score based on final attributes and age; frontend renders the summary with key events.

References:
- [Typed models:48-171](file://backend/app/models.py#L48-L171)
- [Talent pool:51-84](file://backend/app/talents.py#L51-L84)
- [Events catalog:1-200](file://backend/app/events/all_events.json#L1-L200)
- [Endings and scoring:29-54](file://backend/app/endings.py#L29-L54)

**Section sources**
- [backend/app/models.py:48-171](file://backend/app/models.py#L48-L171)
- [backend/app/talents.py:51-84](file://backend/app/talents.py#L51-L84)
- [backend/app/events/all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)
- [backend/app/endings.py:29-54](file://backend/app/endings.py#L29-L54)

## Dependency Analysis
- Frontend Dependencies:
  - App.tsx depends on pages and utils for navigation and API calls.
  - Pages depend on utils/api.ts for network operations and utils/types.ts for type safety.
- Backend Dependencies:
  - Router depends on game_engine for business logic and models for request/response schemas.
  - Game engine depends on models, talents, endings, and events for state computation and storytelling.
- Coupling and Cohesion:
  - Strong cohesion within router and game engine modules; low coupling to external services (only JSON events).
  - Minimal circular dependencies; clear separation of concerns.

```mermaid
graph LR
FE_API["utils/api.ts"] --> BE_Router["router.py"]
FE_App["App.tsx"] --> FE_API
FE_Char["CharacterCreation.tsx"] --> FE_API
FE_Game["GameScreen.tsx"] --> FE_API
FE_Summary["SummaryScreen.tsx"] --> FE_API
BE_Router --> BE_GameEngine["game_engine.py"]
BE_GameEngine --> BE_Models["models.py"]
BE_GameEngine --> BE_Talents["talents.py"]
BE_GameEngine --> BE_Endings["endings.py"]
BE_GameEngine --> BE_Events["events/all_events.json"]
```

**Diagram sources**
- [frontend/src/App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [frontend/src/pages/CharacterCreation.tsx:1-249](file://frontend/src/pages/CharacterCreation.tsx#L1-L249)
- [frontend/src/pages/GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [frontend/src/pages/SummaryScreen.tsx:1-177](file://frontend/src/pages/SummaryScreen.tsx#L1-L177)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [backend/app/models.py:1-171](file://backend/app/models.py#L1-L171)
- [backend/app/talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [backend/app/endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [backend/app/events/all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)

**Section sources**
- [frontend/src/App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [backend/app/models.py:1-171](file://backend/app/models.py#L1-L171)
- [backend/app/talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [backend/app/endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [backend/app/events/all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)

## Performance Considerations
- In-Memory State Store:
  - Using a dictionary keyed by game_id ensures O(1) lookup and update costs for GameState. This minimizes latency for year advancement.
- Event Loading:
  - Events are loaded once at module import time, reducing repeated I/O overhead during gameplay.
- Frontend Polling:
  - Short delays between auto-play ticks prevent excessive network load while maintaining responsiveness.
- Recommendations:
  - Consider rate-limiting auto-play and adding jitter to polling intervals to avoid thundering herd effects under high concurrency.
  - For future scaling, introduce Redis-backed sessions and background workers to offload long-running computations.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
- Common Errors and Handling:
  - Validation errors on game start (attribute totals, talent limits) return HTTP 400 with a detail message. The frontend surfaces a user-friendly alert.
  - Missing game_id on year advancement returns HTTP 400; the frontend stops auto-play and logs the error.
  - Game not found or already ended returns HTTP 404; the frontend halts further polling and navigates to summary.
- Retry Mechanisms:
  - The frontend does not implement automatic retries. On failure, it logs the error and disables auto-play. Users can retry manually.
- State Consistency Guarantees:
  - Backend enforces immutability of inputs via Pydantic models and validates preconditions before state mutation.
  - In-memory state is updated atomically per year; concurrent requests for the same game_id are serialized by the single-threaded nature of the development server. For production, deploy behind a WSGI server and consider database-backed state.

References:
- [Validation and error handling in router:21-30](file://backend/app/router.py#L21-L30)
- [Error handling in API wrappers:29-32](file://frontend/src/utils/api.ts#L29-L32)
- [Game over checks:317-318](file://backend/app/game_engine.py#L317-L318)

**Section sources**
- [backend/app/router.py:21-30](file://backend/app/router.py#L21-L30)
- [frontend/src/utils/api.ts:29-32](file://frontend/src/utils/api.ts#L29-L32)
- [backend/app/game_engine.py:317-318](file://backend/app/game_engine.py#L317-L318)

## Conclusion
A Little Game integrates a React frontend with a FastAPI backend through a clean, typed API contract. The backend’s in-memory state store and deterministic event system provide a responsive, story-driven experience. Frontend components manage navigation and polling-based updates, while backend endpoints encapsulate game logic and data modeling. The documented flows and patterns enable maintainable extensions, such as adding choice events, integrating persistence, or introducing real-time updates.