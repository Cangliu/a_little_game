# Architecture Overview

<cite>
**Referenced Files in This Document**
- [backend/app/main.py](file://backend/app/main.py)
- [backend/app/router.py](file://backend/app/router.py)
- [backend/app/game_engine.py](file://backend/app/game_engine.py)
- [backend/app/models.py](file://backend/app/models.py)
- [backend/app/talents.py](file://backend/app/talents.py)
- [backend/app/endings.py](file://backend/app/endings.py)
- [backend/app/events/all_events.json](file://backend/app/events/all_events.json)
- [frontend/src/App.tsx](file://frontend/src/App.tsx)
- [frontend/src/utils/api.ts](file://frontend/src/utils/api.ts)
- [frontend/src/pages/CharacterCreation.tsx](file://frontend/src/pages/CharacterCreation.tsx)
- [frontend/src/pages/GameScreen.tsx](file://frontend/src/pages/GameScreen.tsx)
- [docker-compose.yml](file://docker-compose.yml)
- [Dockerfile.backend](file://Dockerfile.backend)
- [Dockerfile.frontend](file://Dockerfile.frontend)
- [frontend/nginx.conf](file://frontend/nginx.conf)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document describes the full-stack architecture of A Little Game, a cultivation-themed life simulator. The system separates the frontend (React SPA) from the backend (FastAPI) and orchestrates them via Docker Compose with Nginx as an API gateway and reverse proxy. The backend implements an in-memory game engine that simulates lifetimes year-by-year, driven by a large event catalog and deterministic rules. Cross-cutting concerns include CORS configuration, error handling, and a pragmatic state management strategy centered on in-memory storage with optional persistence hooks.

## Project Structure
The repository is organized into:
- backend: FastAPI application with routing, game engine, models, and event catalogs
- frontend: React SPA with TypeScript, pages, and utilities for API communication
- docker-compose.yml: Multi-service orchestration for frontend, backend, and Nginx
- Dockerfiles: Build and run images for backend and frontend/Nginx

```mermaid
graph TB
subgraph "Frontend (React SPA)"
FE_App["App.tsx"]
FE_API["utils/api.ts"]
FE_Creation["pages/CharacterCreation.tsx"]
FE_Game["pages/GameScreen.tsx"]
end
subgraph "Nginx Gateway"
NGINX["nginx.conf"]
end
subgraph "Backend (FastAPI)"
BE_Main["app/main.py"]
BE_Router["app/router.py"]
BE_Engine["app/game_engine.py"]
BE_Models["app/models.py"]
BE_Talents["app/talents.py"]
BE_Endings["app/endings.py"]
BE_Events["app/events/all_events.json"]
end
FE_App --> FE_API
FE_API --> NGINX
NGINX --> BE_Router
BE_Router --> BE_Engine
BE_Engine --> BE_Models
BE_Engine --> BE_Talents
BE_Engine --> BE_Endings
BE_Engine --> BE_Events
```

**Diagram sources**
- [frontend/src/App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [frontend/src/pages/CharacterCreation.tsx:1-249](file://frontend/src/pages/CharacterCreation.tsx#L1-L249)
- [frontend/src/pages/GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [frontend/nginx.conf:1-27](file://frontend/nginx.conf#L1-L27)
- [backend/app/main.py:1-26](file://backend/app/main.py#L1-L26)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [backend/app/models.py:1-171](file://backend/app/models.py#L1-L171)
- [backend/app/talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [backend/app/endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [backend/app/events/all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)

**Section sources**
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)
- [Dockerfile.backend:1-8](file://Dockerfile.backend#L1-L8)
- [Dockerfile.frontend:1-13](file://Dockerfile.frontend#L1-L13)
- [frontend/nginx.conf:1-27](file://frontend/nginx.conf#L1-L27)

## Core Components
- Frontend (React SPA)
  - App.tsx manages game phases and state transitions
  - utils/api.ts encapsulates API calls to the backend
  - CharacterCreation.tsx handles attribute distribution and talent selection
  - GameScreen.tsx drives the interactive year-by-year simulation
- Backend (FastAPI)
  - main.py configures CORS and mounts the router
  - router.py defines endpoints for talents, starting games, advancing years, and summaries
  - game_engine.py implements the core simulation, state management, and event processing
  - models.py defines Pydantic models for requests, responses, and game state
  - talents.py and endings.py define static data and scoring logic
  - events/all_events.json is the centralized event catalog loaded at runtime

Key implementation patterns:
- API gateway pattern via Nginx proxying /api/* to the backend service
- In-memory state management for concurrent game sessions
- Real-time simulation architecture: client-triggered year advances, server-side deterministic computation
- Event-driven design: weighted event selection conditioned on state and attributes

**Section sources**
- [frontend/src/App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [frontend/src/pages/CharacterCreation.tsx:1-249](file://frontend/src/pages/CharacterCreation.tsx#L1-L249)
- [frontend/src/pages/GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [backend/app/main.py:1-26](file://backend/app/main.py#L1-L26)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [backend/app/models.py:1-171](file://backend/app/models.py#L1-L171)
- [backend/app/talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [backend/app/endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [backend/app/events/all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)

## Architecture Overview
The system follows a classic full-stack separation:
- Frontend: React SPA served by Nginx, communicates with the backend via REST endpoints under /api/game
- Backend: FastAPI microservice exposing game APIs and hosting the simulation engine
- Infrastructure: Docker Compose runs three containers (frontend, backend, Nginx) on the same host network

```mermaid
graph TB
Client["Browser (React SPA)"] --> Nginx["Nginx Reverse Proxy"]
Nginx --> FastAPI["FastAPI Backend"]
FastAPI --> Engine["Game Engine (in-memory state)"]
Engine --> Events["Event Catalog (JSON)"]
Engine --> Models["Pydantic Models"]
Engine --> Talents["Static Talents"]
Engine --> Endings["Static Endings & Titles"]
subgraph "Docker Orchestration"
F["frontend:80"]
B["backend:8000"]
P["nginx.conf:80 -> backend:8000"]
end
Client --> Nginx
Nginx --> FastAPI
F --> P
B --> FastAPI
```

**Diagram sources**
- [frontend/nginx.conf:1-27](file://frontend/nginx.conf#L1-L27)
- [backend/app/main.py:1-26](file://backend/app/main.py#L1-L26)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [backend/app/models.py:1-171](file://backend/app/models.py#L1-L171)
- [backend/app/talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [backend/app/endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [backend/app/events/all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)

## Detailed Component Analysis

### API Gateway and Routing
- Nginx serves static assets and proxies /api/* to the backend service
- CORS is configured in FastAPI to accept all origins for development
- The router exposes:
  - GET /api/game/talents: random talent pool for character creation
  - POST /api/game/start: validates attributes and talents, creates a new game session
  - POST /api/game/next-year: advances simulation by one year
  - GET /api/game/summary/{game_id}: computes final life summary

```mermaid
sequenceDiagram
participant Browser as "Browser"
participant Nginx as "Nginx"
participant API as "FastAPI Router"
participant Engine as "Game Engine"
Browser->>Nginx : "GET /api/game/talents"
Nginx->>API : "Proxy to /api/game/talents"
API->>Engine : "Load talent pool"
Engine-->>API : "Return talent list"
API-->>Nginx : "JSON talents"
Nginx-->>Browser : "200 OK"
Browser->>Nginx : "POST /api/game/start {attributes, talents}"
Nginx->>API : "Proxy to /api/game/start"
API->>Engine : "create_game(...)"
Engine-->>API : "GameState snapshot"
API-->>Nginx : "JSON game state"
Nginx-->>Browser : "200 OK"
Browser->>Nginx : "POST /api/game/next-year {game_id}"
Nginx->>API : "Proxy to /api/game/next-year"
API->>Engine : "advance_year(game_id)"
Engine-->>API : "NextYearResponse"
API-->>Nginx : "JSON events + state"
Nginx-->>Browser : "200 OK"
```

**Diagram sources**
- [frontend/nginx.conf:12-19](file://frontend/nginx.conf#L12-L19)
- [backend/app/router.py:11-68](file://backend/app/router.py#L11-L68)
- [backend/app/game_engine.py:48-77](file://backend/app/game_engine.py#L48-L77)
- [backend/app/game_engine.py:311-393](file://backend/app/game_engine.py#L311-L393)

**Section sources**
- [frontend/nginx.conf:12-19](file://frontend/nginx.conf#L12-L19)
- [backend/app/main.py:12-18](file://backend/app/main.py#L12-L18)
- [backend/app/router.py:11-68](file://backend/app/router.py#L11-L68)

### State Management and Simulation Engine
- In-memory state store keyed by game_id
- Deterministic yearly progression with weighted event selection
- Attribute and tag effects applied per event
- Realm breakthrough checks and ascension detection
- Death checks based on max age and modifiers

```mermaid
flowchart TD
Start(["advance_year(game_id)"]) --> Lookup["Lookup GameState by game_id"]
Lookup --> Found{"Found and active?"}
Found --> |No| Error["Raise 404 Not Found"]
Found --> |Yes| CheckDead["Check is_dead/is_ascended"]
CheckDead --> Dead{"Already ended?"}
Dead --> |Yes| Error
Dead --> |No| AgeInc["state.age += 1"]
AgeInc --> DeathCheck["check_death(state)"]
DeathCheck --> Died{"Died this year?"}
Died --> |Yes| RecordDeath["Record death event<br/>Set is_dead"]
Died --> |No| Gain["process_cultivation_gain(state)"]
Gain --> AddCult["state.cultivation += gain"]
AddCult --> Select["select_events(state, count)"]
Select --> Apply["apply_event_effects(event)"]
Apply --> Breakthrough["check_realm_breakthrough(state)"]
Breakthrough --> Ascended{"Ascended?"}
Ascended --> |Yes| ReturnAsc["Return is_ascended=true"]
Ascended --> |No| ReturnNormal["Return NextYearResponse"]
```

**Diagram sources**
- [backend/app/game_engine.py:311-393](file://backend/app/game_engine.py#L311-L393)
- [backend/app/game_engine.py:207-253](file://backend/app/game_engine.py#L207-L253)
- [backend/app/game_engine.py:298-308](file://backend/app/game_engine.py#L298-L308)
- [backend/app/game_engine.py:256-295](file://backend/app/game_engine.py#L256-L295)
- [backend/app/game_engine.py:166-204](file://backend/app/game_engine.py#L166-L204)

**Section sources**
- [backend/app/game_engine.py:31-45](file://backend/app/game_engine.py#L31-L45)
- [backend/app/game_engine.py:311-393](file://backend/app/game_engine.py#L311-L393)

### Data Models and Types
- Pydantic models define request/response contracts and internal state
- Enums and constants for realms, names, and thresholds
- Talents and endings are static datasets consumed by the engine

```mermaid
classDiagram
class Attributes {
+int lifespan
+int constitution
+int comprehension
+int fortune
+int charisma
+int willpower
}
class GameState {
+string game_id
+int age
+int realm
+int cultivation
+Attributes attributes
+string[] talents
+string[] tags
+list events_log
+bool is_dead
+string death_reason
+bool is_ascended
}
class NextYearResponse {
+int age
+int realm
+string realm_name
+int cultivation
+int cultivation_max
+list events
+Attributes attributes
+bool is_dead
+string death_reason
+bool is_ascended
}
class LifeSummary {
+int total_age
+int max_realm
+string max_realm_name
+string death_reason
+list key_events
+list talents
+Attributes final_attributes
+int score
+string title
}
GameState --> Attributes : "has"
NextYearResponse --> Attributes : "has"
LifeSummary --> Attributes : "has"
```

**Diagram sources**
- [backend/app/models.py:48-171](file://backend/app/models.py#L48-L171)

**Section sources**
- [backend/app/models.py:1-171](file://backend/app/models.py#L1-L171)

### Frontend-Backend Interaction
- App.tsx coordinates game phases and passes game_id/state to child components
- CharacterCreation.tsx fetches talents and allows attribute/talent selection
- GameScreen.tsx polls the backend for yearly updates and renders events
- utils/api.ts centralizes endpoint calls and error handling

```mermaid
sequenceDiagram
participant App as "App.tsx"
participant Creation as "CharacterCreation.tsx"
participant Game as "GameScreen.tsx"
participant API as "utils/api.ts"
participant Router as "router.py"
participant Engine as "game_engine.py"
App->>Creation : "Render character creation"
Creation->>API : "fetchTalents()"
API->>Router : "GET /api/game/talents"
Router->>Engine : "Load talent pool"
Engine-->>Router : "List"
Router-->>API : "JSON talents"
API-->>Creation : "talents"
Creation->>API : "startGame(attributes, talents)"
API->>Router : "POST /api/game/start"
Router->>Engine : "create_game(...)"
Engine-->>Router : "GameState"
Router-->>API : "JSON game snapshot"
API-->>App : "game_id, state"
App->>Game : "Render game screen with game_id"
loop Yearly
Game->>API : "nextYear(game_id)"
API->>Router : "POST /api/game/next-year"
Router->>Engine : "advance_year(game_id)"
Engine-->>Router : "NextYearResponse"
Router-->>API : "JSON events + state"
API-->>Game : "events + state"
Game-->>Game : "Update UI"
end
```

**Diagram sources**
- [frontend/src/App.tsx:28-44](file://frontend/src/App.tsx#L28-L44)
- [frontend/src/pages/CharacterCreation.tsx:30-36](file://frontend/src/pages/CharacterCreation.tsx#L30-L36)
- [frontend/src/pages/GameScreen.tsx:40-65](file://frontend/src/pages/GameScreen.tsx#L40-L65)
- [frontend/src/utils/api.ts:5-56](file://frontend/src/utils/api.ts#L5-L56)
- [backend/app/router.py:18-44](file://backend/app/router.py#L18-L44)
- [backend/app/router.py:47-68](file://backend/app/router.py#L47-L68)
- [backend/app/game_engine.py:48-77](file://backend/app/game_engine.py#L48-L77)
- [backend/app/game_engine.py:311-393](file://backend/app/game_engine.py#L311-L393)

**Section sources**
- [frontend/src/App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)
- [frontend/src/pages/CharacterCreation.tsx:1-249](file://frontend/src/pages/CharacterCreation.tsx#L1-L249)
- [frontend/src/pages/GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)

## Dependency Analysis
- Frontend depends on utils/api.ts for backend communication
- Backend depends on router.py for endpoint exposure and game_engine.py for simulation logic
- game_engine.py depends on models.py for typed state, talents.py for static data, endings.py for scoring, and events/all_events.json for dynamic events
- docker-compose.yml ties frontend, backend, and Nginx together with port mappings and inter-service networking

```mermaid
graph LR
FE_API["frontend/src/utils/api.ts"] --> BE_ROUTER["backend/app/router.py"]
FE_APP["frontend/src/App.tsx"] --> FE_API
FE_CREATION["frontend/src/pages/CharacterCreation.tsx"] --> FE_API
FE_GAME["frontend/src/pages/GameScreen.tsx"] --> FE_API
BE_ROUTER --> BE_ENGINE["backend/app/game_engine.py"]
BE_ENGINE --> BE_MODELS["backend/app/models.py"]
BE_ENGINE --> BE_TALENTS["backend/app/talents.py"]
BE_ENGINE --> BE_ENDINGS["backend/app/endings.py"]
BE_ENGINE --> BE_EVENTS["backend/app/events/all_events.json"]
DOCKER["docker-compose.yml"] --> FE_NGINX["frontend/nginx.conf"]
DOCKER --> BE_MAIN["backend/app/main.py"]
```

**Diagram sources**
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [backend/app/models.py:1-171](file://backend/app/models.py#L1-L171)
- [backend/app/talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [backend/app/endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [backend/app/events/all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)
- [frontend/nginx.conf:1-27](file://frontend/nginx.conf#L1-L27)
- [backend/app/main.py:1-26](file://backend/app/main.py#L1-L26)
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)

**Section sources**
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)

## Performance Considerations
- In-memory state management
  - Pros: low latency, simple deployment
  - Cons: no persistence across restarts, limited horizontal scaling
- Event catalog size
  - The event catalog is preloaded and large; consider lazy-loading or pagination if memory becomes a concern
- Concurrency model
  - Single-process Python app; for multiple concurrent sessions, consider process/thread scaling or state sharding/persistence
- Network and caching
  - Nginx static asset caching and proxy headers improve throughput
- Recommendations
  - Add Redis/Memcached for shared state and horizontal scaling
  - Implement rate limiting and circuit breakers at the API gateway
  - Use asynchronous workers for long-running tasks (e.g., batch summaries)

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
- CORS errors
  - Verify allow_origins configuration in FastAPI matches the frontend origin
- 404 Not Found on /api/game/next-year or summary
  - Ensure game_id is valid and session not ended (dead/ascended)
- 400 Bad Request on /api/game/start
  - Validate total attribute points ≤ 20 and ≤ 3 talents selected
- Frontend fetch failures
  - Confirm Nginx proxy_pass targets the backend service and port
- State not persisting across restarts
  - Expected behavior for in-memory store; implement persistence layer if required

**Section sources**
- [backend/app/main.py:12-18](file://backend/app/main.py#L12-L18)
- [backend/app/router.py:21-30](file://backend/app/router.py#L21-L30)
- [backend/app/router.py:54-58](file://backend/app/router.py#L54-L58)
- [frontend/nginx.conf:12-19](file://frontend/nginx.conf#L12-L19)

## Conclusion
A Little Game employs a clean full-stack separation with a React SPA fronted by Nginx and a FastAPI backend running an in-memory simulation engine. The architecture is straightforward, containerized, and suitable for small to medium-scale deployments. For production, consider adding persistence, horizontal scaling, and enhanced observability while preserving the event-driven simulation model.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Deployment Topology
- Services
  - frontend: Nginx serving static assets and proxying /api/*
  - backend: FastAPI app exposing game endpoints
  - backend relies on mounted volumes for event JSON and internal state
- Ports
  - frontend: 80 (mapped to container 80)
  - backend: 8000 (mapped to container 8000)
- Environment
  - PYTHONUNBUFFERED=1 for stdout logging

**Section sources**
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)
- [Dockerfile.backend:1-8](file://Dockerfile.backend#L1-L8)
- [Dockerfile.frontend:1-13](file://Dockerfile.frontend#L1-L13)
- [frontend/nginx.conf:1-27](file://frontend/nginx.conf#L1-L27)