# Data Flow Architecture

<cite>
**Referenced Files in This Document**
- [backend/app/models.py](file://backend/app/models.py)
- [frontend/src/utils/types.ts](file://frontend/src/utils/types.ts)
- [backend/app/main.py](file://backend/app/main.py)
- [backend/app/router.py](file://backend/app/router.py)
- [frontend/src/utils/api.ts](file://frontend/src/utils/api.ts)
- [backend/app/game_engine.py](file://backend/app/game_engine.py)
- [backend/app/talents.py](file://backend/app/talents.py)
- [backend/app/endings.py](file://backend/app/endings.py)
- [backend/app/events/all_events.json](file://backend/app/events/all_events.json)
- [frontend/src/pages/CharacterCreation.tsx](file://frontend/src/pages/CharacterCreation.tsx)
- [frontend/src/pages/GameScreen.tsx](file://frontend/src/pages/GameScreen.tsx)
- [frontend/src/App.tsx](file://frontend/src/App.tsx)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document describes the complete data flow architecture of A Little Game, focusing on how user input is transformed and validated through frontend and backend systems, how the backend processes state transitions, and how results are serialized and returned to the frontend for reactive updates. It covers:
- Frontend TypeScript interfaces and React state management
- Backend Pydantic models and JSON serialization/deserialization
- Validation strategies and error propagation
- Immutable state changes on the backend and their reflection in frontend updates
- Data transformations across attributes, talents, events, and cultivation progressions

## Project Structure
The project follows a clear separation of concerns:
- Frontend (React + TypeScript) handles user input, local state, and UI rendering
- Backend (FastAPI + Python) manages immutable game state, event processing, and persistence via in-memory storage
- Shared data contracts are defined in both frontend and backend models

```mermaid
graph TB
subgraph "Frontend"
FE_API["api.ts<br/>HTTP client"]
FE_TYPES["types.ts<br/>TypeScript interfaces"]
FE_CREATION["CharacterCreation.tsx<br/>Attribute/Talent selection"]
FE_GAME["GameScreen.tsx<br/>Year advancement & event log"]
FE_APP["App.tsx<br/>Routing & phase management"]
end
subgraph "Backend"
BE_MAIN["main.py<br/>FastAPI app"]
BE_ROUTER["router.py<br/>Routes & validation"]
BE_MODELS["models.py<br/>Pydantic models"]
BE_ENGINE["game_engine.py<br/>State machine & events"]
BE_TALENTS["talents.py<br/>Talent pool"]
BE_ENDINGS["endings.py<br/>Titles & scoring"]
BE_EVENTS["events/all_events.json<br/>Event catalog"]
end
FE_CREATION --> FE_API
FE_GAME --> FE_API
FE_APP --> FE_CREATION
FE_APP --> FE_GAME
FE_API --> BE_MAIN
BE_MAIN --> BE_ROUTER
BE_ROUTER --> BE_ENGINE
BE_ROUTER --> BE_TALENTS
BE_ROUTER --> BE_MODELS
BE_ENGINE --> BE_MODELS
BE_ENGINE --> BE_EVENTS
BE_ENGINE --> BE_ENDINGS
```

**Diagram sources**
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [frontend/src/utils/types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)
- [frontend/src/pages/CharacterCreation.tsx:1-249](file://frontend/src/pages/CharacterCreation.tsx#L1-L249)
- [frontend/src/pages/GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [frontend/src/App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)
- [backend/app/main.py:1-26](file://backend/app/main.py#L1-L26)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/models.py:1-171](file://backend/app/models.py#L1-L171)
- [backend/app/game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [backend/app/talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [backend/app/endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [backend/app/events/all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)

**Section sources**
- [frontend/src/utils/types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)
- [backend/app/models.py:1-171](file://backend/app/models.py#L1-L171)
- [backend/app/main.py:1-26](file://backend/app/main.py#L1-L26)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [backend/app/talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [backend/app/endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [backend/app/events/all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [frontend/src/pages/CharacterCreation.tsx:1-249](file://frontend/src/pages/CharacterCreation.tsx#L1-L249)
- [frontend/src/pages/GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [frontend/src/App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)

## Core Components
- Frontend TypeScript interfaces define the shape of attributes, talents, game state, and API responses. These types guide local state and UI rendering.
- Backend Pydantic models enforce strict schema validation for requests, responses, and internal state, ensuring type safety and consistent serialization.
- The backend maintains an in-memory game state store keyed by game identifiers, enabling deterministic, immutable state transitions per game session.
- Events are loaded from JSON and processed dynamically, applying effects to state based on conditions and weights.

Key data contracts:
- Attributes, Talents, EventCondition, EventEffect, EventBranch, GameEvent, GameState, StartGameRequest, NextYearResponse, ChoiceRequest, LifeSummary (backend)
- Attributes, Talent, GameEvent, GameState, NextYearResponse, LifeSummary, constants for realm names/colors/attributes/rarities (frontend)

Validation highlights:
- Attribute total cap and talent count limits on the backend during game start
- Age/realm/tag/event condition checks during event selection and application
- Death and breakthrough logic with probabilistic outcomes

**Section sources**
- [backend/app/models.py:48-171](file://backend/app/models.py#L48-L171)
- [frontend/src/utils/types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)
- [backend/app/router.py:18-44](file://backend/app/router.py#L18-L44)
- [backend/app/game_engine.py:80-116](file://backend/app/game_engine.py#L80-L116)
- [backend/app/game_engine.py:207-253](file://backend/app/game_engine.py#L207-L253)
- [backend/app/game_engine.py:256-295](file://backend/app/game_engine.py#L256-L295)

## Architecture Overview
The system uses a request-response pattern with JSON payloads:
- Frontend sends typed requests (start game, next year)
- Backend validates inputs, mutates immutable state, and returns typed responses
- Frontend updates local state reactively and renders the UI

```mermaid
sequenceDiagram
participant User as "User"
participant FE as "Frontend (React)"
participant API as "api.ts"
participant Router as "router.py"
participant Engine as "game_engine.py"
participant Store as "GAME_STATES (in-memory)"
User->>FE : "Click Start"
FE->>API : "startGame(attributes, talents)"
API->>Router : "POST /api/game/start"
Router->>Engine : "create_game(attrs, talents)"
Engine->>Store : "GAME_STATES[game_id] = GameState(...)"
Router-->>API : "{game_id, age, realm, ...}"
API-->>FE : "Typed response"
User->>FE : "Click Next Year"
FE->>API : "nextYear(gameId)"
API->>Router : "POST /api/game/next-year"
Router->>Engine : "advance_year(game_id)"
Engine->>Engine : "check_death / select_events / apply effects"
Engine->>Store : "Mutate GameState"
Engine-->>Router : "NextYearResponse"
Router-->>API : "JSON payload"
API-->>FE : "Typed response"
FE->>FE : "Update local state & render"
```

**Diagram sources**
- [frontend/src/utils/api.ts:11-47](file://frontend/src/utils/api.ts#L11-L47)
- [backend/app/router.py:18-68](file://backend/app/router.py#L18-L68)
- [backend/app/game_engine.py:48-77](file://backend/app/game_engine.py#L48-L77)
- [backend/app/game_engine.py:311-393](file://backend/app/game_engine.py#L311-L393)

## Detailed Component Analysis

### Data Models and Type Safety
- Backend models (Pydantic) define strict schemas for all data exchanged between frontend and backend. They ensure:
  - Required fields and defaults
  - Enum-like realm values
  - Nested structures for attributes, talents, events, and state
  - Automatic serialization to dictionaries suitable for JSON transport
- Frontend TypeScript interfaces mirror core structures, enabling compile-time checks and IDE support.

```mermaid
classDiagram
class Attributes {
+int lifespan
+int constitution
+int comprehension
+int fortune
+int charisma
+int willpower
}
class Talent {
+string id
+string name
+string description
+int rarity
+dict effects
+string[] tags
}
class EventCondition {
+int min_age
+int max_age
+int min_realm
+int max_realm
+int min_cultivation
+string[] required_talents
+string[] required_tags
+string[] excluded_tags
+dict min_attribute
}
class EventEffect {
+int cultivation
+int lifespan
+int constitution
+int comprehension
+int fortune
+int charisma
+int willpower
+bool realm_up
+string add_tag
+string remove_tag
+bool death
}
class EventBranch {
+string text
+EventEffect effects
+string result_text
}
class GameEvent {
+string id
+string text
+string category
+EventCondition conditions
+int weight
+EventEffect effects
+EventBranch[] branches
+string[] tags
+string event_type
}
class GameState {
+string game_id
+int age
+int realm
+int cultivation
+Attributes attributes
+string[] talents
+string[] tags
+list events_log
+bool is_dead
+string death_reason
+bool is_ascended
}
class StartGameRequest {
+Attributes attributes
+string[] talents
}
class NextYearResponse {
+int age
+int realm
+string realm_name
+int cultivation
+int cultivation_max
+list events
+Attributes attributes
+bool is_dead
+string death_reason
+bool is_ascended
+bool has_choice
+dict choice_event
}
class ChoiceRequest {
+string game_id
+string event_id
+int choice_index
}
class LifeSummary {
+int total_age
+int max_realm
+string max_realm_name
+string death_reason
+list key_events
+list talents
+Attributes final_attributes
+int score
+string title
}
GameEvent --> EventCondition : "uses"
GameEvent --> EventEffect : "uses"
GameEvent --> EventBranch : "contains"
GameState --> Attributes : "has"
StartGameRequest --> Attributes : "uses"
NextYearResponse --> Attributes : "includes"
LifeSummary --> Attributes : "final"
```

**Diagram sources**
- [backend/app/models.py:48-171](file://backend/app/models.py#L48-L171)

**Section sources**
- [backend/app/models.py:48-171](file://backend/app/models.py#L48-L171)
- [frontend/src/utils/types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)

### Frontend State Management and Validation
- Character creation enforces:
  - Attribute total ≤ 20
  - Talent selection ≤ 3
  - Per-attribute bounds (0–10)
- Game screen advances the year, updates local state, and scrolls to the latest event.
- API client wraps HTTP calls with JSON parsing and error propagation.

```mermaid
flowchart TD
Start(["User opens Character Creation"]) --> Adjust["Adjust attributes (+/- buttons)"]
Adjust --> Validate["Validate total ≤ 20<br/>Remaining ≥ 0"]
Validate --> TalentPick["Pick up to 3 talents"]
TalentPick --> Confirm{"Ready to start?"}
Confirm --> |No| Adjust
Confirm --> |Yes| Submit["Submit to backend"]
Submit --> Response["Receive typed response"]
Response --> Navigate["Navigate to Game Screen"]
Navigate --> YearAdvance["Click Next Year"]
YearAdvance --> Update["Update local state (age, realm, attrs, events)"]
Update --> Render["Render UI with new data"]
```

**Diagram sources**
- [frontend/src/pages/CharacterCreation.tsx:38-78](file://frontend/src/pages/CharacterCreation.tsx#L38-L78)
- [frontend/src/utils/api.ts:11-34](file://frontend/src/utils/api.ts#L11-L34)
- [frontend/src/pages/GameScreen.tsx:40-65](file://frontend/src/pages/GameScreen.tsx#L40-L65)

**Section sources**
- [frontend/src/pages/CharacterCreation.tsx:1-249](file://frontend/src/pages/CharacterCreation.tsx#L1-L249)
- [frontend/src/pages/GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)

### Backend Processing Pipeline
- Start game:
  - Validates attribute total and talent count
  - Applies talent effects to attributes
  - Creates immutable GameState stored in memory
- Advance year:
  - Checks death conditions first
  - Computes cultivation gain
  - Selects weighted events and applies effects
  - Checks realm breakthrough with probability
  - Returns typed NextYearResponse

```mermaid
flowchart TD
S(["advance_year(game_id)"]) --> Load["Load GameState from memory"]
Load --> Over{"is_dead or is_ascended?"}
Over --> |Yes| Error["Raise ValueError"]
Over --> |No| Age["state.age += 1"]
Age --> Death["check_death(state)"]
Death --> Dead{"Died?"}
Dead --> |Yes| LogDeath["Append death event to log"]
LogDeath --> ReturnDead["Return NextYearResponse with is_dead=true"]
Dead --> |No| Gain["process_cultivation_gain(state)"]
Gain --> AddGain["state.cultivation += gain"]
AddGain --> Select["select_events(state, count)"]
Select --> Apply["apply_event_effects(event, state)"]
Apply --> Log["Append event to events_log"]
Log --> Break["check_realm_breakthrough(state)"]
Break --> Asc{"Ascended?"}
Asc --> |Yes| ReturnAsc["Return NextYearResponse with is_ascended=true"]
Asc --> |No| Return["Return NextYearResponse"]
```

**Diagram sources**
- [backend/app/game_engine.py:311-393](file://backend/app/game_engine.py#L311-L393)
- [backend/app/game_engine.py:207-253](file://backend/app/game_engine.py#L207-L253)
- [backend/app/game_engine.py:256-295](file://backend/app/game_engine.py#L256-L295)
- [backend/app/game_engine.py:298-309](file://backend/app/game_engine.py#L298-L309)
- [backend/app/game_engine.py:166-204](file://backend/app/game_engine.py#L166-L204)

**Section sources**
- [backend/app/router.py:47-68](file://backend/app/router.py#L47-L68)
- [backend/app/game_engine.py:311-393](file://backend/app/game_engine.py#L311-L393)
- [backend/app/game_engine.py:80-116](file://backend/app/game_engine.py#L80-L116)
- [backend/app/game_engine.py:119-153](file://backend/app/game_engine.py#L119-L153)

### Data Transformation Pipeline
- Frontend to Backend:
  - Typed request objects are serialized to JSON
  - Backend validates and converts to Pydantic models
- Backend to Frontend:
  - Responses are Pydantic model instances serialized to JSON
  - Frontend deserializes into TypeScript interfaces

Serialization/deserialization:
- Frontend uses JSON.stringify and JSON.parse around fetch calls
- Backend uses model_dump() for serialization and dict-style access for dynamic event loading

**Section sources**
- [frontend/src/utils/api.ts:24-33](file://frontend/src/utils/api.ts#L24-L33)
- [frontend/src/utils/api.ts:37-46](file://frontend/src/utils/api.ts#L37-L46)
- [backend/app/router.py:55-56](file://backend/app/router.py#L55-L56)
- [backend/app/models.py:137-150](file://backend/app/models.py#L137-L150)

### Validation Strategies and Error Propagation
- Frontend:
  - Client-side validation prevents invalid submissions
  - API client surfaces errors from backend with clear messages
- Backend:
  - Route handlers validate inputs and raise HTTP exceptions
  - Engine functions raise ValueError for invalid operations (e.g., advancing ended games)
  - Frontend catches and displays errors

**Section sources**
- [frontend/src/pages/CharacterCreation.tsx:78-78](file://frontend/src/pages/CharacterCreation.tsx#L78-L78)
- [frontend/src/utils/api.ts:29-32](file://frontend/src/utils/api.ts#L29-L32)
- [frontend/src/utils/api.ts:42-45](file://frontend/src/utils/api.ts#L42-L45)
- [backend/app/router.py:21-30](file://backend/app/router.py#L21-L30)
- [backend/app/router.py:57-58](file://backend/app/router.py#L57-L58)

### Real-Time Updates and Event-Driven State
- Frontend reacts to backend responses by updating local state and appending events to the log
- Auto-play mode triggers subsequent year advances after receiving a response
- Death or ascension halts further automation and navigates to the summary screen

**Section sources**
- [frontend/src/pages/GameScreen.tsx:40-65](file://frontend/src/pages/GameScreen.tsx#L40-L65)
- [frontend/src/pages/GameScreen.tsx:53-57](file://frontend/src/pages/GameScreen.tsx#L53-L57)
- [frontend/src/App.tsx:41-44](file://frontend/src/App.tsx#L41-L44)

## Dependency Analysis
- Frontend depends on:
  - api.ts for HTTP communication
  - types.ts for type contracts
  - React components for UI and state
- Backend depends on:
  - models.py for schemas
  - router.py for endpoints
  - game_engine.py for state logic
  - talents.py for talent pool
  - events/all_events.json for event catalog
  - endings.py for titles and scoring

```mermaid
graph LR
FE_API["api.ts"] --> BE_ROUTER["router.py"]
FE_TYPES["types.ts"] --> FE_API
FE_CREATION["CharacterCreation.tsx"] --> FE_API
FE_GAME["GameScreen.tsx"] --> FE_API
BE_ROUTER --> BE_ENGINE["game_engine.py"]
BE_ROUTER --> BE_TALENTS["talents.py"]
BE_ROUTER --> BE_MODELS["models.py"]
BE_ENGINE --> BE_MODELS
BE_ENGINE --> BE_EVENTS["events/all_events.json"]
BE_ENGINE --> BE_ENDINGS["endings.py"]
```

**Diagram sources**
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [frontend/src/utils/types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)
- [frontend/src/pages/CharacterCreation.tsx:1-249](file://frontend/src/pages/CharacterCreation.tsx#L1-L249)
- [frontend/src/pages/GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [backend/app/talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [backend/app/models.py:1-171](file://backend/app/models.py#L1-L171)
- [backend/app/endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [backend/app/events/all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)

**Section sources**
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [backend/app/talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [backend/app/models.py:1-171](file://backend/app/models.py#L1-L171)
- [backend/app/endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [backend/app/events/all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)
- [frontend/src/utils/api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [frontend/src/utils/types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)
- [frontend/src/pages/CharacterCreation.tsx:1-249](file://frontend/src/pages/CharacterCreation.tsx#L1-L249)
- [frontend/src/pages/GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)

## Performance Considerations
- In-memory state storage is efficient for single-process deployments but not persistent across restarts
- Event selection uses weighted random sampling; consider caching normalized weights if performance becomes a concern
- Serialization/deserialization overhead is minimal for typical payloads
- Frontend re-renders are optimized by updating only changed state fields

## Troubleshooting Guide
Common issues and resolutions:
- Invalid attribute totals or talent counts on start:
  - Ensure total points ≤ 20 and talent count ≤ 3
  - Backend returns HTTP 400 with a descriptive message
- Attempting to advance an ended game:
  - Backend raises ValueError; frontend stops auto-play and shows an error
- Network failures:
  - API client surfaces HTTP errors; ensure CORS is configured and server is reachable

**Section sources**
- [frontend/src/pages/CharacterCreation.tsx:78-78](file://frontend/src/pages/CharacterCreation.tsx#L78-L78)
- [frontend/src/utils/api.ts:29-32](file://frontend/src/utils/api.ts#L29-L32)
- [frontend/src/utils/api.ts:42-45](file://frontend/src/utils/api.ts#L42-L45)
- [backend/app/router.py:21-30](file://backend/app/router.py#L21-L30)
- [backend/app/router.py:57-58](file://backend/app/router.py#L57-L58)

## Conclusion
A Little Game’s data flow combines strong frontend type safety with robust backend validation and immutable state management. Requests originate from React components, traverse typed APIs, and are processed through a deterministic engine that mutates in-memory state and returns structured responses. The result is a responsive, reliable simulation where frontend reactive updates reflect backend immutable changes, and validation ensures consistent, predictable gameplay.