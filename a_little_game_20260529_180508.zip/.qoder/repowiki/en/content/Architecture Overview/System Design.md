# System Design

<cite>
**Referenced Files in This Document**
- [docker-compose.yml](file://docker-compose.yml)
- [Dockerfile.backend](file://Dockerfile.backend)
- [Dockerfile.frontend](file://Dockerfile.frontend)
- [nginx.conf](file://frontend/nginx.conf)
- [backend/app/main.py](file://backend/app/main.py)
- [backend/app/router.py](file://backend/app/router.py)
- [backend/app/game_engine.py](file://backend/app/game_engine.py)
- [backend/app/models.py](file://backend/app/models.py)
- [backend/app/talents.py](file://backend/app/talents.py)
- [backend/requirements.txt](file://backend/requirements.txt)
- [frontend/src/App.tsx](file://frontend/src/App.tsx)
- [frontend/src/pages/GameScreen.tsx](file://frontend/src/pages/GameScreen.tsx)
- [frontend/src/utils/api.ts](file://frontend/src/utils/api.ts)
- [frontend/src/utils/types.ts](file://frontend/src/utils/types.ts)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document describes the system design of A Little Game, a cultivation-themed life simulator. The system consists of:
- A React Single Page Application (SPA) frontend that renders the gameplay UI and manages client-side state transitions.
- A FastAPI backend service that runs the game engine, maintains in-memory game state, and exposes REST endpoints.
- Docker images for both frontend and backend, orchestrated via docker-compose.
- An Nginx reverse proxy that serves static assets and proxies API requests to the backend.

The backend implements an event-driven simulation model with in-memory state management. The frontend communicates with the backend through REST calls to start games, advance years, and retrieve summaries. The system is designed for simplicity, portability, and easy local development.

## Project Structure
The repository is organized into:
- backend: FastAPI application with routing, game engine, models, and event data.
- frontend: React SPA built with Vite, TypeScript, and Tailwind CSS.
- docker-compose.yml: Multi-service orchestration.
- Dockerfiles for backend and frontend.
- Nginx configuration for serving static assets and proxying API traffic.

```mermaid
graph TB
subgraph "Host Machine"
DC["docker-compose.yml"]
end
subgraph "Network: default"
FE["frontend:80"]
BE["backend:8000"]
end
DC --> FE
DC --> BE
FE --> NGINX["Nginx (frontend/nginx.conf)"]
NGINX --> API["/api/ -> backend:8000"]
NGINX --> Static["Static SPA -> /usr/share/nginx/html"]
BE --> FastAPI["FastAPI app (backend/app/main.py)"]
FastAPI --> Router["Router (backend/app/router.py)"]
Router --> Engine["Game Engine (backend/app/game_engine.py)"]
Engine --> Events["Events JSON (backend/app/events/*.json)"]
Engine --> Talents["Talents (backend/app/talents.py)"]
Engine --> Models["Models (backend/app/models.py)"]
```

**Diagram sources**
- [docker-compose.yml](file://docker-compose.yml)
- [Dockerfile.frontend](file://Dockerfile.frontend)
- [Dockerfile.backend](file://Dockerfile.backend)
- [nginx.conf](file://frontend/nginx.conf)
- [backend/app/main.py](file://backend/app/main.py)
- [backend/app/router.py](file://backend/app/router.py)
- [backend/app/game_engine.py](file://backend/app/game_engine.py)
- [backend/app/talents.py](file://backend/app/talents.py)
- [backend/app/models.py](file://backend/app/models.py)

**Section sources**
- [docker-compose.yml](file://docker-compose.yml)
- [Dockerfile.backend](file://Dockerfile.backend)
- [Dockerfile.frontend](file://Dockerfile.frontend)
- [frontend/nginx.conf](file://frontend/nginx.conf)

## Core Components
- Frontend SPA
  - Entry point initializes routing among Start, Character Creation, Gameplay, and Summary screens.
  - GameScreen drives the gameplay loop by invoking the backend to advance the year and updating local UI state.
  - API utilities encapsulate REST calls to the backend.
- Backend FastAPI Service
  - Exposes endpoints to fetch talents, start a game, advance a year, and retrieve a life summary.
  - Implements the game engine that simulates events, applies effects, checks death/breakthrough conditions, and updates in-memory state.
  - Uses Pydantic models for request/response validation and typed state representation.
- Containerization and Orchestration
  - Frontend image builds the SPA and serves it via Nginx.
  - Backend image installs Python dependencies and runs Uvicorn with the FastAPI app.
  - docker-compose defines two services, ports, and runtime environment.

**Section sources**
- [frontend/src/App.tsx](file://frontend/src/App.tsx)
- [frontend/src/pages/GameScreen.tsx](file://frontend/src/pages/GameScreen.tsx)
- [frontend/src/utils/api.ts](file://frontend/src/utils/api.ts)
- [backend/app/main.py](file://backend/app/main.py)
- [backend/app/router.py](file://backend/app/router.py)
- [backend/app/game_engine.py](file://backend/app/game_engine.py)
- [backend/app/models.py](file://backend/app/models.py)
- [backend/requirements.txt](file://backend/requirements.txt)

## Architecture Overview
The system follows a classic frontend-backend split with a reverse proxy:
- Nginx serves the React SPA and acts as an API gateway, forwarding /api/* requests to the backend service.
- The backend FastAPI app registers routes and delegates to the game engine.
- The game engine stores state in memory keyed by game identifiers and computes outcomes deterministically based on events and talents.

```mermaid
graph TB
Browser["Browser (React SPA)"] --> Nginx["Nginx (frontend/nginx.conf)"]
Nginx --> API["/api/* -> backend:8000"]
API --> FastAPIApp["FastAPI app (main.py)"]
FastAPIApp --> Routes["Router (router.py)"]
Routes --> Engine["Game Engine (game_engine.py)"]
Engine --> Mem["In-memory GAME_STATES"]
Engine --> Events["Event JSON files"]
Engine --> Talents["Talents (talents.py)"]
Engine --> Models["Pydantic Models (models.py)"]
```

**Diagram sources**
- [frontend/nginx.conf](file://frontend/nginx.conf)
- [backend/app/main.py](file://backend/app/main.py)
- [backend/app/router.py](file://backend/app/router.py)
- [backend/app/game_engine.py](file://backend/app/game_engine.py)
- [backend/app/talents.py](file://backend/app/talents.py)
- [backend/app/models.py](file://backend/app/models.py)

## Detailed Component Analysis

### Frontend: React SPA and API Layer
- App orchestrates four phases: start, character creation, playing, and summary.
- GameScreen coordinates user actions, fetches results from the backend, updates local state, and handles end-of-life transitions.
- API utilities encapsulate HTTP calls to the backend endpoints.

```mermaid
sequenceDiagram
participant UI as "GameScreen.tsx"
participant API as "api.ts"
participant Nginx as "Nginx (frontend/nginx.conf)"
participant BE as "FastAPI Router (router.py)"
UI->>API : nextYear(gameId)
API->>Nginx : POST /api/game/next-year
Nginx->>BE : proxy_pass to backend : 8000
BE-->>API : NextYearResponse
API-->>UI : update state (age, realm, attributes, events)
UI-->>UI : render updated UI and logs
```

**Diagram sources**
- [frontend/src/pages/GameScreen.tsx](file://frontend/src/pages/GameScreen.tsx)
- [frontend/src/utils/api.ts](file://frontend/src/utils/api.ts)
- [frontend/nginx.conf](file://frontend/nginx.conf)
- [backend/app/router.py](file://backend/app/router.py)

**Section sources**
- [frontend/src/App.tsx](file://frontend/src/App.tsx)
- [frontend/src/pages/GameScreen.tsx](file://frontend/src/pages/GameScreen.tsx)
- [frontend/src/utils/api.ts](file://frontend/src/utils/api.ts)
- [frontend/src/utils/types.ts](file://frontend/src/utils/types.ts)

### Backend: FastAPI, Router, and Game Engine
- FastAPI app configures CORS and includes the game router.
- Router validates inputs, enforces business rules, and calls the game engine.
- Game engine:
  - Loads event catalogs from JSON files.
  - Maintains in-memory state keyed by game_id.
  - Computes yearly outcomes: death checks, cultivation gains, event selection, breakthroughs, and end-of-life/end-of-game scenarios.
  - Returns structured responses consumed by the frontend.

```mermaid
flowchart TD
Start(["advance_year(game_id)"]) --> Lookup["Lookup state by game_id"]
Lookup --> Found{"Found and not ended?"}
Found --> |No| Error["Raise 404/ValueError"]
Found --> |Yes| Age["state.age += 1"]
Age --> DeathCheck["check_death(state)"]
DeathCheck --> Died{"Died?"}
Died --> |Yes| LogDeath["Append death event<br/>Set is_dead"]
Died --> |No| Gain["process_cultivation_gain(state)"]
Gain --> AddGain["state.cultivation += gain"]
AddGain --> Select["select_events(state, count)"]
Select --> Apply["apply_event_effects(event)"]
Apply --> Breakthrough["check_realm_breakthrough(state)"]
Breakthrough --> Ascended{"Ascended?"}
Ascended --> |Yes| ReturnAsc["Return is_ascended=true"]
Ascended --> |No| ReturnOK["Return NextYearResponse"]
LogDeath --> ReturnOK
```

**Diagram sources**
- [backend/app/game_engine.py](file://backend/app/game_engine.py)
- [backend/app/router.py](file://backend/app/router.py)

**Section sources**
- [backend/app/main.py](file://backend/app/main.py)
- [backend/app/router.py](file://backend/app/router.py)
- [backend/app/game_engine.py](file://backend/app/game_engine.py)
- [backend/app/models.py](file://backend/app/models.py)
- [backend/app/talents.py](file://backend/app/talents.py)

### Data Models and Types
- Pydantic models define request/response contracts and internal state.
- TypeScript types mirror backend models for frontend consumption.

```mermaid
classDiagram
class Attributes {
+int lifespan
+int constitution
+int comprehension
+int fortune
+int charisma
+int willpower
}
class GameState {
+string game_id
+int age
+int realm
+int cultivation
+Attributes attributes
+string[] talents
+string[] tags
+list events_log
+bool is_dead
+string death_reason
+bool is_ascended
}
class NextYearResponse {
+int age
+int realm
+string realm_name
+int cultivation
+int cultivation_max
+list events
+Attributes attributes
+bool is_dead
+string death_reason
+bool is_ascended
}
class StartGameRequest {
+Attributes attributes
+string[] talents
}
class LifeSummary {
+int total_age
+int max_realm
+string max_realm_name
+string death_reason
+list key_events
+list talents
+Attributes final_attributes
+int score
+string title
}
GameState --> Attributes : "has"
NextYearResponse --> Attributes : "has"
StartGameRequest --> Attributes : "has"
LifeSummary --> Attributes : "final_attributes"
```

**Diagram sources**
- [backend/app/models.py](file://backend/app/models.py)
- [frontend/src/utils/types.ts](file://frontend/src/utils/types.ts)

**Section sources**
- [backend/app/models.py](file://backend/app/models.py)
- [frontend/src/utils/types.ts](file://frontend/src/utils/types.ts)

### Real-Time Simulation and State Synchronization
- The frontend does not implement real-time push; it polls the backend by invoking the next-year endpoint.
- The backend maintains deterministic simulation logic and returns the computed state snapshot for each year.
- The frontend updates UI state upon receiving responses, ensuring eventual consistency between frontend and backend.

```mermaid
sequenceDiagram
participant UI as "GameScreen.tsx"
participant API as "api.ts"
participant BE as "advance_year (game_engine.py)"
participant Store as "GAME_STATES"
UI->>API : nextYear(gameId)
API->>BE : POST /api/game/next-year
BE->>Store : Read state by game_id
BE->>BE : Compute death, events, breakthrough
BE->>Store : Write updated state
BE-->>API : NextYearResponse
API-->>UI : Render updated UI
```

**Diagram sources**
- [frontend/src/pages/GameScreen.tsx](file://frontend/src/pages/GameScreen.tsx)
- [frontend/src/utils/api.ts](file://frontend/src/utils/api.ts)
- [backend/app/game_engine.py](file://backend/app/game_engine.py)

**Section sources**
- [frontend/src/pages/GameScreen.tsx](file://frontend/src/pages/GameScreen.tsx)
- [frontend/src/utils/api.ts](file://frontend/src/utils/api.ts)
- [backend/app/game_engine.py](file://backend/app/game_engine.py)

## Dependency Analysis
- Internal dependencies:
  - main.py includes router.py.
  - router.py imports models, game_engine, talents.
  - game_engine.py imports models, talents, and loads event JSONs.
- External dependencies:
  - FastAPI, Uvicorn, Pydantic for backend.
  - React, Vite, Tailwind for frontend.
- Runtime dependencies:
  - Nginx proxies API requests to backend.
  - docker-compose orchestrates networking and service startup order.

```mermaid
graph LR
Main["backend/app/main.py"] --> Router["backend/app/router.py"]
Router --> Engine["backend/app/game_engine.py"]
Engine --> Models["backend/app/models.py"]
Engine --> Talents["backend/app/talents.py"]
Router --> Models
FEConf["frontend/nginx.conf"] --> Proxy["/api/ -> backend:8000"]
```

**Diagram sources**
- [backend/app/main.py](file://backend/app/main.py)
- [backend/app/router.py](file://backend/app/router.py)
- [backend/app/game_engine.py](file://backend/app/game_engine.py)
- [backend/app/models.py](file://backend/app/models.py)
- [backend/app/talents.py](file://backend/app/talents.py)
- [frontend/nginx.conf](file://frontend/nginx.conf)

**Section sources**
- [backend/app/main.py](file://backend/app/main.py)
- [backend/app/router.py](file://backend/app/router.py)
- [backend/app/game_engine.py](file://backend/app/game_engine.py)
- [backend/app/models.py](file://backend/app/models.py)
- [backend/app/talents.py](file://backend/app/talents.py)
- [frontend/nginx.conf](file://frontend/nginx.conf)

## Performance Considerations
- In-memory state scaling:
  - Current design uses a dictionary keyed by game_id. This is simple but not horizontally scalable.
  - Recommendations:
    - Persist state to a database (e.g., PostgreSQL/Redis) and shard by game_id.
    - Implement rate limiting and session timeouts to prevent memory growth.
- Event processing:
  - Event loading occurs at module import; consider lazy-loading or caching for very large catalogs.
- Frontend rendering:
  - Virtualize long event logs for better scroll performance.
- API throughput:
  - Add middleware for request logging, gzip compression, and health checks.
- Containerization:
  - Use separate networks and healthchecks in docker-compose for production-like setups.
- Caching:
  - Cache static assets via Nginx (already configured) and consider CDN for distribution.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
- CORS errors:
  - Verify CORS middleware configuration allows expected origins.
- 404 Not Found:
  - Ensure game_id exists and the game is not already ended.
- Validation errors:
  - Attribute totals and talent counts are validated on start; confirm payload compliance.
- API proxy issues:
  - Confirm Nginx proxy_pass targets the correct backend host/port and that backend is reachable on the compose network.
- Health checks:
  - Add a simple GET route to backend for readiness/liveness probes.

**Section sources**
- [backend/app/main.py](file://backend/app/main.py)
- [backend/app/router.py](file://backend/app/router.py)
- [frontend/nginx.conf](file://frontend/nginx.conf)

## Conclusion
A Little Game employs a clean separation between a React SPA and a FastAPI backend, orchestrated by docker-compose and served via Nginx. The backend’s in-memory game engine provides a deterministic, event-driven simulation that the frontend consumes through REST calls. While the current design prioritizes simplicity and developer productivity, adopting persistent storage, rate limiting, and CDN caching would improve scalability and robustness for production deployment.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### API Surface
- GET /api/game/talents
  - Description: Fetch a randomized pool of talents for character creation.
  - Response: talents array.
- POST /api/game/start
  - Request: StartGameRequest (attributes, talents).
  - Response: Initial game state including game_id, age, realm, cultivation, attributes, talents, tags.
- POST /api/game/next-year
  - Request: { game_id }.
  - Response: NextYearResponse (updated state, events, attributes).
- GET /api/game/summary/{game_id}
  - Response: LifeSummary (final stats, title, score).

**Section sources**
- [backend/app/router.py](file://backend/app/router.py)
- [backend/app/models.py](file://backend/app/models.py)

### Containerization and Orchestration Notes
- Services:
  - frontend: Builds SPA and serves via Nginx; binds port 80.
  - backend: Runs FastAPI with Uvicorn; binds port 8000.
- Dependencies:
  - frontend depends_on backend to ensure API availability during startup.
- Networking:
  - Services share the default bridge network; Nginx proxies /api/ to backend.

**Section sources**
- [docker-compose.yml](file://docker-compose.yml)
- [Dockerfile.backend](file://Dockerfile.backend)
- [Dockerfile.frontend](file://Dockerfile.frontend)
- [frontend/nginx.conf](file://frontend/nginx.conf)