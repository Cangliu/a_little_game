# API Integration

<cite>
**Referenced Files in This Document**
- [api.ts](file://frontend/src/utils/api.ts)
- [types.ts](file://frontend/src/utils/types.ts)
- [App.tsx](file://frontend/src/App.tsx)
- [CharacterCreation.tsx](file://frontend/src/pages/CharacterCreation.tsx)
- [GameScreen.tsx](file://frontend/src/pages/GameScreen.tsx)
- [SummaryScreen.tsx](file://frontend/src/pages/SummaryScreen.tsx)
- [router.py](file://backend/app/router.py)
- [main.py](file://backend/app/main.py)
- [models.py](file://backend/app/models.py)
- [game_engine.py](file://backend/app/game_engine.py)
- [talents.py](file://backend/app/talents.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the centralized API client implementation and TypeScript integration patterns used by the frontend to communicate with the backend. It covers the api.ts module functions for retrieving talents, starting a game, advancing years, and fetching summaries, along with robust error handling and type safety. It also documents the TypeScript types in types.ts, including the Attributes interface, GameResult structure, and API response types. The guide details HTTP request patterns, error handling strategies, response processing, and practical examples of integrating these APIs with React components. Authentication patterns, request/response transformation, debugging approaches, and guidelines for extending the API client are included.

## Project Structure
The API integration spans two primary areas:
- Frontend: Centralized API client and strongly typed models
- Backend: FastAPI routes and Pydantic models backing the API

```mermaid
graph TB
subgraph "Frontend"
FE_API["frontend/src/utils/api.ts"]
FE_TYPES["frontend/src/utils/types.ts"]
FE_APP["frontend/src/App.tsx"]
FE_CHAR["frontend/src/pages/CharacterCreation.tsx"]
FE_GAME["frontend/src/pages/GameScreen.tsx"]
FE_SUM["frontend/src/pages/SummaryScreen.tsx"]
end
subgraph "Backend"
BE_MAIN["backend/app/main.py"]
BE_ROUTER["backend/app/router.py"]
BE_MODELS["backend/app/models.py"]
BE_ENGINE["backend/app/game_engine.py"]
BE_TALENTS["backend/app/talents.py"]
end
FE_APP --> FE_API
FE_CHAR --> FE_API
FE_GAME --> FE_API
FE_SUM --> FE_API
FE_API --> BE_ROUTER
BE_ROUTER --> BE_MODELS
BE_ROUTER --> BE_ENGINE
BE_ENGINE --> BE_TALENTS
BE_MAIN --> BE_ROUTER
```

**Diagram sources**
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)
- [App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)
- [CharacterCreation.tsx:1-249](file://frontend/src/pages/CharacterCreation.tsx#L1-L249)
- [GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [SummaryScreen.tsx:1-177](file://frontend/src/pages/SummaryScreen.tsx#L1-L177)
- [main.py:1-26](file://backend/app/main.py#L1-L26)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [talents.py:1-85](file://backend/app/talents.py#L1-L85)

**Section sources**
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [main.py:1-26](file://backend/app/main.py#L1-L26)

## Core Components
- Centralized API client (frontend/src/utils/api.ts)
  - Provides four primary functions:
    - fetchTalents(): retrieves a random pool of talents for character creation
    - startGame(attributes, talents): starts a new game session
    - nextYear(gameId): advances the game by one year
    - getSummary(gameId): retrieves the life summary after the game ends
  - All functions use fetch with JSON serialization and robust error handling via HTTP status checks and JSON error payloads.

- TypeScript type definitions (frontend/src/utils/types.ts)
  - Defines strongly typed interfaces for Attributes, Talent, GameEvent, GameState, NextYearResponse, and LifeSummary
  - Exposes constants for realm names, colors, attribute names, rarity colors, and rarity names
  - Ensures compile-time safety and predictable runtime behavior across components

- Backend API routes (backend/app/router.py)
  - Exposes endpoints under /api/game for talents, start, next-year, and summary
  - Validates requests and returns Pydantic model dumps for responses
  - Uses FastAPI HTTPException for error signaling

- Backend models (backend/app/models.py)
  - Declares Pydantic models for Attributes, Talent, EventCondition, EventEffect, EventBranch, GameEvent, GameState, StartGameRequest, NextYearResponse, ChoiceRequest, and LifeSummary
  - Provides constants for realm names, thresholds, and max ages

- Backend game engine (backend/app/game_engine.py)
  - Implements game logic, including event selection, attribute application, realm breakthrough checks, and life summary generation
  - Manages in-memory game state keyed by game_id

**Section sources**
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)

## Architecture Overview
The frontend API client communicates with the backend via HTTP endpoints. The backend validates inputs, executes game logic, and returns structured JSON responses. The frontend consumes these responses with strong TypeScript types and updates React component state accordingly.

```mermaid
sequenceDiagram
participant FE as "Frontend Component"
participant API as "frontend/src/utils/api.ts"
participant BE as "backend/app/router.py"
FE->>API : Call startGame(attributes, talents)
API->>BE : POST /api/game/start (JSON)
BE-->>API : 200 OK {game_id, age, realm, attributes, talents, ...}
API-->>FE : Promise resolves with game state
FE->>FE : Update local state and navigate to playing screen
```

**Diagram sources**
- [api.ts:11-34](file://frontend/src/utils/api.ts#L11-L34)
- [router.py:18-44](file://backend/app/router.py#L18-L44)

**Section sources**
- [api.ts:11-34](file://frontend/src/utils/api.ts#L11-L34)
- [router.py:18-44](file://backend/app/router.py#L18-L44)

## Detailed Component Analysis

### Centralized API Client (api.ts)
- Base URL
  - Uses a fixed base path for all game endpoints
- Function: fetchTalents
  - GET /api/game/talents
  - Returns an array of Talent objects
- Function: startGame
  - POST /api/game/start
  - Request body includes attributes and talents arrays
  - Throws on non-OK responses using the error detail field
- Function: nextYear
  - POST /api/game/next-year
  - Request body includes game_id
  - Throws on non-OK responses using the error detail field
- Function: getSummary
  - GET /api/game/summary/{game_id}
  - Throws on non-OK responses using the error detail field

```mermaid
flowchart TD
Start(["Call nextYear(gameId)"]) --> Post["POST /api/game/next-year<br/>Body: { game_id }"]
Post --> Ok{"HTTP 200 OK?"}
Ok --> |Yes| Parse["Parse JSON response"]
Ok --> |No| Err["Read JSON error payload<br/>Throw Error(detail)"]
Parse --> Return["Return NextYearResponse"]
Err --> End(["Stop"])
Return --> End
```

**Diagram sources**
- [api.ts:36-47](file://frontend/src/utils/api.ts#L36-L47)

**Section sources**
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)

### TypeScript Types (types.ts)
- Attributes interface
  - Six core attributes used across gameplay
- Talent interface
  - Describes selectable traits with rarity, effects, and tags
- GameEvent interface
  - Represents individual events with text, type, and age
- GameState interface
  - Full snapshot of an ongoing game
- NextYearResponse interface
  - Response shape for advancing a year
- LifeSummary interface
  - Final summary after game completion
- Constants
  - REALM_NAMES, REALM_COLORS, ATTR_NAMES, RARITY_COLORS, RARITY_NAMES
  - Used for rendering and UI classification

```mermaid
classDiagram
class Attributes {
+number lifespan
+number constitution
+number comprehension
+number fortune
+number charisma
+number willpower
}
class Talent {
+string id
+string name
+string description
+number rarity
+Record~string,number~ effects
+string[] tags
}
class GameEvent {
+string text
+string type
+number age
}
class GameState {
+string game_id
+number age
+number realm
+string realm_name
+number cultivation
+number cultivation_max
+Attributes attributes
+string[] talents
+string[] tags
+boolean is_dead
+string death_reason
+boolean is_ascended
}
class NextYearResponse {
+number age
+number realm
+string realm_name
+number cultivation
+number cultivation_max
+GameEvent[] events
+Attributes attributes
+boolean is_dead
+string death_reason
+boolean is_ascended
}
class LifeSummary {
+number total_age
+number max_realm
+string max_realm_name
+string death_reason
+string[] key_events
+string[] talents
+Attributes final_attributes
+number score
+string title
}
```

**Diagram sources**
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)

**Section sources**
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)

### Backend Routes and Models
- Router endpoints
  - GET /api/game/talents: returns a list of randomized talents
  - POST /api/game/start: validates attributes and talents, creates a new game
  - POST /api/game/next-year: advances the game by one year
  - GET /api/game/summary/{game_id}: computes and returns the life summary
- Pydantic models
  - StartGameRequest, NextYearResponse, LifeSummary, Attributes, Talent, GameEvent, etc.
  - Provide strict schema validation and serialization

```mermaid
graph LR
FE["frontend/src/utils/api.ts"] --> RT["backend/app/router.py"]
RT --> MD["backend/app/models.py"]
RT --> GE["backend/app/game_engine.py"]
GE --> TL["backend/app/talents.py"]
```

**Diagram sources**
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [talents.py:1-85](file://backend/app/talents.py#L1-L85)

**Section sources**
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [talents.py:1-85](file://backend/app/talents.py#L1-L85)

### React Component Integrations

#### Character Creation Screen (CharacterCreation.tsx)
- Fetches talent pool on mount and renders selectable talents
- Validates attribute distribution and talent selection
- Confirms and starts the game by invoking startGame

```mermaid
sequenceDiagram
participant CC as "CharacterCreation.tsx"
participant API as "api.ts"
participant BE as "router.py"
CC->>API : fetchTalents()
API->>BE : GET /api/game/talents
BE-->>API : 200 OK { talents : [...] }
API-->>CC : Promise resolved with Talent[]
CC->>CC : Render talent cards and controls
CC->>API : startGame(attributes, talents)
API->>BE : POST /api/game/start
BE-->>API : 200 OK { game_id, attributes, ... }
API-->>CC : Promise resolved with game state
CC->>CC : Navigate to GameScreen
```

**Diagram sources**
- [CharacterCreation.tsx:30-36](file://frontend/src/pages/CharacterCreation.tsx#L30-L36)
- [api.ts:5-34](file://frontend/src/utils/api.ts#L5-L34)
- [router.py:18-44](file://backend/app/router.py#L18-L44)

**Section sources**
- [CharacterCreation.tsx:1-249](file://frontend/src/pages/CharacterCreation.tsx#L1-L249)
- [api.ts:5-34](file://frontend/src/utils/api.ts#L5-L34)
- [router.py:18-44](file://backend/app/router.py#L18-L44)

#### Game Screen (GameScreen.tsx)
- Drives the gameplay loop by calling nextYear repeatedly
- Updates state with returned NextYearResponse
- Handles game over conditions and transitions to SummaryScreen

```mermaid
sequenceDiagram
participant GS as "GameScreen.tsx"
participant API as "api.ts"
participant BE as "router.py"
loop Year progression
GS->>API : nextYear(gameId)
API->>BE : POST /api/game/next-year
BE-->>API : 200 OK { age, events, attributes, ... }
API-->>GS : Promise resolved with NextYearResponse
GS->>GS : Update UI state and event log
alt Game over
GS->>GS : Trigger onGameEnd(gameId)
end
end
```

**Diagram sources**
- [GameScreen.tsx:40-65](file://frontend/src/pages/GameScreen.tsx#L40-L65)
- [api.ts:36-47](file://frontend/src/utils/api.ts#L36-L47)
- [router.py:47-59](file://backend/app/router.py#L47-L59)

**Section sources**
- [GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [api.ts:36-47](file://frontend/src/utils/api.ts#L36-L47)
- [router.py:47-59](file://backend/app/router.py#L47-L59)

#### Summary Screen (SummaryScreen.tsx)
- Retrieves the life summary after the game ends
- Renders final stats, attributes, key events, and score

```mermaid
sequenceDiagram
participant SS as "SummaryScreen.tsx"
participant API as "api.ts"
participant BE as "router.py"
SS->>API : getSummary(gameId)
API->>BE : GET /api/game/summary/{gameId}
BE-->>API : 200 OK { total_age, max_realm, key_events, ... }
API-->>SS : Promise resolved with LifeSummary
SS->>SS : Render summary panel
```

**Diagram sources**
- [SummaryScreen.tsx:16-21](file://frontend/src/pages/SummaryScreen.tsx#L16-L21)
- [api.ts:49-56](file://frontend/src/utils/api.ts#L49-L56)
- [router.py:61-68](file://backend/app/router.py#L61-L68)

**Section sources**
- [SummaryScreen.tsx:1-177](file://frontend/src/pages/SummaryScreen.tsx#L1-L177)
- [api.ts:49-56](file://frontend/src/utils/api.ts#L49-L56)
- [router.py:61-68](file://backend/app/router.py#L61-L68)

### Error Handling Strategies
- Frontend
  - Checks res.ok and throws with detail from JSON payload when present
  - Components catch errors and surface user-friendly messages or logs
- Backend
  - Validates attribute totals and talent counts
  - Raises HTTPException with descriptive detail for invalid requests
  - Returns 404 for missing or ended games during next-year and summary operations

```mermaid
flowchart TD
A["Fetch response"] --> B{"res.ok?"}
B --> |Yes| C["Parse JSON"]
B --> |No| D["Parse JSON error payload"]
D --> E["Throw Error(detail)"]
C --> F["Return typed data"]
```

**Diagram sources**
- [api.ts:29-33](file://frontend/src/utils/api.ts#L29-L33)
- [api.ts:42-46](file://frontend/src/utils/api.ts#L42-L46)
- [api.ts:51-54](file://frontend/src/utils/api.ts#L51-L54)

**Section sources**
- [api.ts:29-33](file://frontend/src/utils/api.ts#L29-L33)
- [api.ts:42-46](file://frontend/src/utils/api.ts#L42-L46)
- [api.ts:51-54](file://frontend/src/utils/api.ts#L51-L54)
- [router.py:26-30](file://backend/app/router.py#L26-L30)
- [router.py:51-58](file://backend/app/router.py#L51-L58)
- [router.py:64-68](file://backend/app/router.py#L64-L68)

### Request/Response Transformation
- Frontend
  - Serializes request bodies to JSON
  - Deserializes responses to typed objects
- Backend
  - Uses Pydantic models for validation and serialization
  - Converts models to dictionaries via model_dump()

**Section sources**
- [api.ts:24-28](file://frontend/src/utils/api.ts#L24-L28)
- [api.ts:37-41](file://frontend/src/utils/api.ts#L37-L41)
- [router.py:34-44](file://backend/app/router.py#L34-L44)
- [models.py:137-151](file://backend/app/models.py#L137-L151)
- [models.py:160-171](file://backend/app/models.py#L160-L171)

### Authentication Patterns
- No explicit authentication is implemented in the current codebase
- CORS middleware allows cross-origin requests from any origin

**Section sources**
- [main.py:12-18](file://backend/app/main.py#L12-L18)

### Debugging Approaches
- Frontend
  - Log caught errors to the console
  - Alert user-friendly messages on failures
  - Use useEffect and state updates to track loading and completion
- Backend
  - Validate inputs early and return clear HTTP exceptions
  - Use detailed error messages in HTTPException detail fields

**Section sources**
- [App.tsx:35-38](file://frontend/src/App.tsx#L35-L38)
- [GameScreen.tsx:60-63](file://frontend/src/pages/GameScreen.tsx#L60-L63)
- [router.py:26-30](file://backend/app/router.py#L26-L30)

### Guidelines for Extending the API Client
- Add new endpoint functions in api.ts following the existing pattern:
  - Define a function that calls fetch with appropriate method and headers
  - Serialize request body as JSON when needed
  - Check res.ok and throw with parsed error detail
  - Return parsed JSON response
- Update types.ts with corresponding interfaces for new responses
- Integrate new functions in React components using useEffect and state
- Keep base URL consistent and consider adding a small wrapper for shared headers if needed

**Section sources**
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)

## Dependency Analysis
The frontend depends on the backend API contract defined by router.py and enforced by Pydantic models in models.py. The game engine in game_engine.py encapsulates business logic and state management.

```mermaid
graph TB
API["frontend/src/utils/api.ts"] --> ROUTER["backend/app/router.py"]
ROUTER --> MODELS["backend/app/models.py"]
ROUTER --> ENGINE["backend/app/game_engine.py"]
ENGINE --> TALENTS["backend/app/talents.py"]
APP["frontend/src/App.tsx"] --> API
CHAR["frontend/src/pages/CharacterCreation.tsx"] --> API
GAME["frontend/src/pages/GameScreen.tsx"] --> API
SUM["frontend/src/pages/SummaryScreen.tsx"] --> API
```

**Diagram sources**
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)
- [CharacterCreation.tsx:1-249](file://frontend/src/pages/CharacterCreation.tsx#L1-L249)
- [GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [SummaryScreen.tsx:1-177](file://frontend/src/pages/SummaryScreen.tsx#L1-L177)

**Section sources**
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)
- [CharacterCreation.tsx:1-249](file://frontend/src/pages/CharacterCreation.tsx#L1-L249)
- [GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [SummaryScreen.tsx:1-177](file://frontend/src/pages/SummaryScreen.tsx#L1-L177)

## Performance Considerations
- Minimize unnecessary re-renders by passing stable props and memoizing derived data
- Debounce or throttle rapid API calls (e.g., auto-play mode) to avoid overwhelming the backend
- Cache talent pools locally when appropriate to reduce network requests
- Use efficient UI rendering for long event logs and large summaries

## Troubleshooting Guide
- Common issues
  - Network errors: Verify base URL and CORS configuration
  - Validation errors: Ensure attribute totals and talent counts meet backend constraints
  - Game not found: Confirm game_id exists and the game is still active
- Frontend debugging
  - Log errors in catch blocks and display user-friendly messages
  - Inspect response payloads and error details
- Backend debugging
  - Review HTTP exceptions and detail messages
  - Validate model dumps and ensure consistent shapes

**Section sources**
- [api.ts:29-33](file://frontend/src/utils/api.ts#L29-L33)
- [api.ts:42-46](file://frontend/src/utils/api.ts#L42-L46)
- [api.ts:51-54](file://frontend/src/utils/api.ts#L51-L54)
- [router.py:26-30](file://backend/app/router.py#L26-L30)
- [router.py:51-58](file://backend/app/router.py#L51-L58)
- [router.py:64-68](file://backend/app/router.py#L64-L68)

## Conclusion
The API integration combines a centralized frontend client with strongly typed models and a robust backend built on FastAPI and Pydantic. The implementation emphasizes type safety, clear error handling, and straightforward request/response patterns. By following the established patterns and extending types.ts alongside api.ts, developers can reliably add new endpoints and integrate them into React components.

## Appendices

### API Function Reference
- fetchTalents
  - Purpose: Retrieve a random pool of talents
  - Method: GET
  - Path: /api/game/talents
  - Returns: Promise<Talent[]>
- startGame
  - Purpose: Start a new game
  - Method: POST
  - Path: /api/game/start
  - Body: { attributes: Attributes, talents: string[] }
  - Returns: Promise containing game metadata and initial state
- nextYear
  - Purpose: Advance the game by one year
  - Method: POST
  - Path: /api/game/next-year
  - Body: { game_id: string }
  - Returns: Promise<NextYearResponse>
- getSummary
  - Purpose: Retrieve life summary after game ends
  - Method: GET
  - Path: /api/game/summary/{game_id}
  - Returns: Promise<LifeSummary>

**Section sources**
- [api.ts:5-56](file://frontend/src/utils/api.ts#L5-L56)
- [router.py:11-68](file://backend/app/router.py#L11-L68)