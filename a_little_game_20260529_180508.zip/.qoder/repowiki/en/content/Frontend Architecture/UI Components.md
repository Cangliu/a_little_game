# UI Components

<cite>
**Referenced Files in This Document**
- [GameScreen.tsx](file://frontend/src/pages/GameScreen.tsx)
- [CharacterCreation.tsx](file://frontend/src/pages/CharacterCreation.tsx)
- [StartScreen.tsx](file://frontend/src/pages/StartScreen.tsx)
- [SummaryScreen.tsx](file://frontend/src/pages/SummaryScreen.tsx)
- [App.tsx](file://frontend/src/App.tsx)
- [types.ts](file://frontend/src/utils/types.ts)
- [api.ts](file://frontend/src/utils/api.ts)
- [index.css](file://frontend/src/index.css)
- [main.tsx](file://frontend/src/main.tsx)
- [vite.config.ts](file://frontend/vite.config.ts)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Accessibility and Responsive Design](#accessibility-and-responsive-design)
9. [Styling Patterns and Customization](#styling-patterns-and-customization)
10. [Troubleshooting Guide](#troubleshooting-guide)
11. [Conclusion](#conclusion)

## Introduction
This document focuses on the interactive user interface elements and user experience patterns across the application’s screens. It covers:
- Real-time simulation features in the GameScreen component, including event logging, auto-play, realm progression visualization, and attribute tracking
- Form handling and validation in the CharacterCreation component, including attribute sliders, talent selection, and feedback
- Navigation patterns and state transitions among StartScreen, CharacterCreation, GameScreen, and SummaryScreen
- Responsive design, realm color coding, progress indicators, and user interaction patterns
- Accessibility considerations, mobile responsiveness, and visual feedback mechanisms
- Examples of component customization and TailwindCSS styling patterns integrated with the overall application flow

## Project Structure
The UI is organized around four primary page components orchestrated by a single-page application shell. The pages communicate via props and a shared state machine, with centralized styling and animations.

```mermaid
graph TB
subgraph "Application Shell"
APP["App.tsx"]
end
subgraph "Screens"
START["StartScreen.tsx"]
CREATION["CharacterCreation.tsx"]
GAME["GameScreen.tsx"]
SUMMARY["SummaryScreen.tsx"]
end
subgraph "Utilities"
TYPES["types.ts"]
API["api.ts"]
end
subgraph "Styling"
CSS["index.css"]
VITE["vite.config.ts"]
end
APP --> START
APP --> CREATION
APP --> GAME
APP --> SUMMARY
START --> APP
CREATION --> APP
GAME --> APP
SUMMARY --> APP
CREATION --> API
GAME --> API
SUMMARY --> API
CREATION --> TYPES
GAME --> TYPES
SUMMARY --> TYPES
APP --> CSS
START --> CSS
CREATION --> CSS
GAME --> CSS
SUMMARY --> CSS
VITE --> CSS
```

**Diagram sources**
- [App.tsx:11-68](file://frontend/src/App.tsx#L11-L68)
- [StartScreen.tsx:7-339](file://frontend/src/pages/StartScreen.tsx#L7-L339)
- [CharacterCreation.tsx:20-248](file://frontend/src/pages/CharacterCreation.tsx#L20-L248)
- [GameScreen.tsx:13-260](file://frontend/src/pages/GameScreen.tsx#L13-L260)
- [SummaryScreen.tsx:12-176](file://frontend/src/pages/SummaryScreen.tsx#L12-L176)
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [index.css:1-311](file://frontend/src/index.css#L1-L311)
- [vite.config.ts:1-16](file://frontend/vite.config.ts#L1-L16)

**Section sources**
- [App.tsx:11-68](file://frontend/src/App.tsx#L11-L68)
- [vite.config.ts:1-16](file://frontend/vite.config.ts#L1-L16)

## Core Components
This section documents the interactive UI elements and UX patterns for each screen, focusing on user actions, state updates, and visual feedback.

- StartScreen
  - Purpose: Entrypoint with an immersive animated background and a prominent call-to-action
  - Interactions: Clicking the start button triggers a phase transition to CharacterCreation
  - Visuals: SVG-based celestial landscape, floating petal animations, and gradient text effects
  - Responsiveness: Uses flexbox and percentage-based sizing for scalable layouts

- CharacterCreation
  - Purpose: Allows players to allocate attribute points and select up to three talents
  - Interactions:
    - Attribute sliders with +/- buttons and a randomize feature
    - Talent pool selection with rarity badges and re-roll capability
    - Validation feedback and a confirm button that starts the game
  - Visuals: Scroll-style panels, gradient buttons, animated dividers, and progress bars
  - Responsiveness: Grid layout for talents and stacked sliders on small screens

- GameScreen
  - Purpose: Real-time life simulation with event logs, auto-play, and progression tracking
  - Interactions:
    - Year advancement via manual “Next Year” or automatic “Auto” mode
    - Realm progression visualization and attribute bars
    - Event log with type-specific styling and smooth scrolling
  - Visuals: Side status panel, main event log area, and bottom control bar
  - Responsiveness: Two-column layout on medium+ screens, single column on mobile

- SummaryScreen
  - Purpose: Presents life summary, key events, and a restart option
  - Interactions: Clicking restart returns to StartScreen
  - Visuals: Animated petals for ascension, score-based commentary, and final stats grid
  - Responsiveness: Centered card layout with scrollable sections

**Section sources**
- [StartScreen.tsx:7-339](file://frontend/src/pages/StartScreen.tsx#L7-L339)
- [CharacterCreation.tsx:20-248](file://frontend/src/pages/CharacterCreation.tsx#L20-L248)
- [GameScreen.tsx:13-260](file://frontend/src/pages/GameScreen.tsx#L13-L260)
- [SummaryScreen.tsx:12-176](file://frontend/src/pages/SummaryScreen.tsx#L12-L176)

## Architecture Overview
The application uses a simple state machine to manage navigation between screens. Each screen is self-contained and receives data via props or external APIs.

```mermaid
sequenceDiagram
participant U as "User"
participant S as "StartScreen"
participant C as "CharacterCreation"
participant G as "GameScreen"
participant SM as "SummaryScreen"
participant A as "App"
U->>S : Click "Start New Life"
S-->>A : onStart()
A->>A : setPhase("creation")
A-->>C : Render CharacterCreation
U->>C : Adjust attributes / Select talents
C-->>A : onConfirm(attributes, talents)
A->>A : startGame() via API
A->>G : Render GameScreen with gameId, initialAttrs, initialTalents
A->>G : onGameEnd(gameId)
G-->>A : onGameEnd(gameId)
A->>SM : Render SummaryScreen with gameId
U->>SM : Click "Reincarnate"
SM-->>A : onRestart()
A->>A : setPhase("start"), reset state
```

**Diagram sources**
- [App.tsx:24-50](file://frontend/src/App.tsx#L24-L50)
- [CharacterCreation.tsx:20-248](file://frontend/src/pages/CharacterCreation.tsx#L20-L248)
- [GameScreen.tsx:13-260](file://frontend/src/pages/GameScreen.tsx#L13-L260)
- [SummaryScreen.tsx:12-176](file://frontend/src/pages/SummaryScreen.tsx#L12-L176)
- [api.ts:11-34](file://frontend/src/utils/api.ts#L11-L34)

## Detailed Component Analysis

### GameScreen: Real-time Simulation and UX
Key features:
- Event logging display with type-specific styling and smooth scrolling to latest entries
- Auto-play functionality with controlled toggling and debounced rapid advancement
- Realm progression visualization with color-coded names and progress bars
- Attribute tracking with proportional bars and numeric displays
- Loading states and graceful handling of game over conditions

```mermaid
flowchart TD
Start(["User clicks 'Next Year'"]) --> CheckLoading{"Loading or Game Over?"}
CheckLoading --> |Yes| Exit["Do Nothing"]
CheckLoading --> |No| CallAPI["Call nextYear(gameId)"]
CallAPI --> UpdateState["Update age, realm, cultivation, attrs, events"]
UpdateState --> IsGameOver{"Is Dead or Ascended?"}
IsGameOver --> |Yes| SetGameOver["Set isGameOver=true, stop auto-play"]
SetGameOver --> Delay["Wait 2s"]
Delay --> TriggerEnd["Trigger onGameEnd(gameId)"]
IsGameOver --> |No| AutoOn{"Auto Play On?"}
AutoOn --> |Yes| Delay2["Wait 400ms"]
Delay2 --> Recursive["Call advanceYear() again"]
AutoOn --> |No| Exit
```

**Diagram sources**
- [GameScreen.tsx:40-74](file://frontend/src/pages/GameScreen.tsx#L40-L74)
- [api.ts:36-47](file://frontend/src/utils/api.ts#L36-L47)

User interactions and feedback:
- Manual control: Disabled during auto-play; shows “Advancing...” state
- Auto control: Toggles auto-play; changes button style and hover states
- Event log: Smooth scroll to bottom; staggered animations per event
- Progress bars: Transition-based width updates; gradient styling for depth

Realm color coding and progress:
- Realm names mapped to colors via constants; applied to current realm display
- Cultivation progress bar with gradient and capped percentage
- Attribute bars sized proportionally to current values

Validation and error handling:
- Defensive checks prevent concurrent API calls and redundant actions
- Auto-play is halted on errors and disabled until user intervention

Customization examples:
- Modify event line classes to add new types
- Adjust progress bar gradients and timing in CSS
- Extend realm names and colors in types

**Section sources**
- [GameScreen.tsx:19-260](file://frontend/src/pages/GameScreen.tsx#L19-L260)
- [types.ts:65-98](file://frontend/src/utils/types.ts#L65-L98)
- [index.css:179-205](file://frontend/src/index.css#L179-L205)

### CharacterCreation: Form Handling and Validation
Key features:
- Attribute sliders with constrained adjustment (+/- buttons, randomize)
- Talent selection with rarity badges, selection limits, and re-roll
- Validation feedback and a confirm action that starts the game
- Animated entrance and scroll-style panels

```mermaid
flowchart TD
Init["Initialize defaults and fetch talents"] --> Adjust["Adjust attribute by +1 or -1"]
Adjust --> Validate{"Within bounds and point budget?"}
Validate --> |No| Block["Ignore change"]
Validate --> |Yes| Update["Update state"]
Update --> Recalc["Recalculate remaining points"]
Recalc --> CanStart{"Selected >= 1 and remaining >= 0?"}
CanStart --> |No| Disable["Disable Confirm"]
CanStart --> |Yes| Enable["Enable Confirm"]
Enable --> Confirm["onConfirm(attrs, selectedTalents)"]
Disable --> Confirm
```

**Diagram sources**
- [CharacterCreation.tsx:38-78](file://frontend/src/pages/CharacterCreation.tsx#L38-L78)
- [api.ts:5-9](file://frontend/src/utils/api.ts#L5-L9)

User interactions and feedback:
- Point budget enforcement prevents overspending
- Selection limit enforces up to three talents
- Rarity badges provide immediate visual hierarchy
- Re-roll talent pool refreshes asynchronously

Accessibility and responsiveness:
- Buttons sized for touch targets
- Clear visual feedback for disabled states
- Grid layout adapts to smaller screens

Customization examples:
- Increase maximum points or per-attribute cap
- Add new talent rarities and associated styles
- Expand attribute set by updating types and rendering loop

**Section sources**
- [CharacterCreation.tsx:20-248](file://frontend/src/pages/CharacterCreation.tsx#L20-L248)
- [types.ts:100-112](file://frontend/src/utils/types.ts#L100-L112)
- [index.css:157-177](file://frontend/src/index.css#L157-L177)

### StartScreen: Navigation and State Transitions
Key features:
- Immersive animated background with SVG elements and floating particles
- Prominent call-to-action button that triggers the transition to CharacterCreation
- Subtle entrance animation and decorative corner accents

Navigation pattern:
- Single action: click “Start New Life”
- Triggers App-level state change to creation phase

Responsive design:
- Flex-centered layout with percentage-based widths
- Typography scales with viewport size

Customization examples:
- Adjust SVG gradients and shapes for alternate themes
- Modify entrance animation curve and duration
- Change button styling to match evolving brand guidelines

**Section sources**
- [StartScreen.tsx:7-339](file://frontend/src/pages/StartScreen.tsx#L7-L339)
- [App.tsx:24-26](file://frontend/src/App.tsx#L24-L26)

### SummaryScreen: Results Presentation and Restart
Key features:
- Asynchronous loading of life summary
- Conditional animations for ascension outcomes
- Score-based commentary and key events timeline
- Restart button returning to StartScreen

UX patterns:
- Fade-in reveal after data load
- Highlighted stats with realm color coding
- Scrollable key events for long summaries

Customization examples:
- Add new outcome categories and associated visuals
- Extend scoring thresholds and messages
- Introduce export or share functionality

**Section sources**
- [SummaryScreen.tsx:12-176](file://frontend/src/pages/SummaryScreen.tsx#L12-L176)
- [types.ts:53-63](file://frontend/src/utils/types.ts#L53-L63)
- [api.ts:49-56](file://frontend/src/utils/api.ts#L49-L56)

## Dependency Analysis
The UI components depend on shared types, utilities, and centralized styling. The App orchestrates state and passes data down to child components.

```mermaid
graph LR
TYPES["types.ts"] --> CREATION["CharacterCreation.tsx"]
TYPES --> GAME["GameScreen.tsx"]
TYPES --> SUMMARY["SummaryScreen.tsx"]
API["api.ts"] --> CREATION
API --> GAME
API --> SUMMARY
CSS["index.css"] --> START["StartScreen.tsx"]
CSS --> CREATION
CSS --> GAME
CSS --> SUMMARY
APP["App.tsx"] --> START
APP --> CREATION
APP --> GAME
APP --> SUMMARY
```

**Diagram sources**
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [index.css:1-311](file://frontend/src/index.css#L1-L311)
- [App.tsx:11-68](file://frontend/src/App.tsx#L11-L68)

**Section sources**
- [App.tsx:11-68](file://frontend/src/App.tsx#L11-L68)
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [index.css:1-311](file://frontend/src/index.css#L1-L311)

## Performance Considerations
- Minimize re-renders by passing memoized callbacks and stable prop references
- Debounce rapid user actions (e.g., auto-play) to avoid excessive API calls
- Virtualize long event lists if summaries grow very large
- Lazy-load talent images if added later
- Use CSS transforms and opacity for animations to leverage GPU acceleration

## Accessibility and Responsive Design
Accessibility:
- Ensure sufficient color contrast for realm names and progress bars
- Provide focus-visible styles for keyboard navigation
- Use semantic headings and landmarks for screen readers
- Announce dynamic content changes (e.g., “Game Over” state) to assistive technologies

Responsive design:
- Mobile-first breakpoints: side panel stacks below main content on small screens
- Touch-friendly controls with adequate spacing and hit areas
- Flexible grids for talent selection and attribute displays
- Viewport units and relative typography for scalable text

## Styling Patterns and Customization
TailwindCSS and custom utilities:
- Theme tokens for scroll-like palettes and fonts
- Component utilities for ancient buttons, scroll panels, and event lines
- Animations for floating petals, glows, and pulse effects
- Gradient backgrounds and backdrop filters for depth

Customization examples:
- Add new realm colors by extending the color map and updating realm display logic
- Introduce new event types by adding CSS classes and mapping in the event line function
- Adjust button styles by modifying the ancient-button utility and its variants
- Extend progress bars by adding new gradient stops or transition durations

Integration with the overall flow:
- Centralized theme and animations in index.css
- Component-specific styles layered on top of base utilities
- Vite + Tailwind plugin pipeline configured for development and production

**Section sources**
- [index.css:3-311](file://frontend/src/index.css#L3-L311)
- [vite.config.ts:1-16](file://frontend/vite.config.ts#L1-L16)
- [main.tsx:1-11](file://frontend/src/main.tsx#L1-L11)

## Troubleshooting Guide
Common issues and resolutions:
- API failures during game start or next year:
  - Verify backend endpoint availability and CORS proxy configuration
  - Inspect response payloads for error details
- Auto-play not stopping on errors:
  - Ensure error handlers disable auto-play and surface user-facing messages
- Attribute slider overflow:
  - Confirm budget calculations and per-attribute caps
- Talent selection not enabling confirm:
  - Check selection count and remaining point logic
- Summary not loading:
  - Validate game ID propagation and API route correctness

**Section sources**
- [api.ts:24-34](file://frontend/src/utils/api.ts#L24-L34)
- [api.ts:36-47](file://frontend/src/utils/api.ts#L36-L47)
- [api.ts:49-56](file://frontend/src/utils/api.ts#L49-L56)
- [vite.config.ts:7-14](file://frontend/vite.config.ts#L7-L14)

## Conclusion
The UI components deliver a cohesive, immersive experience across four distinct screens. GameScreen excels at real-time simulation with robust event logging and auto-play controls. CharacterCreation balances flexibility and validation to guide meaningful character builds. StartScreen and SummaryScreen anchor the narrative with strong visual storytelling and seamless navigation. Together with centralized styling and responsive patterns, the UI supports both desktop and mobile play, with clear pathways for future enhancements.