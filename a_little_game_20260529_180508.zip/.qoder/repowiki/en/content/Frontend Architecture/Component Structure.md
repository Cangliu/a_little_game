# Component Structure

<cite>
**Referenced Files in This Document**
- [App.tsx](file://frontend/src/App.tsx)
- [StartScreen.tsx](file://frontend/src/pages/StartScreen.tsx)
- [CharacterCreation.tsx](file://frontend/src/pages/CharacterCreation.tsx)
- [GameScreen.tsx](file://frontend/src/pages/GameScreen.tsx)
- [SummaryScreen.tsx](file://frontend/src/pages/SummaryScreen.tsx)
- [api.ts](file://frontend/src/utils/api.ts)
- [types.ts](file://frontend/src/utils/types.ts)
- [main.tsx](file://frontend/src/main.tsx)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the React component hierarchy and organization of the application. It focuses on the main App component’s phase-based routing (start, creation, playing, summary), prop passing patterns, and component lifecycle. It also documents the page-level components (StartScreen, CharacterCreation, GameScreen, SummaryScreen), their composition patterns, state synchronization, and integration with the global application state. The goal is to help developers understand how components interact, how state flows, and how to extend or modify the system safely.

## Project Structure
The frontend is organized around a small set of page-level components under a single entry point. The App component orchestrates navigation between screens and maintains shared application state. Utility modules define types and API helpers used across components.

```mermaid
graph TB
subgraph "Entry Point"
MAIN["main.tsx"]
end
subgraph "Application Shell"
APP["App.tsx"]
end
subgraph "Pages"
START["StartScreen.tsx"]
CREATION["CharacterCreation.tsx"]
GAME["GameScreen.tsx"]
SUMMARY["SummaryScreen.tsx"]
end
subgraph "Utilities"
TYPES["types.ts"]
API["api.ts"]
end
MAIN --> APP
APP --> START
APP --> CREATION
APP --> GAME
APP --> SUMMARY
START --> TYPES
CREATION --> TYPES
CREATION --> API
GAME --> TYPES
GAME --> API
SUMMARY --> TYPES
SUMMARY --> API
APP --> API
```

**Diagram sources**
- [main.tsx:1-11](file://frontend/src/main.tsx#L1-L11)
- [App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)
- [StartScreen.tsx:1-193](file://frontend/src/pages/StartScreen.tsx#L1-L193)
- [CharacterCreation.tsx:1-249](file://frontend/src/pages/CharacterCreation.tsx#L1-L249)
- [GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [SummaryScreen.tsx:1-177](file://frontend/src/pages/SummaryScreen.tsx#L1-L177)
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)

**Section sources**
- [main.tsx:1-11](file://frontend/src/main.tsx#L1-L11)
- [App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)

## Core Components
- App: Central state container and router. Manages the current phase, game identifiers, and player attributes/talents. Renders one of four screens based on phase and passes props down to child components.
- StartScreen: Initial landing screen with animated entrance and a start action handler.
- CharacterCreation: Attribute distribution panel and talent selection panel with validation and randomization.
- GameScreen: Real-time simulation with year advancement, event log, progress bars, and auto-play controls.
- SummaryScreen: Lifecycle summary with stats, final attributes, and key events.

Key state and props:
- App manages:
  - Phase: 'start' | 'creation' | 'playing' | 'summary'
  - Game identifier
  - Player attributes and talents
  - Handlers to transition between phases and pass data forward
- Child components receive only what they need via props, avoiding deep prop drilling.

**Section sources**
- [App.tsx:9-72](file://frontend/src/App.tsx#L9-L72)
- [StartScreen.tsx:3-5](file://frontend/src/pages/StartScreen.tsx#L3-L5)
- [CharacterCreation.tsx:6-8](file://frontend/src/pages/CharacterCreation.tsx#L6-L8)
- [GameScreen.tsx:6-11](file://frontend/src/pages/GameScreen.tsx#L6-L11)
- [SummaryScreen.tsx:7-10](file://frontend/src/pages/SummaryScreen.tsx#L7-L10)

## Architecture Overview
The application follows a straightforward, top-down data flow:
- App holds global state and routes to the current screen.
- Each page-level component is responsible for its own internal state and UI.
- API utilities encapsulate network requests and response parsing.
- Types define the shape of data passed across boundaries.

```mermaid
sequenceDiagram
participant Root as "main.tsx"
participant App as "App.tsx"
participant Start as "StartScreen.tsx"
participant Creation as "CharacterCreation.tsx"
participant Game as "GameScreen.tsx"
participant Summary as "SummaryScreen.tsx"
participant API as "api.ts"
participant Types as "types.ts"
Root->>App : Render <App/>
App->>Start : Render phase=start
Start->>App : onStart()
App->>App : setPhase("creation")
App->>Creation : Render phase=creation
Creation->>App : onConfirm(attrs, talents)
App->>API : startGame(attrs, talents)
API-->>App : {game_id, attributes, ...}
App->>App : setGameId, setPlayerAttrs, setPlayerTalents
App->>App : setPhase("playing")
App->>Game : Render phase=playing
Game->>API : nextYear(gameId)
API-->>Game : NextYearResponse
Game->>App : onGameEnd(gameId)
App->>App : setPhase("summary")
App->>Summary : Render phase=summary
Summary->>API : getSummary(gameId)
API-->>Summary : LifeSummary
Summary->>App : onRestart()
App->>App : reset phase and state
```

**Diagram sources**
- [main.tsx:6-9](file://frontend/src/main.tsx#L6-L9)
- [App.tsx:24-50](file://frontend/src/App.tsx#L24-L50)
- [StartScreen.tsx:173-178](file://frontend/src/pages/StartScreen.tsx#L173-L178)
- [CharacterCreation.tsx:230-238](file://frontend/src/pages/CharacterCreation.tsx#L230-L238)
- [api.ts:11-34](file://frontend/src/utils/api.ts#L11-L34)
- [GameScreen.tsx:40-65](file://frontend/src/pages/GameScreen.tsx#L40-L65)
- [SummaryScreen.tsx:16-21](file://frontend/src/pages/SummaryScreen.tsx#L16-L21)

## Detailed Component Analysis

### App Component
Responsibilities:
- Maintains application-wide state: phase, game ID, player attributes, and talents.
- Implements phase-based rendering of StartScreen, CharacterCreation, GameScreen, and SummaryScreen.
- Provides handlers to move between phases and synchronize state with backend.

State and handlers:
- State: phase, gameId, playerAttrs, playerTalents
- Handlers:
  - handleStart: transitions to character creation
  - handleConfirm: starts the game via API, updates state, transitions to playing
  - handleGameEnd: sets phase to summary after game completion
  - handleRestart: resets to start with empty state

Prop passing patterns:
- Passes props to children based on current phase:
  - StartScreen receives onStart
  - CharacterCreation receives onConfirm
  - GameScreen receives gameId, initialAttrs, initialTalents, onGameEnd
  - SummaryScreen receives gameId, onRestart

Lifecycle:
- Uses React state and effects to manage transitions and UI feedback.
- No custom lifecycle hooks beyond standard useState/useEffect.

**Section sources**
- [App.tsx:11-72](file://frontend/src/App.tsx#L11-L72)

### StartScreen
Responsibilities:
- Presents the initial screen with decorative animations and a start button.
- Triggers the transition to character creation via a callback prop.

Props:
- onStart: function invoked when the user clicks the start button.

Lifecycle:
- Uses useEffect to trigger an entrance animation after mount.

UI composition:
- Uses inline SVG for background art and floating elements.
- Applies Tailwind-based classes for layout and transitions.

**Section sources**
- [StartScreen.tsx:7-193](file://frontend/src/pages/StartScreen.tsx#L7-L193)

### CharacterCreation
Responsibilities:
- Allows players to allocate attribute points and select up to three talents.
- Validates selections and provides randomization and reroll capabilities.

Internal state:
- Local state for attributes, talent pool, selected talents, loading, and UI show state.

Validation and constraints:
- Enforces a maximum total point allocation and per-attribute bounds.
- Limits talent selection to three.
- Disables confirm until validation passes.

API integration:
- Fetches talent pool on mount.
- Calls onConfirm with validated attributes and talents when confirmed.

UI composition:
- Grid-based layout with attribute sliders and talent cards.
- Conditional styling based on rarity and selection state.

**Section sources**
- [CharacterCreation.tsx:20-249](file://frontend/src/pages/CharacterCreation.tsx#L20-L249)
- [api.ts:5-9](file://frontend/src/utils/api.ts#L5-L9)

### GameScreen
Responsibilities:
- Drives the real-time simulation by advancing the year and displaying events.
- Displays realm progression, attributes, and an event log.
- Supports manual and automatic play modes.

Internal state:
- Age, realm, realm name, cultivation, cultivation max, attributes, event log, game over flag, loading, auto-play flag.
- Uses refs to track auto-play state and scroll position.

Event handling:
- advanceYear: async operation that calls the backend, updates state, and handles game over conditions.
- toggleAutoPlay: switches between manual and continuous play.

UI composition:
- Side panel for status and attributes.
- Main content area for event log with age separators.
- Bottom control bar with buttons for advancing and toggling auto-play.

**Section sources**
- [GameScreen.tsx:13-261](file://frontend/src/pages/GameScreen.tsx#L13-L261)
- [api.ts:36-47](file://frontend/src/utils/api.ts#L36-L47)

### SummaryScreen
Responsibilities:
- Displays the life summary after the game ends, including stats, final attributes, and key events.
- Provides a restart option to return to the start screen.

Internal state:
- Summary data and UI show state.

API integration:
- Fetches summary data on mount and after game completion.

UI composition:
- Grid layout for core stats and final attributes.
- Scrollable list for key events.
- Conditional decorations for ascension outcomes.

**Section sources**
- [SummaryScreen.tsx:12-177](file://frontend/src/pages/SummaryScreen.tsx#L12-L177)
- [api.ts:49-56](file://frontend/src/utils/api.ts#L49-L56)

### Type System and API Layer
Types:
- Defines Attributes, Talent, GameEvent, GameState, NextYearResponse, and LifeSummary interfaces.
- Provides constants for realm names, colors, attribute names, and rarity metadata.

API:
- Encapsulates backend endpoints for talents, starting a game, advancing years, and retrieving summaries.
- Handles error responses and throws descriptive errors.

Integration:
- Components import types and API functions to remain decoupled from backend specifics.

**Section sources**
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)

## Architecture Overview

```mermaid
classDiagram
class App {
+phase : "start"|"creation"|"playing"|"summary"
+gameId : string
+playerAttrs : Attributes
+playerTalents : string[]
+handleStart()
+handleConfirm(attrs, talents)
+handleGameEnd(gameId)
+handleRestart()
}
class StartScreen {
+props : { onStart }
+useEffect()
}
class CharacterCreation {
+attrs : Attributes
+talentPool : Talent[]
+selectedTalents : string[]
+loading : boolean
+adjustAttr(key, delta)
+toggleTalent(id)
+randomize()
+rerollTalents()
+onConfirm(attrs, talents)
}
class GameScreen {
+age : number
+realm : number
+realmName : string
+cultivation : number
+cultivationMax : number
+attrs : Attributes
+eventLog : GameEvent[]
+isGameOver : boolean
+loading : boolean
+autoPlay : boolean
+advanceYear()
+toggleAutoPlay()
}
class SummaryScreen {
+summary : LifeSummary
+show : boolean
}
class API {
+fetchTalents()
+startGame(attrs, talents)
+nextYear(gameId)
+getSummary(gameId)
}
class Types {
<<interfaces>>
}
App --> StartScreen : "renders when phase=start"
App --> CharacterCreation : "renders when phase=creation"
App --> GameScreen : "renders when phase=playing"
App --> SummaryScreen : "renders when phase=summary"
CharacterCreation --> API : "uses"
GameScreen --> API : "uses"
SummaryScreen --> API : "uses"
App --> API : "uses"
StartScreen --> Types : "uses"
CharacterCreation --> Types : "uses"
GameScreen --> Types : "uses"
SummaryScreen --> Types : "uses"
```

**Diagram sources**
- [App.tsx:11-72](file://frontend/src/App.tsx#L11-L72)
- [StartScreen.tsx:7-193](file://frontend/src/pages/StartScreen.tsx#L7-L193)
- [CharacterCreation.tsx:20-249](file://frontend/src/pages/CharacterCreation.tsx#L20-L249)
- [GameScreen.tsx:13-261](file://frontend/src/pages/GameScreen.tsx#L13-L261)
- [SummaryScreen.tsx:12-177](file://frontend/src/pages/SummaryScreen.tsx#L12-L177)
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)

## Detailed Component Analysis

### Phase-Based Routing and State Synchronization
- App maintains a single source of truth for the current phase and game state.
- Handlers update state and trigger re-renders, ensuring child components receive fresh props.
- GameScreen persists initial attributes and talents via props to avoid losing state during gameplay.

```mermaid
flowchart TD
Start(["App: start"]) --> Creation["App: creation"]
Creation --> Playing["App: playing"]
Playing --> Summary["App: summary"]
Summary --> Start
```

**Diagram sources**
- [App.tsx:24-50](file://frontend/src/App.tsx#L24-L50)

**Section sources**
- [App.tsx:24-50](file://frontend/src/App.tsx#L24-L50)

### Prop Passing Patterns
- Top-down props: App passes only the necessary data to each child.
- Callbacks: Children call back into App to signal transitions and data submission.
- Example patterns:
  - StartScreen.onStart -> App.handleStart
  - CharacterCreation.onConfirm -> App.handleConfirm
  - GameScreen.onGameEnd -> App.handleGameEnd
  - SummaryScreen.onRestart -> App.handleRestart

Benefits:
- Predictable data flow
- Easy testing and mocking of callbacks
- Minimal coupling between siblings

**Section sources**
- [StartScreen.tsx:173-178](file://frontend/src/pages/StartScreen.tsx#L173-L178)
- [CharacterCreation.tsx:230-238](file://frontend/src/pages/CharacterCreation.tsx#L230-L238)
- [GameScreen.tsx:40-65](file://frontend/src/pages/GameScreen.tsx#L40-L65)
- [SummaryScreen.tsx:16-21](file://frontend/src/pages/SummaryScreen.tsx#L16-L21)

### Component Interaction Flows

#### Character Creation to Gameplay
```mermaid
sequenceDiagram
participant C as "CharacterCreation"
participant A as "App"
participant B as "Backend API"
C->>A : onConfirm(attrs, talents)
A->>B : startGame(attrs, talents)
B-->>A : {game_id, attributes, ...}
A->>A : setGameId, setPlayerAttrs, setPlayerTalents
A->>A : setPhase("playing")
```

**Diagram sources**
- [CharacterCreation.tsx:230-238](file://frontend/src/pages/CharacterCreation.tsx#L230-L238)
- [App.tsx:28-39](file://frontend/src/App.tsx#L28-L39)
- [api.ts:11-34](file://frontend/src/utils/api.ts#L11-L34)

#### Year Advancement in Gameplay
```mermaid
sequenceDiagram
participant G as "GameScreen"
participant A as "App"
participant B as "Backend API"
G->>G : advanceYear()
G->>B : nextYear(gameId)
B-->>G : NextYearResponse
G->>G : update state (age, realm, attrs, events)
alt Game Over
G->>A : onGameEnd(gameId)
A->>A : setPhase("summary")
else Continue
opt Auto-play
G->>G : schedule next advanceYear()
end
end
```

**Diagram sources**
- [GameScreen.tsx:40-65](file://frontend/src/pages/GameScreen.tsx#L40-L65)
- [api.ts:36-47](file://frontend/src/utils/api.ts#L36-L47)
- [App.tsx:41-44](file://frontend/src/App.tsx#L41-L44)

### State Management Approach
- Centralized state in App with local state inside pages for UI-only concerns.
- Props carry data down; callbacks carry events up.
- No external state management library is used; React’s built-in hooks suffice.

Best practices observed:
- Keep components pure where possible (e.g., UI-only state).
- Use refs sparingly for flags and DOM references (e.g., autoPlayRef, logEndRef).
- Validate inputs before calling APIs (e.g., CharacterCreation validation).

**Section sources**
- [App.tsx:11-72](file://frontend/src/App.tsx#L11-L72)
- [CharacterCreation.tsx:27-78](file://frontend/src/pages/CharacterCreation.tsx#L27-L78)
- [GameScreen.tsx:30-34](file://frontend/src/pages/GameScreen.tsx#L30-L34)

### Reusability and Composition
- Page components are self-contained and reusable as-is.
- Shared UI constants (colors, names) are centralized in types for reuse across components.
- API functions encapsulate network logic, enabling easy replacement or extension.

**Section sources**
- [types.ts:65-113](file://frontend/src/utils/types.ts#L65-L113)
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)

### Prop Validation and Type Safety
- Strongly typed props for each page component using interfaces from types.ts.
- API functions return typed responses, reducing runtime errors.
- Consider adding runtime validation (e.g., Zod) if the project grows and needs stricter input guarantees.

**Section sources**
- [types.ts:1-63](file://frontend/src/utils/types.ts#L1-L63)
- [api.ts:11-56](file://frontend/src/utils/api.ts#L11-L56)

## Dependency Analysis

```mermaid
graph LR
APP["App.tsx"] --> START["StartScreen.tsx"]
APP --> CREATION["CharacterCreation.tsx"]
APP --> GAME["GameScreen.tsx"]
APP --> SUMMARY["SummaryScreen.tsx"]
START --> TYPES["types.ts"]
CREATION --> TYPES
CREATION --> API["api.ts"]
GAME --> TYPES
GAME --> API
SUMMARY --> TYPES
SUMMARY --> API
API --> TYPES
```

**Diagram sources**
- [App.tsx:1-7](file://frontend/src/App.tsx#L1-L7)
- [StartScreen.tsx:1-7](file://frontend/src/pages/StartScreen.tsx#L1-L7)
- [CharacterCreation.tsx:1-4](file://frontend/src/pages/CharacterCreation.tsx#L1-L4)
- [GameScreen.tsx:1-4](file://frontend/src/pages/GameScreen.tsx#L1-L4)
- [SummaryScreen.tsx:1-5](file://frontend/src/pages/SummaryScreen.tsx#L1-L5)
- [api.ts:1](file://frontend/src/utils/api.ts#L1)
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)

Observations:
- Low coupling between pages; App acts as a coordinator.
- Utilities are consumed by pages and App, maintaining a clean separation.
- No circular dependencies detected among the analyzed files.

**Section sources**
- [App.tsx:1-7](file://frontend/src/App.tsx#L1-L7)
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)

## Performance Considerations
- Minimal re-renders: App only re-renders when phase or state changes; pages render conditionally.
- Efficient UI updates: GameScreen uses refs for auto-play state and logs scrolling.
- API calls are throttled by loading flags to prevent concurrent requests.
- Consider memoizing expensive computations (e.g., attribute totals) if needed.

## Troubleshooting Guide
Common issues and resolutions:
- API failures:
  - startGame and nextYear throw errors on non-OK responses; App catches and alerts the user.
  - SummaryScreen and nextYear also throw on failure; ensure backend endpoints are reachable.
- State resets:
  - handleRestart clears phase and state; verify that all child components reset appropriately.
- Auto-play glitches:
  - autoPlayRef ensures the latest value is used inside closures; verify that toggleAutoPlay is called correctly.

**Section sources**
- [App.tsx:35-38](file://frontend/src/App.tsx#L35-L38)
- [GameScreen.tsx:60-64](file://frontend/src/pages/GameScreen.tsx#L60-L64)
- [api.ts:29-32](file://frontend/src/utils/api.ts#L29-L32)
- [api.ts:42-45](file://frontend/src/utils/api.ts#L42-L45)

## Conclusion
The component structure is intentionally simple and focused on clarity and maintainability. App coordinates a clean, phase-based flow with minimal prop drilling and strong typing. Pages encapsulate their own UI concerns and communicate with App and the backend through well-defined props and callbacks. This design supports easy extension, testing, and future enhancements such as adding a global state manager if needed.