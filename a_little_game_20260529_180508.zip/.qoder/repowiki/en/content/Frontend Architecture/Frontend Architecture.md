# Frontend Architecture

<cite>
**Referenced Files in This Document**
- [App.tsx](file://frontend/src/App.tsx)
- [main.tsx](file://frontend/src/main.tsx)
- [StartScreen.tsx](file://frontend/src/pages/StartScreen.tsx)
- [CharacterCreation.tsx](file://frontend/src/pages/CharacterCreation.tsx)
- [GameScreen.tsx](file://frontend/src/pages/GameScreen.tsx)
- [SummaryScreen.tsx](file://frontend/src/pages/SummaryScreen.tsx)
- [api.ts](file://frontend/src/utils/api.ts)
- [types.ts](file://frontend/src/utils/types.ts)
- [index.css](file://frontend/src/index.css)
- [package.json](file://frontend/package.json)
- [vite.config.ts](file://frontend/vite.config.ts)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the frontend architecture of the React TypeScript Single Page Application for the life renaissance simulation game. It covers the component hierarchy, state management patterns, centralized API client, error handling, TypeScript interfaces, real-time simulation UI with auto-play, event logging, responsive design, routing, component composition, and backend integration. It also highlights prop drilling solutions, performance optimizations, and user interaction flows.

## Project Structure
The frontend is organized around a small set of page-level components and shared utilities:
- Pages: StartScreen, CharacterCreation, GameScreen, SummaryScreen
- Utilities: API client and TypeScript type definitions
- Styles: Tailwind-based design tokens and animations
- Build and dev server: Vite with React and Tailwind plugins, plus a development proxy to the backend

```mermaid
graph TB
subgraph "Entry"
MAIN["main.tsx"]
APP["App.tsx"]
end
subgraph "Pages"
START["StartScreen.tsx"]
CHAR["CharacterCreation.tsx"]
GAME["GameScreen.tsx"]
SUM["SummaryScreen.tsx"]
end
subgraph "Utilities"
API["utils/api.ts"]
TYPES["utils/types.ts"]
end
subgraph "Styles"
CSS["index.css"]
end
subgraph "Build & Dev"
PKG["package.json"]
VITE["vite.config.ts"]
end
MAIN --> APP
APP --> START
APP --> CHAR
APP --> GAME
APP --> SUM
CHAR --> API
GAME --> API
SUM --> API
START --> CSS
CHAR --> CSS
GAME --> CSS
SUM --> CSS
APP --> TYPES
CHAR --> TYPES
GAME --> TYPES
SUM --> TYPES
PKG --> VITE
VITE --> API
```

**Diagram sources**
- [main.tsx:1-11](file://frontend/src/main.tsx#L1-L11)
- [App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)
- [StartScreen.tsx:1-193](file://frontend/src/pages/StartScreen.tsx#L1-L193)
- [CharacterCreation.tsx:1-249](file://frontend/src/pages/CharacterCreation.tsx#L1-L249)
- [GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [SummaryScreen.tsx:1-177](file://frontend/src/pages/SummaryScreen.tsx#L1-L177)
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)
- [index.css:1-277](file://frontend/src/index.css#L1-L277)
- [package.json:1-33](file://frontend/package.json#L1-L33)
- [vite.config.ts:1-16](file://frontend/vite.config.ts#L1-L16)

**Section sources**
- [main.tsx:1-11](file://frontend/src/main.tsx#L1-L11)
- [App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)
- [package.json:1-33](file://frontend/package.json#L1-L33)
- [vite.config.ts:1-16](file://frontend/vite.config.ts#L1-L16)

## Core Components
- App orchestrates the game lifecycle via a phase state machine and passes data down to page components.
- StartScreen renders the opening cinematic and triggers character creation.
- CharacterCreation manages attribute distribution and talent selection, then confirms to start the game.
- GameScreen handles real-time simulation with auto-play, event logging, and progress visualization.
- SummaryScreen fetches and displays the life summary after the game ends.

Key state management patterns:
- Centralized phase state in App controls which page is rendered.
- Player attributes and talents are passed down to GameScreen and persisted across transitions.
- GameScreen maintains local state for current age, realm, cultivation, attributes, event log, and auto-play flag.

**Section sources**
- [App.tsx:9-72](file://frontend/src/App.tsx#L9-L72)
- [StartScreen.tsx:1-193](file://frontend/src/pages/StartScreen.tsx#L1-L193)
- [CharacterCreation.tsx:1-249](file://frontend/src/pages/CharacterCreation.tsx#L1-L249)
- [GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [SummaryScreen.tsx:1-177](file://frontend/src/pages/SummaryScreen.tsx#L1-L177)

## Architecture Overview
The frontend follows a straightforward page-based composition pattern with a centralized App container. Routing is implemented via a simple phase-based switch rather than a traditional router. The API client encapsulates backend communication with typed responses and robust error handling. Styling leverages Tailwind with custom design tokens and layered animations.

```mermaid
sequenceDiagram
participant U as "User"
participant S as "StartScreen"
participant C as "CharacterCreation"
participant A as "App"
participant G as "GameScreen"
participant SU as "SummaryScreen"
participant API as "API Client"
U->>S : Click "Start"
S-->>A : onStart()
A->>C : Render with onConfirm handler
U->>C : Adjust attributes/talents and confirm
C->>API : startGame(attributes, talents)
API-->>C : {game_id, attributes, talents,...}
C-->>A : onConfirm(result)
A->>G : Render with gameId, initialAttrs, initialTalents
loop Year progression
U->>G : Click "Next Year" or Auto
G->>API : nextYear(gameId)
API-->>G : {events, attributes, is_dead, is_ascended,...}
G-->>U : Update UI (age, realm, events)
end
G->>SU : onGameEnd(gameId)
SU->>API : getSummary(gameId)
API-->>SU : LifeSummary
SU-->>A : onRestart()
A-->>S : Reset to start
```

**Diagram sources**
- [App.tsx:24-50](file://frontend/src/App.tsx#L24-L50)
- [CharacterCreation.tsx:28-39](file://frontend/src/pages/CharacterCreation.tsx#L28-L39)
- [GameScreen.tsx:40-65](file://frontend/src/pages/GameScreen.tsx#L40-L65)
- [SummaryScreen.tsx:16-21](file://frontend/src/pages/SummaryScreen.tsx#L16-L21)
- [api.ts:11-56](file://frontend/src/utils/api.ts#L11-L56)

## Detailed Component Analysis

### App Container and Phase Management
- Maintains game phase state and routes rendering to StartScreen, CharacterCreation, GameScreen, or SummaryScreen.
- Persists player attributes and talents across transitions.
- Handles start, confirm, end, and restart actions.

```mermaid
flowchart TD
Start(["App init"]) --> SetPhase["Set phase to 'start'"]
SetPhase --> RenderStart["Render StartScreen"]
RenderStart --> OnStart["onStart -> set phase 'creation'"]
OnStart --> RenderChar["Render CharacterCreation"]
RenderChar --> OnConfirm["onConfirm -> startGame()"]
OnConfirm --> SetPlaying["Set phase 'playing' with gameId"]
SetPlaying --> RenderGame["Render GameScreen"]
RenderGame --> OnEnd["onGameEnd -> set phase 'summary'"]
OnEnd --> RenderSum["Render SummaryScreen"]
RenderSum --> OnRestart["onRestart -> reset state"]
OnRestart --> SetPhase
```

**Diagram sources**
- [App.tsx:11-50](file://frontend/src/App.tsx#L11-L50)

**Section sources**
- [App.tsx:9-72](file://frontend/src/App.tsx#L9-L72)

### StartScreen
- Renders an immersive animated background and entrance text.
- Triggers the onStart callback to move to character creation.

**Section sources**
- [StartScreen.tsx:1-193](file://frontend/src/pages/StartScreen.tsx#L1-L193)

### CharacterCreation
- Manages attribute distribution with +/- controls and a randomization strategy.
- Loads and allows selecting up to three talents, with reroll capability.
- Confirms to start the game and passes attributes and talents to App.

```mermaid
flowchart TD
Init(["Mount CharacterCreation"]) --> LoadTalents["fetchTalents()"]
LoadTalents --> Ready["Render UI"]
Ready --> Adjust["Adjust attribute (+/-)"]
Adjust --> Validate{"Within bounds<br/>and remaining >= 0?"}
Validate --> |No| Ignore["Ignore action"]
Validate --> |Yes| Update["Update attrs"]
Ready --> ToggleTalent["Toggle talent selection"]
ToggleTalent --> MaxTalents{"Selected < 3 or deselect?"}
MaxTalents --> Confirm["Confirm if canStart"]
Confirm --> CallOnConfirm["Call onConfirm(attrs, talents)"]
```

**Diagram sources**
- [CharacterCreation.tsx:20-78](file://frontend/src/pages/CharacterCreation.tsx#L20-L78)
- [api.ts:5-9](file://frontend/src/utils/api.ts#L5-L9)

**Section sources**
- [CharacterCreation.tsx:1-249](file://frontend/src/pages/CharacterCreation.tsx#L1-L249)
- [api.ts:5-9](file://frontend/src/utils/api.ts#L5-L9)

### GameScreen
- Implements the real-time simulation UI with:
  - Age and realm display with color-coded realm names.
  - Cultivation progress bar.
  - Attribute bars.
  - Event log with age grouping and event-type-specific styling.
  - Auto-play toggle and manual “Next Year” control.
- Uses a ref to track auto-play state across async operations and scrolls the event log to the latest entry.

```mermaid
sequenceDiagram
participant U as "User"
participant GS as "GameScreen"
participant API as "API Client"
U->>GS : Click "Next Year" or "Auto"
GS->>GS : setLoading(true)
GS->>API : nextYear(gameId)
API-->>GS : NextYearResponse
GS->>GS : Update age/realm/cultivation/attrs/events
alt Ascended or Dead
GS->>GS : setIsGameOver(true), setAutoPlay(false)
GS-->>U : Show end state, then onGameEnd(gameId)
else Continue
alt AutoPlay enabled
GS->>GS : setTimeout(advanceYear, delay)
else Manual
GS->>GS : setLoading(false)
end
end
```

**Diagram sources**
- [GameScreen.tsx:13-74](file://frontend/src/pages/GameScreen.tsx#L13-L74)
- [api.ts:36-47](file://frontend/src/utils/api.ts#L36-L47)

**Section sources**
- [GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [types.ts:25-51](file://frontend/src/utils/types.ts#L25-L51)

### SummaryScreen
- Fetches the life summary after the game ends and renders a polished report card with stats, final attributes, key events, and a score rating.

**Section sources**
- [SummaryScreen.tsx:1-177](file://frontend/src/pages/SummaryScreen.tsx#L1-L177)
- [api.ts:49-56](file://frontend/src/utils/api.ts#L49-L56)
- [types.ts:53-63](file://frontend/src/utils/types.ts#L53-L63)

### Centralized API Client
- Provides typed functions for:
  - Fetching talents.
  - Starting a new game.
  - Advancing the year.
  - Retrieving the life summary.
- Enforces response validation and throws descriptive errors on non-OK responses.

```mermaid
classDiagram
class ApiClient {
+fetchTalents() Talent[]
+startGame(attrs, talents) StartResponse
+nextYear(gameId) NextYearResponse
+getSummary(gameId) LifeSummary
}
class Types {
<<interfaces>>
Attributes
Talent
GameEvent
GameState
NextYearResponse
LifeSummary
}
ApiClient --> Types : "returns"
```

**Diagram sources**
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)

**Section sources**
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)

### TypeScript Interfaces and Constants
- Defines strongly-typed shapes for attributes, talents, game events, game state, API responses, and life summaries.
- Exposes constants for realm names/colors, attribute names, and talent rarities.

**Section sources**
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)

### Real-time Simulation UI and Auto-play
- Auto-play toggles continuous year advancement with a short delay between steps.
- Event log updates incrementally and smoothly scrolls to the newest entry.
- Event lines are styled differently based on event type.

```mermaid
flowchart TD
Auto["Auto mode ON"] --> Delay["Short delay"]
Delay --> Advance["advanceYear()"]
Advance --> NextResp["Receive NextYearResponse"]
NextResp --> UpdateUI["Update state and render"]
UpdateUI --> CheckEnd{"Dead or Ascended?"}
CheckEnd --> |Yes| End["Stop auto-play and trigger end"]
CheckEnd --> |No| Auto
```

**Diagram sources**
- [GameScreen.tsx:67-74](file://frontend/src/pages/GameScreen.tsx#L67-L74)
- [GameScreen.tsx:40-65](file://frontend/src/pages/GameScreen.tsx#L40-L65)

**Section sources**
- [GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)

### Responsive Design Patterns
- Uses Tailwind utilities for responsive layouts (stacked on mobile, side panel on desktop).
- Employs backdrop blur and semi-transparent backgrounds for depth.
- Animations and transitions enhance UX without heavy computations.

**Section sources**
- [index.css:1-277](file://frontend/src/index.css#L1-L277)
- [GameScreen.tsx:92-182](file://frontend/src/pages/GameScreen.tsx#L92-L182)
- [CharacterCreation.tsx:80-247](file://frontend/src/pages/CharacterCreation.tsx#L80-L247)

### Backend Integration and Proxy
- Vite dev server proxies API requests under /api to the backend service.
- API client uses a base path consistent with the backend router.

**Section sources**
- [vite.config.ts:7-14](file://frontend/vite.config.ts#L7-L14)
- [api.ts:3](file://frontend/src/utils/api.ts#L3)

## Dependency Analysis
- App depends on page components and the API client.
- Pages depend on the API client and shared types.
- Styles are global and applied via Tailwind layers.
- Build toolchain integrates React, TypeScript, Tailwind, and Vite.

```mermaid
graph LR
APP["App.tsx"] --> START["StartScreen.tsx"]
APP --> CHAR["CharacterCreation.tsx"]
APP --> GAME["GameScreen.tsx"]
APP --> SUM["SummaryScreen.tsx"]
CHAR --> API["utils/api.ts"]
GAME --> API
SUM --> API
CHAR --> TYPES["utils/types.ts"]
GAME --> TYPES
SUM --> TYPES
APP --> TYPES
START --> CSS["index.css"]
CHAR --> CSS
GAME --> CSS
SUM --> CSS
PKG["package.json"] --> VITE["vite.config.ts"]
VITE --> API
```

**Diagram sources**
- [App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)
- [CharacterCreation.tsx:1-249](file://frontend/src/pages/CharacterCreation.tsx#L1-L249)
- [GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [SummaryScreen.tsx:1-177](file://frontend/src/pages/SummaryScreen.tsx#L1-L177)
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)
- [index.css:1-277](file://frontend/src/index.css#L1-L277)
- [package.json:1-33](file://frontend/package.json#L1-L33)
- [vite.config.ts:1-16](file://frontend/vite.config.ts#L1-L16)

**Section sources**
- [package.json:1-33](file://frontend/package.json#L1-L33)
- [vite.config.ts:1-16](file://frontend/vite.config.ts#L1-L16)

## Performance Considerations
- Minimal re-renders: App centralizes state and passes only necessary props to pages.
- Local state scoping: GameScreen keeps UI state close to the component that needs it.
- Ref usage: autoPlayRef avoids stale closures during async loops.
- Efficient rendering: Event log uses keyed list rendering and only updates when new events arrive.
- CSS animations: Prefer hardware-accelerated transforms and opacity changes.
- Lazy loading: Talent pool is fetched once during CharacterCreation mount.
- Avoid prop drilling: App holds top-level state and passes down only what’s needed.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- API failures: The API client throws descriptive errors on non-OK responses. Catch and surface user-friendly messages in pages.
- Auto-play stalls: Ensure auto-play is disabled when errors occur and that the ref value is updated on state changes.
- Event log not scrolling: Verify the ref is attached to a DOM element and that the effect runs after log updates.
- Proxy misconfiguration: Confirm Vite proxy targets the correct backend host/port.

**Section sources**
- [api.ts:29-33](file://frontend/src/utils/api.ts#L29-L33)
- [api.ts:42-46](file://frontend/src/utils/api.ts#L42-L46)
- [api.ts:51-56](file://frontend/src/utils/api.ts#L51-L56)
- [GameScreen.tsx:32-38](file://frontend/src/pages/GameScreen.tsx#L32-L38)
- [vite.config.ts:7-14](file://frontend/vite.config.ts#L7-L14)

## Conclusion
The frontend employs a clean, page-based architecture with centralized orchestration in App and a dedicated API client. State management is intentionally minimal and scoped, reducing complexity and prop drilling. The real-time simulation UI combines responsive design, smooth animations, and efficient rendering to deliver an engaging user experience. Integration with the backend is handled via a simple proxy and typed API functions, ensuring reliability and maintainability.