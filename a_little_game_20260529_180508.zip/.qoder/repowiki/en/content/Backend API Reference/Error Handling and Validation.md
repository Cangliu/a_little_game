# Error Handling and Validation

<cite>
**Referenced Files in This Document**
- [main.py](file://backend/app/main.py)
- [router.py](file://backend/app/router.py)
- [game_engine.py](file://backend/app/game_engine.py)
- [models.py](file://backend/app/models.py)
- [talents.py](file://backend/app/talents.py)
- [requirements.txt](file://backend/requirements.txt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the error handling patterns and validation strategies used in the A Little Game API. It focuses on:
- HTTPException usage for client errors (400, 404 status codes)
- Validation error messages for attribute point limits and talent selection constraints
- Game state validation for missing game IDs and invalid operations
- Examples of proper error responses, validation failure scenarios, and exception propagation from the game engine to the API layer
- FastAPI’s automatic validation integration via Pydantic models
- Custom validation logic in route handlers
- Error response formatting and debugging/logging best practices

## Project Structure
The API is implemented with FastAPI and organized around a small set of modules:
- Application entrypoint initializes the server and mounts the router
- Router defines endpoints and performs custom validations
- Game engine encapsulates core logic and raises exceptions for invalid states
- Models define Pydantic schemas for request/response validation
- Talents provide pre-defined talent pools for character creation

```mermaid
graph TB
Client["Client"]
FastAPI["FastAPI App<br/>main.py"]
Router["Routes<br/>router.py"]
Engine["Game Engine<br/>game_engine.py"]
Models["Pydantic Models<br/>models.py"]
Talents["Talents Pool<br/>talents.py"]
Client --> FastAPI
FastAPI --> Router
Router --> Models
Router --> Engine
Router --> Talents
Engine --> Models
```

**Diagram sources**
- [main.py:1-26](file://backend/app/main.py#L1-L26)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [talents.py:1-85](file://backend/app/talents.py#L1-L85)

**Section sources**
- [main.py:1-26](file://backend/app/main.py#L1-L26)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [talents.py:1-85](file://backend/app/talents.py#L1-L85)

## Core Components
- FastAPI application initialization and CORS middleware setup
- Route handlers for:
  - Getting random talents
  - Starting a new game with attribute and talent validation
  - Advancing the game by one year with game ID and state checks
  - Retrieving life summary with game ID validation
- Game engine functions that:
  - Create new games and apply talent effects
  - Advance years and enforce game state transitions
  - Compute life summaries and titles
- Pydantic models for:
  - Request/response shapes and automatic validation
  - Enumerations for realms and constants for thresholds and max ages

Key validation and error handling points:
- Attribute point cap (sum cannot exceed 20)
- Talent selection limit (no more than 3)
- Missing or invalid game ID
- Game already ended (dead or ascended)
- Propagation of ValueError from engine to HTTPException with appropriate status codes

**Section sources**
- [router.py:18-44](file://backend/app/router.py#L18-L44)
- [router.py:47-69](file://backend/app/router.py#L47-L69)
- [game_engine.py:48-77](file://backend/app/game_engine.py#L48-L77)
- [game_engine.py:311-393](file://backend/app/game_engine.py#L311-L393)
- [game_engine.py:396-424](file://backend/app/game_engine.py#L396-L424)
- [models.py:48-171](file://backend/app/models.py#L48-L171)

## Architecture Overview
The API follows a layered pattern:
- Presentation layer: FastAPI routes
- Domain layer: Game engine functions
- Data layer: Pydantic models and in-memory state storage

```mermaid
sequenceDiagram
participant C as "Client"
participant F as "FastAPI App"
participant R as "Router"
participant E as "Game Engine"
C->>F : "POST /api/game/start"
F->>R : "Dispatch to start_game()"
R->>R : "Validate attributes total <= 20"
R->>R : "Validate talents length <= 3"
alt "Validation fails"
R-->>C : "HTTP 400 Bad Request"
else "Validation passes"
R->>E : "create_game(attributes, talents)"
E-->>R : "GameState"
R-->>C : "HTTP 200 OK with game state"
end
```

**Diagram sources**
- [router.py:18-44](file://backend/app/router.py#L18-L44)
- [game_engine.py:48-77](file://backend/app/game_engine.py#L48-L77)

**Section sources**
- [router.py:18-44](file://backend/app/router.py#L18-L44)
- [game_engine.py:48-77](file://backend/app/game_engine.py#L48-L77)

## Detailed Component Analysis

### HTTPException Usage and Error Responses
- Client errors:
  - 400 Bad Request for invalid requests (attribute totals exceeding limits, too many talents, missing game_id)
  - 404 Not Found for operations on non-existent or already-completed games
- Exception propagation:
  - Route handlers catch ValueError raised by the engine and convert to HTTPException with appropriate status codes
- Error response formatting:
  - FastAPI automatically serializes HTTPException details into JSON responses with a consistent structure

Examples of error scenarios:
- Exceeding attribute point cap during game start
- Selecting more than three talents
- Calling next-year without a game_id
- Advancing a year for a game that is already dead or ascended
- Retrieving a summary for a non-existent game ID

**Section sources**
- [router.py:26-30](file://backend/app/router.py#L26-L30)
- [router.py:51-58](file://backend/app/router.py#L51-L58)
- [router.py:64-68](file://backend/app/router.py#L64-L68)
- [game_engine.py:314-318](file://backend/app/game_engine.py#L314-L318)

### FastAPI Automatic Validation Integration
- Pydantic models define strict schemas for requests and responses
- FastAPI validates incoming requests against these models automatically
- Model fields include defaults and constraints that prevent invalid states from reaching handler logic
- Example model classes:
  - Attributes: six-dimensional stats with default values
  - StartGameRequest: composed of Attributes and a list of talent IDs
  - NextYearResponse and LifeSummary: structured outputs for year progression and final summaries

Benefits:
- Centralized validation logic in models
- Consistent error messages for malformed payloads
- Type safety and IDE support for route handlers

**Section sources**
- [models.py:48-171](file://backend/app/models.py#L48-L171)
- [requirements.txt:1-5](file://backend/requirements.txt#L1-L5)

### Custom Validation Logic in Route Handlers
- Attribute point validation:
  - Sum of lifespan, constitution, comprehension, fortune, charisma, willpower must not exceed 20
- Talent selection validation:
  - No more than three talents can be selected
- Game state validation:
  - Missing game_id triggers 400
  - Attempting to advance a year on a finished game triggers 404
  - Retrieving summary for a non-existent game triggers 404

These validations occur before delegating to the game engine, ensuring early failure and clear error messages.

**Section sources**
- [router.py:21-30](file://backend/app/router.py#L21-L30)
- [router.py:50-58](file://backend/app/router.py#L50-L58)
- [router.py:64-68](file://backend/app/router.py#L64-L68)

### Exception Propagation from Engine to API Layer
```mermaid
sequenceDiagram
participant R as "Router.next_year()"
participant E as "Engine.advance_year()"
participant G as "GAME_STATES"
R->>R : "Extract game_id"
R->>E : "advance_year(game_id)"
E->>G : "Lookup state by game_id"
alt "Not found"
E-->>R : "raise ValueError('Game ... not found')"
else "Found"
E->>E : "Check is_dead or is_ascended"
alt "Already over"
E-->>R : "raise ValueError('Game is already over')"
else "Valid"
E->>E : "Advance year, process events"
E-->>R : "NextYearResponse"
end
end
R->>R : "Catch ValueError"
R-->>R : "Convert to HTTP 404"
```

**Diagram sources**
- [router.py:47-58](file://backend/app/router.py#L47-L58)
- [game_engine.py:311-393](file://backend/app/game_engine.py#L311-L393)

**Section sources**
- [router.py:47-58](file://backend/app/router.py#L47-L58)
- [game_engine.py:311-393](file://backend/app/game_engine.py#L311-L393)

### Validation Failure Scenarios and Examples
- Attribute point overflow:
  - Scenario: Sum of six attributes exceeds 20
  - Outcome: HTTP 400 with a message indicating the attribute point cap
- Talent selection overflow:
  - Scenario: More than three talent IDs provided
  - Outcome: HTTP 400 with a message indicating the talent limit
- Missing game_id:
  - Scenario: next-year request lacks game_id
  - Outcome: HTTP 400 with a message indicating missing game_id
- Invalid operation on finished game:
  - Scenario: advance_year called on a game that is dead or ascended
  - Outcome: HTTP 404 with a message reflecting the game state
- Non-existent game lookup:
  - Scenario: get_summary called with a game_id not present in state
  - Outcome: HTTP 404 with a message indicating the game was not found

**Section sources**
- [router.py:26-30](file://backend/app/router.py#L26-L30)
- [router.py:51-58](file://backend/app/router.py#L51-L58)
- [router.py:64-68](file://backend/app/router.py#L64-L68)
- [game_engine.py:314-318](file://backend/app/game_engine.py#L314-L318)

### Game State Validation and Constraints
- In-memory state management:
  - Games stored by short UUID-like identifiers
  - Access validated before any operation
- Realm and cultivation thresholds:
  - Engine enforces progression thresholds and realm transitions
- Death and ascension checks:
  - Engine computes death probability and outcomes
  - Ascension triggers special handling in summaries and responses

These mechanisms ensure that invalid operations are prevented and clearly reported to clients.

**Section sources**
- [game_engine.py:31-32](file://backend/app/game_engine.py#L31-L32)
- [game_engine.py:311-393](file://backend/app/game_engine.py#L311-L393)
- [game_engine.py:396-424](file://backend/app/game_engine.py#L396-L424)

### Error Response Formatting
- HTTPException is used to produce standardized error responses
- FastAPI serializes exceptions into JSON with a consistent structure
- Status codes align with the semantic meaning of the error (client vs server)

Best practices derived from the code:
- Keep error messages localized and actionable
- Prefer explicit checks in handlers for user-facing constraints
- Convert domain errors (ValueError) to HTTPException with appropriate status codes

**Section sources**
- [router.py:26-30](file://backend/app/router.py#L26-L30)
- [router.py:51-58](file://backend/app/router.py#L51-L58)
- [router.py:64-68](file://backend/app/router.py#L64-L68)

## Dependency Analysis
- FastAPI and Pydantic versions are pinned in requirements
- Router depends on models and game_engine
- Game engine depends on models and constants
- Application entrypoint wires router into the FastAPI app

```mermaid
graph LR
Req["requirements.txt"]
Main["main.py"]
Router["router.py"]
Models["models.py"]
Engine["game_engine.py"]
Talents["talents.py"]
Req --> Main
Main --> Router
Router --> Models
Router --> Engine
Router --> Talents
Engine --> Models
```

**Diagram sources**
- [requirements.txt:1-5](file://backend/requirements.txt#L1-L5)
- [main.py:1-26](file://backend/app/main.py#L1-L26)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [talents.py:1-85](file://backend/app/talents.py#L1-L85)

**Section sources**
- [requirements.txt:1-5](file://backend/requirements.txt#L1-L5)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)

## Performance Considerations
- In-memory state storage simplifies deployment but limits horizontal scaling
- Event loading occurs at import time; consider lazy loading for very large datasets
- Validation is lightweight and occurs at the edge; keep models minimal and precise
- Consider adding rate limiting and input size caps for multipart/form-data endpoints

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and debugging strategies:
- Validation failures on start-game:
  - Verify attribute totals and talent counts match constraints
  - Confirm request payload shape matches StartGameRequest
- Missing game_id errors:
  - Ensure the next-year endpoint receives a valid game_id
  - Check client-side state management for game identifiers
- 404 errors on next-year or summary:
  - Confirm the game exists and is not already finished
  - Verify the game_id is correct and not expired
- Logging patterns:
  - The engine prints a message when loading events; similar logs can be added for state transitions
  - Use structured logging (e.g., JSON) for production observability
- Best practices:
  - Centralize validation in models and route handlers
  - Normalize error messages and avoid leaking internal details
  - Add tests for boundary conditions (limits, missing fields, invalid states)

**Section sources**
- [router.py:18-44](file://backend/app/router.py#L18-L44)
- [router.py:47-69](file://backend/app/router.py#L47-L69)
- [game_engine.py:19-29](file://backend/app/game_engine.py#L19-L29)

## Conclusion
The A Little Game API employs a clean separation of concerns with robust error handling:
- FastAPI and Pydantic provide strong automatic validation
- Route handlers implement targeted custom validations for business rules
- The game engine centralizes state logic and raises explicit exceptions for invalid states
- HTTPException ensures consistent, machine-readable error responses
Adhering to these patterns improves reliability, maintainability, and developer experience across all endpoints.