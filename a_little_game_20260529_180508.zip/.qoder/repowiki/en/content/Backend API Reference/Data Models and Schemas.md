# Data Models and Schemas

<cite>
**Referenced Files in This Document**
- [models.py](file://backend/app/models.py)
- [game_engine.py](file://backend/app/game_engine.py)
- [router.py](file://backend/app/router.py)
- [main.py](file://backend/app/main.py)
- [talents.py](file://backend/app/talents.py)
- [types.ts](file://frontend/src/utils/types.ts)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document provides comprehensive documentation for the Pydantic data models and schemas used in the A Little Game API. It focuses on:
- Attributes: six-dimensional stat tracking for player characters
- GameState: complete game state representation during gameplay
- StartGameRequest: character creation input validation
- Realm: cultivation tier management using an IntEnum

It explains field definitions, data types, validation rules, serialization patterns, and relationships between models. It also covers how these models integrate with FastAPI request/response handling, including examples of instantiation, validation scenarios, and JSON serialization/deserialization.

## Project Structure
The data models live in the backend application under backend/app/models.py. They are consumed by the game engine in backend/app/game_engine.py, exposed via FastAPI routes in backend/app/router.py, and integrated with the frontend TypeScript types in frontend/src/utils/types.ts.

```mermaid
graph TB
subgraph "Backend"
M["models.py<br/>Pydantic Models"]
GE["game_engine.py<br/>Game Logic"]
RT["router.py<br/>FastAPI Routes"]
APP["main.py<br/>FastAPI App"]
TL["talents.py<br/>Talent Definitions"]
end
subgraph "Frontend"
TS["types.ts<br/>TypeScript Interfaces"]
end
APP --> RT
RT --> GE
GE --> M
GE --> TL
TS --> RT
```

**Diagram sources**
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [main.py:1-26](file://backend/app/main.py#L1-L26)
- [talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)

**Section sources**
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [main.py:1-26](file://backend/app/main.py#L1-L26)
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)

## Core Components
This section documents the four primary models used in the API.

### Attributes Model
- Purpose: Six-dimensional stat tracking for player characters
- Fields:
  - lifespan: integer, base max age modifier
  - constitution: integer, physical/bodily talent
  - comprehension: integer, learning/skill acquisition speed
  - fortune: integer, luck factor affecting outcomes
  - charisma: integer, social influence
  - willpower: integer, resistance to tribulations and mental stress
- Defaults: All fields initialized to 3
- Notes: Used as a nested model within GameState and StartGameRequest

Validation and usage:
- Total attribute points are validated server-side during character creation
- Attribute values are used throughout game logic for calculations (e.g., death chance, cultivation gains, breakthrough chance)

Serialization:
- model_dump() is used to serialize nested Attributes instances in API responses

Relationships:
- Nested within GameState and StartGameRequest
- Modified by talents during game initialization

**Section sources**
- [models.py:48-56](file://backend/app/models.py#L48-L56)
- [router.py:18-44](file://backend/app/router.py#L18-L44)
- [game_engine.py:48-77](file://backend/app/game_engine.py#L48-L77)

### GameState Model
- Purpose: Complete representation of a running game session
- Fields:
  - game_id: string, unique identifier
  - age: integer, current age
  - realm: integer, current cultivation realm (0–9)
  - cultivation: integer, progress toward next realm
  - attributes: Attributes, nested stats
  - talents: list[str], identifiers of chosen talents
  - tags: list[str], active tags from talents/events
  - events_log: list[dict], chronological record of events
  - is_dead: boolean, whether the character died
  - death_reason: string, cause of death
  - is_ascended: boolean, whether the character ascended to the highest realm
- Defaults: Age starts at 0; realm and cultivation at 0; empty lists and flags false

Usage:
- Created by the game engine at start
- Updated by yearly advancement logic
- Consumed by summary generation

Serialization:
- model_dump() is used to serialize the complete state in API responses

**Section sources**
- [models.py:116-129](file://backend/app/models.py#L116-L129)
- [game_engine.py:48-77](file://backend/app/game_engine.py#L48-L77)
- [game_engine.py:311-393](file://backend/app/game_engine.py#L311-L393)

### StartGameRequest Model
- Purpose: Validates character creation inputs
- Fields:
  - attributes: Attributes, required
  - talents: list[str], required
- Validation rules enforced by the API:
  - Total attribute points must not exceed 20
  - Number of talents must not exceed 3
- Behavior:
  - On validation pass, creates a GameState instance and stores it
  - Returns a structured response including realm name and thresholds

Serialization:
- Request body is automatically parsed into StartGameRequest
- Response body is serialized via model_dump()

**Section sources**
- [models.py:131-135](file://backend/app/models.py#L131-L135)
- [router.py:18-44](file://backend/app/router.py#L18-L44)

### Realm Enumeration
- Purpose: Cultivation tier management using an IntEnum
- Values:
  - MORTAL (0), QI_REFINING (1), FOUNDATION (2), GOLDEN_CORE (3), NASCENT_SOUL (4), DEITY (5), INTEGRATION (6), MAHAYANA (7), TRIBULATION (8), ASCENSION (9)
- Supporting constants:
  - REALM_NAMES: mapping of realm values to Chinese names
  - REALM_MAX_AGE: maximum age per realm
  - REALM_THRESHOLDS: cultivation thresholds to advance between realms

Usage:
- Used to compute realm names and thresholds in API responses
- Used in game logic for max age calculation and breakthrough checks

**Section sources**
- [models.py:7-45](file://backend/app/models.py#L7-L45)
- [game_engine.py:34-45](file://backend/app/game_engine.py#L34-L45)
- [router.py:38-40](file://backend/app/router.py#L38-L40)

## Architecture Overview
The models integrate with FastAPI through typed route handlers. Requests are validated against Pydantic models, and responses are serialized using model_dump().

```mermaid
sequenceDiagram
participant Client as "Client"
participant API as "FastAPI Router"
participant Engine as "Game Engine"
participant Models as "Pydantic Models"
Client->>API : POST "/api/game/start" with JSON payload
API->>Models : Parse payload into StartGameRequest
API->>API : Validate attribute total and talent count
API->>Engine : create_game(attributes, talents)
Engine->>Models : Instantiate GameState with nested Attributes
Engine-->>API : GameState instance
API->>Models : Serialize with model_dump()
API-->>Client : JSON response
Client->>API : POST "/api/game/next-year" with JSON payload
API->>Engine : advance_year(game_id)
Engine->>Models : Build NextYearResponse
Engine-->>API : NextYearResponse instance
API->>Models : Serialize with model_dump()
API-->>Client : JSON response
```

**Diagram sources**
- [router.py:18-68](file://backend/app/router.py#L18-L68)
- [models.py:131-151](file://backend/app/models.py#L131-L151)
- [game_engine.py:48-77](file://backend/app/game_engine.py#L48-L77)
- [game_engine.py:311-393](file://backend/app/game_engine.py#L311-L393)

## Detailed Component Analysis

### Attributes Model Analysis
- Data structure: Six integers representing core character stats
- Complexity: O(1) access for each field
- Relationships:
  - Embedded in GameState and StartGameRequest
  - Modified by talents during initialization
- Validation:
  - Enforced at API boundary via total point cap
- Serialization:
  - model_dump() produces a flat dictionary suitable for JSON

```mermaid
classDiagram
class Attributes {
+int lifespan
+int constitution
+int comprehension
+int fortune
+int charisma
+int willpower
}
```

**Diagram sources**
- [models.py:48-56](file://backend/app/models.py#L48-L56)

**Section sources**
- [models.py:48-56](file://backend/app/models.py#L48-L56)
- [router.py:21-30](file://backend/app/router.py#L21-L30)
- [game_engine.py:52-61](file://backend/app/game_engine.py#L52-L61)

### GameState Model Analysis
- Data structure: Complete game state snapshot
- Complexity: O(n) for serialization where n is number of events in log
- Relationships:
  - Contains nested Attributes
  - Maintains logs and flags for terminal states
- Serialization:
  - model_dump() used for responses and summaries

```mermaid
classDiagram
class GameState {
+string game_id
+int age
+int realm
+int cultivation
+Attributes attributes
+string[] talents
+string[] tags
+dict[] events_log
+bool is_dead
+string death_reason
+bool is_ascended
}
class Attributes
GameState --> Attributes : "has"
```

**Diagram sources**
- [models.py:116-129](file://backend/app/models.py#L116-L129)
- [models.py:48-56](file://backend/app/models.py#L48-L56)

**Section sources**
- [models.py:116-129](file://backend/app/models.py#L116-L129)
- [game_engine.py:48-77](file://backend/app/game_engine.py#L48-L77)

### StartGameRequest Model Analysis
- Data structure: Minimal request envelope for character creation
- Validation:
  - Total attribute points checked server-side
  - Talent count constrained
- Integration:
  - Converts to internal GameState via game engine
  - Returns structured response with realm metadata

```mermaid
sequenceDiagram
participant Client as "Client"
participant Router as "Router.start_game"
participant Engine as "create_game"
participant Models as "StartGameRequest/GameState"
Client->>Router : POST /api/game/start
Router->>Models : Validate StartGameRequest
Router->>Engine : create_game(attrs, talents)
Engine->>Models : Build GameState
Engine-->>Router : GameState
Router-->>Client : JSON response
```

**Diagram sources**
- [router.py:18-44](file://backend/app/router.py#L18-L44)
- [models.py:131-135](file://backend/app/models.py#L131-L135)
- [models.py:116-129](file://backend/app/models.py#L116-L129)

**Section sources**
- [models.py:131-135](file://backend/app/models.py#L131-L135)
- [router.py:18-44](file://backend/app/router.py#L18-L44)

### Realm Enumeration Analysis
- Data structure: IntEnum with associated constants
- Complexity: O(1) lookups for names and thresholds
- Usage:
  - Maps numeric realm to localized names
  - Provides max age and thresholds for progression

```mermaid
classDiagram
class Realm {
<<IntEnum>>
+MORTAL
+QI_REFINING
+FOUNDATION
+GOLDEN_CORE
+NASCENT_SOUL
+DEITY
+INTEGRATION
+MAHAYANA
+TRIBULATION
+ASCENSION
}
class Constants {
+dict REALM_NAMES
+dict REALM_MAX_AGE
+dict REALM_THRESHOLDS
}
Constants --> Realm : "maps"
```

**Diagram sources**
- [models.py:7-45](file://backend/app/models.py#L7-L45)

**Section sources**
- [models.py:7-45](file://backend/app/models.py#L7-L45)
- [game_engine.py:34-45](file://backend/app/game_engine.py#L34-L45)
- [router.py:38-40](file://backend/app/router.py#L38-L40)

### Validation Scenarios and Examples
- Character creation validation:
  - Total attribute points exceeding 20 triggers a 400 error
  - Selecting more than 3 talents triggers a 400 error
- Example instantiation paths:
  - StartGameRequest is instantiated from incoming JSON and validated by FastAPI
  - Attributes is embedded within StartGameRequest and later within GameState
  - GameState is constructed inside create_game and later serialized in responses
- JSON serialization/deserialization:
  - Requests are deserialized into Pydantic models automatically
  - Responses are serialized via model_dump()

**Section sources**
- [router.py:21-30](file://backend/app/router.py#L21-L30)
- [models.py:131-135](file://backend/app/models.py#L131-L135)
- [models.py:116-129](file://backend/app/models.py#L116-L129)

### Frontend Integration
- The frontend defines TypeScript interfaces mirroring backend models for type safety
- These interfaces guide API consumption and UI rendering
- The frontend sends Attributes and receives GameState-like structures

**Section sources**
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)
- [router.py:18-68](file://backend/app/router.py#L18-L68)

## Dependency Analysis
The models depend on each other and on external constants and enums. The game engine orchestrates state transitions and uses models for input/output.

```mermaid
graph TB
Models["models.py"]
Engine["game_engine.py"]
Router["router.py"]
Talents["talents.py"]
Router --> Models
Router --> Engine
Engine --> Models
Engine --> Talents
```

**Diagram sources**
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [talents.py:1-85](file://backend/app/talents.py#L1-L85)

**Section sources**
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [talents.py:1-85](file://backend/app/talents.py#L1-L85)

## Performance Considerations
- Model instantiation and serialization are lightweight operations
- Nested model dumps (e.g., Attributes within GameState) are efficient
- Validation occurs at the API boundary, preventing invalid states from entering the game engine
- Consider caching realm-related constants if frequently accessed

## Troubleshooting Guide
Common validation errors:
- Attribute total exceeds 20: Adjust distribution of points so the sum does not exceed the limit
- More than 3 talents selected: Limit selections to three or fewer

Error handling in routes:
- Missing game_id in next-year requests raises a 400 error
- Nonexistent game_id raises a 404 error
- Game already ended raises a 404 error

**Section sources**
- [router.py:21-30](file://backend/app/router.py#L21-L30)
- [router.py:50-58](file://backend/app/router.py#L50-L58)
- [router.py:64-68](file://backend/app/router.py#L64-L68)

## Conclusion
The Pydantic models provide a robust, type-safe foundation for the A Little Game API. Attributes encapsulate six-dimensional stats, GameState tracks the complete game state, StartGameRequest validates character creation inputs, and Realm manages cultivation tiers. Together with FastAPI’s automatic validation and serialization, they ensure predictable behavior, strong typing, and seamless integration with the frontend.