# API Endpoints

<cite>
**Referenced Files in This Document**
- [main.py](file://backend/app/main.py)
- [router.py](file://backend/app/router.py)
- [models.py](file://backend/app/models.py)
- [game_engine.py](file://backend/app/game_engine.py)
- [talents.py](file://backend/app/talents.py)
- [api.ts](file://frontend/src/utils/api.ts)
- [types.ts](file://frontend/src/utils/types.ts)
- [docker-compose.yml](file://docker-compose.yml)
- [Dockerfile.backend](file://Dockerfile.backend)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document provides comprehensive API documentation for the A Little Game REST endpoints. It covers four primary endpoints:
- Talent pool endpoint: GET /api/game/talents
- Game start endpoint: POST /api/game/start
- Year advancement endpoint: POST /api/game/next-year
- Life summary endpoint: GET /api/game/summary/{game_id}

For each endpoint, we describe HTTP method, URL pattern, request/response schemas, parameter validation rules, error handling patterns, status codes, and practical workflows. We also document FastAPI route decorators, dependency injection patterns, and exception handling strategies used in the API layer.

## Project Structure
The backend is implemented with FastAPI and organized into modules:
- main.py: Application entry point and CORS configuration
- router.py: Route definitions under /api/game
- models.py: Pydantic models for requests, responses, enums, and constants
- game_engine.py: Core game logic, state management, and event processing
- talents.py: Talent definitions and selection logic

```mermaid
graph TB
subgraph "Backend"
A["main.py<br/>FastAPI app + CORS"]
B["router.py<br/>APIRouter /api/game"]
C["models.py<br/>Pydantic models"]
D["game_engine.py<br/>Game logic + state"]
E["talents.py<br/>Talent pool"]
end
A --> B
B --> C
B --> D
B --> E
```

**Diagram sources**
- [main.py:1-26](file://backend/app/main.py#L1-L26)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [talents.py:1-85](file://backend/app/talents.py#L1-L85)

**Section sources**
- [main.py:1-26](file://backend/app/main.py#L1-L26)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [talents.py:1-85](file://backend/app/talents.py#L1-L85)

## Core Components
- FastAPI application with CORS enabled for cross-origin requests
- APIRouter with prefix "/api/game" and tag "game"
- Pydantic models for request/response validation and serialization
- In-memory game state storage keyed by game_id
- Event-driven simulation with configurable thresholds and probabilities

Key validation and error handling patterns:
- Attribute total validation and talent count limits in the start endpoint
- Missing game_id validation in the next-year endpoint
- Game state existence and completion checks raising ValueError
- HTTPException raised with explicit status codes and messages

**Section sources**
- [main.py:6-20](file://backend/app/main.py#L6-L20)
- [router.py:11-69](file://backend/app/router.py#L11-L69)
- [models.py:48-171](file://backend/app/models.py#L48-L171)
- [game_engine.py:311-424](file://backend/app/game_engine.py#L311-L424)

## Architecture Overview
The API layer integrates FastAPI routes with the game engine and models. Requests are validated by Pydantic models, processed by game_engine functions, and responses are serialized back to clients.

```mermaid
sequenceDiagram
participant Client as "Client"
participant API as "FastAPI Router"
participant Engine as "Game Engine"
participant Store as "In-Memory State"
Client->>API : "GET /api/game/talents"
API->>Engine : "get_random_talents(10)"
Engine-->>API : "List[Talent]"
API-->>Client : "200 OK { talents : [...] }"
Client->>API : "POST /api/game/start { attributes, talents }"
API->>API : "Validate totals and counts"
API->>Engine : "create_game(attributes, talents)"
Engine->>Store : "Save GameState"
Engine-->>API : "GameState"
API-->>Client : "200 OK { game_id, ... }"
Client->>API : "POST /api/game/next-year { game_id }"
API->>Engine : "advance_year(game_id)"
Engine->>Store : "Update state"
Engine-->>API : "NextYearResponse"
API-->>Client : "200 OK { age, events, ... }"
Client->>API : "GET /api/game/summary/{game_id}"
API->>Engine : "get_life_summary(game_id)"
Engine-->>API : "LifeSummary"
API-->>Client : "200 OK { total_age, max_realm, ... }"
```

**Diagram sources**
- [router.py:11-69](file://backend/app/router.py#L11-L69)
- [game_engine.py:48-424](file://backend/app/game_engine.py#L48-L424)
- [models.py:48-171](file://backend/app/models.py#L48-L171)

## Detailed Component Analysis

### Endpoint: GET /api/game/talents
- Method: GET
- URL Pattern: /api/game/talents
- Purpose: Retrieve a random pool of talents for character creation
- Request: No body
- Response Schema:
  - talents: array of Talent objects
- Validation Rules:
  - None (returns a fixed-size pool)
- Error Handling:
  - No explicit validation errors
- Status Codes:
  - 200 OK on success
- Practical Example Workflow:
  - Client calls GET /api/game/talents
  - Server responds with a list of 10 talent entries
  - Client displays selectable talents to the user

```mermaid
sequenceDiagram
participant Client as "Client"
participant Router as "router.get('/api/game/talents')"
participant Talents as "talents.get_random_talents"
Client->>Router : "GET /api/game/talents"
Router->>Talents : "get_random_talents(10)"
Talents-->>Router : "List[Talent]"
Router-->>Client : "200 OK { talents : [...] }"
```

**Diagram sources**
- [router.py:11-15](file://backend/app/router.py#L11-L15)
- [talents.py:51-84](file://backend/app/talents.py#L51-L84)

**Section sources**
- [router.py:11-15](file://backend/app/router.py#L11-L15)
- [talents.py:51-84](file://backend/app/talents.py#L51-L84)
- [models.py:58-66](file://backend/app/models.py#L58-L66)

### Endpoint: POST /api/game/start
- Method: POST
- URL Pattern: /api/game/start
- Purpose: Start a new game with validated attributes and talents
- Request Body Schema (StartGameRequest):
  - attributes: Attributes
  - talents: array of string ids
- Response Schema (StartGameResponse):
  - game_id: string
  - age: integer
  - realm: integer
  - realm_name: string
  - cultivation: integer
  - cultivation_max: integer
  - attributes: Attributes
  - talents: array of string ids
  - tags: array of string
- Validation Rules:
  - Total of attributes must not exceed 20
  - Number of talents must not exceed 3
- Error Handling:
  - 400 Bad Request for invalid totals or talent count
  - On success, creates GameState and returns initial state
- Status Codes:
  - 200 OK on success
  - 400 Bad Request on validation failure
- Practical Example Workflow:
  - Client fetches talents from GET /api/game/talents
  - Client constructs StartGameRequest with chosen talent ids
  - Client posts to POST /api/game/start
  - Server validates and returns initial game state with game_id

```mermaid
sequenceDiagram
participant Client as "Client"
participant Router as "router.post('/api/game/start')"
participant Models as "StartGameRequest"
participant Engine as "create_game"
participant Store as "GAME_STATES"
Client->>Router : "POST /api/game/start { attributes, talents }"
Router->>Models : "Validate request"
Router->>Router : "Check total <= 20 and talents <= 3"
alt "Validation fails"
Router-->>Client : "400 Bad Request"
else "Validation passes"
Router->>Engine : "create_game(attributes, talents)"
Engine->>Store : "Save GameState"
Engine-->>Router : "GameState"
Router-->>Client : "200 OK { game_id, ... }"
end
```

**Diagram sources**
- [router.py:18-44](file://backend/app/router.py#L18-L44)
- [models.py:131-135](file://backend/app/models.py#L131-L135)
- [models.py:48-56](file://backend/app/models.py#L48-L56)
- [game_engine.py:48-77](file://backend/app/game_engine.py#L48-L77)

**Section sources**
- [router.py:18-44](file://backend/app/router.py#L18-L44)
- [models.py:131-135](file://backend/app/models.py#L131-L135)
- [models.py:48-56](file://backend/app/models.py#L48-L56)
- [game_engine.py:48-77](file://backend/app/game_engine.py#L48-L77)

### Endpoint: POST /api/game/next-year
- Method: POST
- URL Pattern: /api/game/next-year
- Purpose: Advance the game by one year
- Request Body Schema:
  - game_id: string (required)
- Response Schema (NextYearResponse):
  - age: integer
  - realm: integer
  - realm_name: string
  - cultivation: integer
  - cultivation_max: integer
  - events: array of event objects
  - attributes: Attributes
  - is_dead: boolean
  - death_reason: string
  - is_ascended: boolean
  - has_choice: boolean (not present in current implementation)
  - choice_event: object (not present in current implementation)
- Validation Rules:
  - game_id must be present
- Error Handling:
  - 400 Bad Request if game_id is missing
  - 404 Not Found if game does not exist or is already finished
- Status Codes:
  - 200 OK on success
  - 400 Bad Request for missing game_id
  - 404 Not Found for invalid or finished game
- Practical Example Workflow:
  - Client calls POST /api/game/next-year with game_id
  - Server advances the game state, processes events, and returns NextYearResponse
  - Client updates UI with new age, events, and attributes

```mermaid
sequenceDiagram
participant Client as "Client"
participant Router as "router.post('/api/game/next-year')"
participant Engine as "advance_year"
participant Store as "GAME_STATES"
Client->>Router : "POST /api/game/next-year { game_id }"
Router->>Router : "Validate game_id present"
alt "Missing game_id"
Router-->>Client : "400 Bad Request"
else "Has game_id"
Router->>Engine : "advance_year(game_id)"
Engine->>Store : "Lookup GameState"
alt "Game not found or finished"
Engine-->>Router : "ValueError"
Router-->>Client : "404 Not Found"
else "Valid game"
Engine->>Store : "Update state"
Engine-->>Router : "NextYearResponse"
Router-->>Client : "200 OK { age, events, ... }"
end
end
```

**Diagram sources**
- [router.py:47-59](file://backend/app/router.py#L47-L59)
- [game_engine.py:311-393](file://backend/app/game_engine.py#L311-L393)

**Section sources**
- [router.py:47-59](file://backend/app/router.py#L47-L59)
- [models.py:137-151](file://backend/app/models.py#L137-L151)
- [game_engine.py:311-393](file://backend/app/game_engine.py#L311-L393)

### Endpoint: GET /api/game/summary/{game_id}
- Method: GET
- URL Pattern: /api/game/summary/{game_id}
- Purpose: Retrieve life summary after game ends
- Path Parameter:
  - game_id: string (required)
- Response Schema (LifeSummary):
  - total_age: integer
  - max_realm: integer
  - max_realm_name: string
  - death_reason: string
  - key_events: array of string
  - talents: array of string ids
  - final_attributes: Attributes
  - score: integer
  - title: string
- Validation Rules:
  - game_id must be present in path
- Error Handling:
  - 404 Not Found if game does not exist or is still ongoing
- Status Codes:
  - 200 OK on success
  - 404 Not Found for invalid or unfinished game
- Practical Example Workflow:
  - Client calls GET /api/game/summary/{game_id} after game finishes
  - Server computes title and score, returns LifeSummary
  - Client renders achievements and final stats

```mermaid
sequenceDiagram
participant Client as "Client"
participant Router as "router.get('/api/game/summary/{game_id}')"
participant Engine as "get_life_summary"
participant Store as "GAME_STATES"
Client->>Router : "GET /api/game/summary/{game_id}"
Router->>Engine : "get_life_summary(game_id)"
Engine->>Store : "Lookup GameState"
alt "Game not found"
Engine-->>Router : "ValueError"
Router-->>Client : "404 Not Found"
else "Game exists"
Engine-->>Router : "LifeSummary"
Router-->>Client : "200 OK { total_age, ... }"
end
```

**Diagram sources**
- [router.py:61-69](file://backend/app/router.py#L61-L69)
- [game_engine.py:396-424](file://backend/app/game_engine.py#L396-L424)

**Section sources**
- [router.py:61-69](file://backend/app/router.py#L61-L69)
- [models.py:160-171](file://backend/app/models.py#L160-L171)
- [game_engine.py:396-424](file://backend/app/game_engine.py#L396-L424)

### FastAPI Route Decorators and Dependency Injection
- APIRouter with prefix "/api/game" and tag "game"
- Route handlers accept typed Pydantic models as parameters
- Exception handling uses HTTPException with explicit status codes
- Global CORS middleware configured in main.py

```mermaid
classDiagram
class APIRouter {
+prefix "/api/game"
+tag "game"
+get("/talents")
+post("/start")
+post("/next-year")
+get("/summary/{game_id}")
}
class FastAPIApp {
+add_middleware(CORS)
+include_router(APIRouter)
}
APIRouter --> FastAPIApp : "included by"
```

**Diagram sources**
- [router.py:8](file://backend/app/router.py#L8)
- [main.py:20](file://backend/app/main.py#L20)

**Section sources**
- [router.py:8](file://backend/app/router.py#L8)
- [main.py:6-20](file://backend/app/main.py#L6-L20)

### Data Models and Schemas
- Attributes: six core attributes with defaults
- Talent: talent definition with rarity and effects
- StartGameRequest: attributes + talents
- NextYearResponse: yearly progress snapshot
- LifeSummary: final life statistics
- Realm enum and constants for realm names and thresholds

```mermaid
classDiagram
class Attributes {
+int lifespan
+int constitution
+int comprehension
+int fortune
+int charisma
+int willpower
}
class Talent {
+string id
+string name
+string description
+int rarity
+dict effects
+string[] tags
}
class StartGameRequest {
+Attributes attributes
+string[] talents
}
class NextYearResponse {
+int age
+int realm
+string realm_name
+int cultivation
+int cultivation_max
+dict[] events
+Attributes attributes
+bool is_dead
+string death_reason
+bool is_ascended
}
class LifeSummary {
+int total_age
+int max_realm
+string max_realm_name
+string death_reason
+string[] key_events
+string[] talents
+Attributes final_attributes
+int score
+string title
}
StartGameRequest --> Attributes : "has"
NextYearResponse --> Attributes : "has"
LifeSummary --> Attributes : "has"
```

**Diagram sources**
- [models.py:48-171](file://backend/app/models.py#L48-L171)

**Section sources**
- [models.py:48-171](file://backend/app/models.py#L48-L171)

## Dependency Analysis
The API layer depends on:
- router.py for route definitions
- models.py for request/response validation
- game_engine.py for business logic and state management
- talents.py for talent pool generation

```mermaid
graph LR
Router["router.py"] --> Models["models.py"]
Router --> Engine["game_engine.py"]
Router --> Talents["talents.py"]
Engine --> Models
Engine --> Endings["endings.py"]
Engine --> Events["events/*.json"]
```

**Diagram sources**
- [router.py:1-6](file://backend/app/router.py#L1-L6)
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [game_engine.py:1-14](file://backend/app/game_engine.py#L1-L14)

**Section sources**
- [router.py:1-6](file://backend/app/router.py#L1-L6)
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [game_engine.py:1-14](file://backend/app/game_engine.py#L1-L14)

## Performance Considerations
- In-memory state storage: suitable for single-process deployments; consider persistence for production
- Event loading: events loaded once at module import; consider lazy loading or caching for large datasets
- Random selection: weighted selection and randomization are O(n) per operation; optimize if throughput increases
- CORS overhead: wildcard origins acceptable for development; restrict origins in production

## Troubleshooting Guide
Common issues and resolutions:
- 400 Bad Request on /api/game/start:
  - Cause: attribute total exceeds 20 or more than 3 talents selected
  - Resolution: Adjust attributes so total ≤ 20 and select ≤ 3 talents
- 400 Bad Request on /api/game/next-year:
  - Cause: missing game_id in request body
  - Resolution: Include game_id in POST body
- 404 Not Found on /api/game/next-year or /api/game/summary/{game_id}:
  - Cause: game does not exist or already finished
  - Resolution: Verify game_id and ensure game is still active

**Section sources**
- [router.py:26-30](file://backend/app/router.py#L26-L30)
- [router.py:51-52](file://backend/app/router.py#L51-L52)
- [game_engine.py:314-318](file://backend/app/game_engine.py#L314-L318)

## Conclusion
The A Little Game API provides a clear, validated interface for character creation, simulation progression, and result retrieval. Routes leverage FastAPI’s type hints and Pydantic models for robust request/response handling, with explicit error responses for validation failures and missing resources. The implementation supports a smooth user experience from selecting talents to observing life outcomes.

## Appendices

### API Reference Summary
- GET /api/game/talents
  - Response: { talents: [Talent] }
  - Status: 200
- POST /api/game/start
  - Request: { attributes: Attributes, talents: [string] }
  - Response: Initial game state with game_id
  - Status: 200, 400
- POST /api/game/next-year
  - Request: { game_id: string }
  - Response: NextYearResponse
  - Status: 200, 400, 404
- GET /api/game/summary/{game_id}
  - Response: LifeSummary
  - Status: 200, 404

### Frontend Integration Notes
- The frontend API client demonstrates typical usage patterns for each endpoint
- Types align with backend models for seamless integration

**Section sources**
- [api.ts:5-56](file://frontend/src/utils/api.ts#L5-L56)
- [types.ts:10-63](file://frontend/src/utils/types.ts#L10-L63)

### Deployment Information
- Backend runs on port 8000 inside Docker container
- Frontend serves on port 80
- docker-compose defines service dependencies

**Section sources**
- [docker-compose.yml:12-21](file://docker-compose.yml#L12-L21)
- [Dockerfile.backend:7](file://Dockerfile.backend#L7)