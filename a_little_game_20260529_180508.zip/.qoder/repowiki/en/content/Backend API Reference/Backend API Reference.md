# Backend API Reference

<cite>
**Referenced Files in This Document**
- [backend/app/main.py](file://backend/app/main.py)
- [backend/app/router.py](file://backend/app/router.py)
- [backend/app/models.py](file://backend/app/models.py)
- [backend/app/talents.py](file://backend/app/talents.py)
- [backend/app/game_engine.py](file://backend/app/game_engine.py)
- [backend/app/endings.py](file://backend/app/endings.py)
- [backend/requirements.txt](file://backend/requirements.txt)
- [frontend/src/utils/api.ts](file://frontend/src/utils/api.ts)
- [frontend/src/utils/types.ts](file://frontend/src/utils/types.ts)
- [frontend/src/pages/CharacterCreation.tsx](file://frontend/src/pages/CharacterCreation.tsx)
- [frontend/src/pages/GameScreen.tsx](file://frontend/src/pages/GameScreen.tsx)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document describes the Backend REST API for A Little Game, a cultivation-themed life simulator. It covers:
- API endpoints for talent management and game lifecycle
- Request/response schemas powered by Pydantic
- Authentication model (none)
- CORS configuration
- Practical usage patterns for frontend integration
- Error handling and status codes
- Versioning and rate limiting considerations

## Project Structure
The backend is a FastAPI application with a modular structure:
- Application entrypoint initializes FastAPI and mounts the game router
- Router defines public endpoints under /api/game
- Models define request/response schemas and enums
- Game engine encapsulates core simulation logic
- Talents module supplies randomized talent pools
- Endings module computes titles and scores
- Frontend TypeScript utilities consume the API

```mermaid
graph TB
Client["Frontend Client<br/>React SPA"] --> FastAPI["FastAPI App<br/>main.py"]
FastAPI --> Router["API Router<br/>router.py"]
Router --> Models["Pydantic Models<br/>models.py"]
Router --> Engine["Game Engine<br/>game_engine.py"]
Engine --> Events["Event JSONs<br/>events/*.json"]
Engine --> Talents["Talents Pool<br/>talents.py"]
Engine --> Endings["Endings & Scores<br/>endings.py"]
```

**Diagram sources**
- [backend/app/main.py:1-26](file://backend/app/main.py#L1-L26)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/models.py:1-171](file://backend/app/models.py#L1-L171)
- [backend/app/game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [backend/app/talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [backend/app/endings.py:1-55](file://backend/app/endings.py#L1-L55)

**Section sources**
- [backend/app/main.py:1-26](file://backend/app/main.py#L1-L26)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)

## Core Components
- FastAPI application with CORS enabled for development
- APIRouter mounted under /api/game with three primary tags: game
- Pydantic models for request/response validation and typed enums
- In-memory game state storage keyed by game_id
- JSON-backed event system loaded at startup

Key frameworks and libraries:
- FastAPI 0.115.0
- Uvicorn 0.30.0
- Pydantic 2.9.0

**Section sources**
- [backend/requirements.txt:1-5](file://backend/requirements.txt#L1-L5)
- [backend/app/main.py:6-18](file://backend/app/main.py#L6-L18)
- [backend/app/router.py:8](file://backend/app/router.py#L8)

## Architecture Overview
The API follows a layered architecture:
- HTTP layer: FastAPI routes
- Domain layer: Router handlers and game engine
- Data layer: Pydantic models and in-memory state
- Persistence: JSON event files and in-memory dict

```mermaid
sequenceDiagram
participant FE as "Frontend"
participant API as "FastAPI Router"
participant GE as "Game Engine"
participant ST as "State Store"
FE->>API : GET /api/game/talents
API-->>FE : { talents : [...] }
FE->>API : POST /api/game/start
API->>GE : create_game(attrs, talents)
GE->>ST : store GameState
API-->>FE : { game_id, age, realm, attributes, ... }
loop Simulation
FE->>API : POST /api/game/next-year
API->>GE : advance_year(game_id)
GE->>ST : update state
API-->>FE : NextYearResponse
end
FE->>API : GET /api/game/summary/{game_id}
API->>GE : get_life_summary(game_id)
API-->>FE : LifeSummary
```

**Diagram sources**
- [backend/app/router.py:11-69](file://backend/app/router.py#L11-L69)
- [backend/app/game_engine.py:48-77](file://backend/app/game_engine.py#L48-L77)
- [backend/app/game_engine.py:311-393](file://backend/app/game_engine.py#L311-L393)
- [backend/app/game_engine.py:396-424](file://backend/app/game_engine.py#L396-L424)

## Detailed Component Analysis

### Endpoint Catalog
- GET /api/game/talents
- POST /api/game/start
- POST /api/game/next-year
- GET /api/game/summary/{game_id}

Authentication: None. All endpoints are public.

CORS: Enabled for development with broad allowances.

Versioning: API version is exposed via FastAPI metadata.

Rate limiting: Not implemented in the backend.

**Section sources**
- [backend/app/main.py:6-18](file://backend/app/main.py#L6-L18)
- [backend/app/router.py:11-69](file://backend/app/router.py#L11-L69)

### GET /api/game/talents
Purpose: Retrieve a randomized pool of talents for character creation.

Behavior:
- Returns a list of talent dictionaries with id, name, description, rarity, effects, tags.

Validation:
- No request body; response validated by Pydantic model list.

Responses:
- 200 OK with JSON payload containing talents array.

Example request:
- curl https://your-host/api/game/talents

Example response:
- {"talents": [{"id":"...","name":"...","description":"...","rarity":1,"effects":{},"tags":[]}]}

Notes:
- The talent pool is randomized and weighted by rarity.

**Section sources**
- [backend/app/router.py:11-15](file://backend/app/router.py#L11-L15)
- [backend/app/talents.py:51-84](file://backend/app/talents.py#L51-L84)

### POST /api/game/start
Purpose: Start a new game with provided attributes and talents.

Request body (JSON):
- attributes: Attributes object
  - lifespan: integer
  - constitution: integer
  - comprehension: integer
  - fortune: integer
  - charisma: integer
  - willpower: integer
- talents: array of strings (up to 3)

Validation rules:
- Total of attributes must not exceed 20
- Number of talents must not exceed 3

Success response (200 OK):
- game_id: string
- age: integer
- realm: integer
- realm_name: string
- cultivation: integer
- cultivation_max: integer
- attributes: Attributes
- talents: array of strings
- tags: array of strings

Error responses:
- 400 Bad Request: Validation errors (attribute total > 20, too many talents)
- 500 Internal Server Error: Unhandled exceptions

Example request:
- POST /api/game/start with JSON body containing attributes and talents

Example response:
- {"game_id":"abc123","age":0,"realm":0,"realm_name":"Mortal","cultivation":0,"cultivation_max":100,"attributes":{...},"talents":[],"tags":[]}

Frontend usage:
- The frontend calls this endpoint after user selects attributes and talents.

**Section sources**
- [backend/app/router.py:18-44](file://backend/app/router.py#L18-L44)
- [backend/app/models.py:48-66](file://backend/app/models.py#L48-L66)
- [backend/app/models.py:131-134](file://backend/app/models.py#L131-L134)

### POST /api/game/next-year
Purpose: Advance the simulation by one year.

Request body (JSON):
- game_id: string (required)

Validation rules:
- game_id must be present

Success response (200 OK):
- age: integer
- realm: integer
- realm_name: string
- cultivation: integer
- cultivation_max: integer
- events: array of event objects
  - text: string
  - type: enum "normal"|"important"|"danger"|"fortune"
  - age: integer
- attributes: Attributes
- is_dead: boolean
- death_reason: string
- is_ascended: boolean
- has_choice: boolean (not used in current implementation)
- choice_event: null (not used in current implementation)

Error responses:
- 400 Bad Request: Missing game_id
- 404 Not Found: Game not found or already ended
- 500 Internal Server Error: Unexpected server error

Example request:
- POST /api/game/next-year with {"game_id":"abc123"}

Example response:
- {"age":1,"realm":0,"realm_name":"Mortal","cultivation":0,"cultivation_max":100,"events":[{...}],"attributes":{...},"is_dead":false,"death_reason":"","is_ascended":false}

Frontend usage:
- The frontend calls this endpoint to progress the game year by year.

**Section sources**
- [backend/app/router.py:47-59](file://backend/app/router.py#L47-L59)
- [backend/app/models.py:137-151](file://backend/app/models.py#L137-L151)
- [backend/app/game_engine.py:311-393](file://backend/app/game_engine.py#L311-L393)

### GET /api/game/summary/{game_id}
Purpose: Retrieve the life summary after the game ends (death or ascension).

Path parameter:
- game_id: string (required)

Success response (200 OK):
- total_age: integer
- max_realm: integer
- max_realm_name: string
- death_reason: string
- key_events: array of strings
- talents: array of strings
- final_attributes: Attributes
- score: integer
- title: string

Error responses:
- 404 Not Found: Game not found or not ended yet
- 500 Internal Server Error: Unexpected server error

Example request:
- GET /api/game/summary/abc123

Example response:
- {"total_age":123,"max_realm":9,"max_realm_name":"Ascension","death_reason":"ascended","key_events":["..."],"talents":[],"final_attributes":{...},"score":42,"title":"Fly to Immortality"}

Frontend usage:
- The frontend navigates to the summary screen after the game ends.

**Section sources**
- [backend/app/router.py:61-69](file://backend/app/router.py#L61-L69)
- [backend/app/models.py:160-171](file://backend/app/models.py#L160-L171)
- [backend/app/game_engine.py:396-424](file://backend/app/game_engine.py#L396-L424)
- [backend/app/endings.py:29-55](file://backend/app/endings.py#L29-L55)

### Data Models and Schemas
Core Pydantic models used across endpoints:

- Attributes: Six-dimensional stats with defaults
- Talent: Talent definition with rarity and tags
- EventCondition: Filters for event eligibility
- EventEffect: Stat adjustments and realm transitions
- EventBranch: Choice option within an event
- GameEvent: Single event representation
- GameState: Current game state
- StartGameRequest: Request to start a game
- NextYearResponse: Response for advancing a year
- ChoiceRequest: Choice selection
- LifeSummary: Final life summary

Realm enum and constants:
- Realm: Ordered stages from Mortal to Ascension
- Realm names and thresholds
- Max age per realm

**Section sources**
- [backend/app/models.py:7-171](file://backend/app/models.py#L7-L171)
- [backend/app/game_engine.py:35-45](file://backend/app/game_engine.py#L35-L45)

### Error Handling Patterns
- Validation errors return 400 with detail messages
- Missing or ended games return 404 with detail messages
- Other exceptions return 500

Examples:
- Attribute total exceeds limit
- Too many talents selected
- Missing game_id
- Game not found or already ended

**Section sources**
- [backend/app/router.py:26-30](file://backend/app/router.py#L26-L30)
- [backend/app/router.py:51-58](file://backend/app/router.py#L51-L58)
- [backend/app/router.py:64-68](file://backend/app/router.py#L64-L68)

### CORS Configuration
- allow_origins: ["*"]
- allow_credentials: true
- allow_methods: ["*"]
- allow_headers: ["*"]

This enables local and cross-origin development.

**Section sources**
- [backend/app/main.py:12-18](file://backend/app/main.py#L12-L18)

### API Versioning
- FastAPI app exposes version metadata
- No path-versioning scheme is currently implemented

Recommendation:
- Consider adding /v1 prefix or Accept-Version header for future-proofing.

**Section sources**
- [backend/app/main.py:6-10](file://backend/app/main.py#L6-L10)

### Rate Limiting Considerations
- Not implemented
- Recommendation: Add middleware or route-level throttling for production

[No sources needed since this section provides general guidance]

## Dependency Analysis
High-level dependencies among modules:

```mermaid
graph LR
Main["main.py"] --> Router["router.py"]
Router --> Models["models.py"]
Router --> Engine["game_engine.py"]
Engine --> Models
Engine --> Talents["talents.py"]
Engine --> Endings["endings.py"]
Engine --> Events["events/*.json"]
```

**Diagram sources**
- [backend/app/main.py:1-26](file://backend/app/main.py#L1-L26)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/game_engine.py:1-14](file://backend/app/game_engine.py#L1-L14)

**Section sources**
- [backend/app/main.py:1-26](file://backend/app/main.py#L1-L26)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/game_engine.py:1-14](file://backend/app/game_engine.py#L1-L14)

## Performance Considerations
- In-memory state storage: Simple but not suitable for multi-instance deployments
- JSON event loading: Loads once at import; acceptable for small to medium workloads
- Randomization: Lightweight; consider caching weighted pools if needed
- Recommendations:
  - Persist state to a database for durability and scaling
  - Add pagination for summaries if key_events grows large
  - Consider caching talent pools per session

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- 400 Bad Request on /api/game/start
  - Cause: Attribute total > 20 or more than 3 talents
  - Fix: Adjust attributes so total ≤ 20 and select ≤ 3 talents
- 400 Bad Request on /api/game/next-year
  - Cause: Missing game_id
  - Fix: Ensure request body includes game_id
- 404 Not Found on /api/game/next-year or /api/game/summary/{game_id}
  - Cause: Unknown or ended game_id
  - Fix: Verify game_id and handle ended states in frontend
- CORS errors in browser
  - Cause: Strict CSP or dev misconfiguration
  - Fix: Confirm allow_origins and credentials settings

**Section sources**
- [backend/app/router.py:26-30](file://backend/app/router.py#L26-L30)
- [backend/app/router.py:51-58](file://backend/app/router.py#L51-L58)
- [backend/app/router.py:64-68](file://backend/app/router.py#L64-L68)
- [backend/app/main.py:12-18](file://backend/app/main.py#L12-L18)

## Conclusion
The backend provides a clear, schema-driven REST API for a cultivation simulator. It leverages FastAPI and Pydantic for robust request/response validation, with a straightforward in-memory game state model. For production, consider persistence, rate limiting, and versioning strategies outlined in the appendices.

## Appendices

### Endpoint Reference Details

- GET /api/game/talents
  - Auth: None
  - Responses: 200 OK
  - Schema: talents array of Talent

- POST /api/game/start
  - Auth: None
  - Request: StartGameRequest
  - Responses: 200 OK, 400 Bad Request
  - Schema: Game state snapshot

- POST /api/game/next-year
  - Auth: None
  - Request: game_id (string)
  - Responses: 200 OK, 400 Bad Request, 404 Not Found
  - Schema: NextYearResponse

- GET /api/game/summary/{game_id}
  - Auth: None
  - Responses: 200 OK, 404 Not Found
  - Schema: LifeSummary

**Section sources**
- [backend/app/router.py:11-69](file://backend/app/router.py#L11-L69)
- [backend/app/models.py:131-171](file://backend/app/models.py#L131-L171)

### Practical Usage Examples

- Character creation workflow
  - Fetch talents: GET /api/game/talents
  - Start game: POST /api/game/start with attributes and up to 3 talents
  - Store returned game_id in frontend state

- Simulation progression
  - Advance year: POST /api/game/next-year with game_id
  - Update UI with NextYearResponse fields (age, realm, events, attributes)

- Game state queries
  - On end: GET /api/game/summary/{game_id}
  - Compute title/score using backend logic

Frontend integration patterns:
- Utilities call endpoints and propagate errors to UI
- Components orchestrate flows and manage loading states

**Section sources**
- [frontend/src/utils/api.ts:5-56](file://frontend/src/utils/api.ts#L5-L56)
- [frontend/src/pages/CharacterCreation.tsx:30-76](file://frontend/src/pages/CharacterCreation.tsx#L30-L76)
- [frontend/src/pages/GameScreen.tsx:40-65](file://frontend/src/pages/GameScreen.tsx#L40-L65)

### Data Model Flow

```mermaid
classDiagram
class Attributes {
+int lifespan
+int constitution
+int comprehension
+int fortune
+int charisma
+int willpower
}
class Talent {
+string id
+string name
+string description
+int rarity
+dict effects
+string[] tags
}
class GameState {
+string game_id
+int age
+int realm
+int cultivation
+Attributes attributes
+string[] talents
+string[] tags
+list events_log
+bool is_dead
+string death_reason
+bool is_ascended
}
class StartGameRequest {
+Attributes attributes
+string[] talents
}
class NextYearResponse {
+int age
+int realm
+string realm_name
+int cultivation
+int cultivation_max
+list events
+Attributes attributes
+bool is_dead
+string death_reason
+bool is_ascended
}
class LifeSummary {
+int total_age
+int max_realm
+string max_realm_name
+string death_reason
+string[] key_events
+string[] talents
+Attributes final_attributes
+int score
+string title
}
StartGameRequest --> Attributes : "uses"
GameState --> Attributes : "contains"
NextYearResponse --> Attributes : "contains"
LifeSummary --> Attributes : "contains"
```

**Diagram sources**
- [backend/app/models.py:48-171](file://backend/app/models.py#L48-L171)