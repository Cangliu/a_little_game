# Simulation Loop and Year Advancement

<cite>
**Referenced Files in This Document**
- [game_engine.py](file://backend/app/game_engine.py)
- [models.py](file://backend/app/models.py)
- [router.py](file://backend/app/router.py)
- [main.py](file://backend/app/main.py)
- [types.ts](file://frontend/src/utils/types.ts)
- [GameScreen.tsx](file://frontend/src/pages/GameScreen.tsx)
- [api.ts](file://frontend/src/utils/api.ts)
- [all_events.json](file://backend/app/events/all_events.json)
- [endings.py](file://backend/app/endings.py)
- [talents.py](file://backend/app/talents.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
This document explains the simulation loop and year advancement mechanism in the cultivation life simulator. It focuses on the advance_year() function as the core simulation driver, detailing the chronological order of operations: death checks, cultivation gain, event selection and application, breakthrough verification, and state updates. It also documents the yearly event selection logic based on age progression, the integration with the event system, real-time state updates, and the NextYearResponse structure that communicates simulation results to the frontend. Examples of complete simulation cycles, edge cases handling (death, ascension), and performance considerations for rapid simulation modes are included.

## Project Structure
The simulation logic resides in the backend Python application under backend/app. The frontend React application communicates with the backend via REST endpoints. The key files involved in the simulation loop are:

- Backend:
  - game_engine.py: Contains the core simulation functions including advance_year(), event selection, death checks, breakthrough verification, and cultivation gain calculations.
  - models.py: Defines data structures including NextYearResponse, GameState, Attributes, and Realm constants.
  - router.py: Exposes the /api/game/next-year endpoint that invokes advance_year().
  - main.py: FastAPI application entry point.
  - events/all_events.json: Centralized event database loaded by the game engine.
  - endings.py: Title and scoring logic for life summaries.
  - talents.py: Talent definitions affecting initial attributes.

- Frontend:
  - GameScreen.tsx: Manages UI state, handles user actions, and renders simulation results.
  - api.ts: Implements HTTP requests to the backend.
  - types.ts: TypeScript interfaces mirroring backend models for type safety.

```mermaid
graph TB
subgraph "Backend"
GE["game_engine.py"]
MD["models.py"]
RT["router.py"]
MN["main.py"]
EV["events/all_events.json"]
ED["endings.py"]
TL["talents.py"]
end
subgraph "Frontend"
GS["GameScreen.tsx"]
AP["api.ts"]
TY["types.ts"]
end
GS --> AP
AP --> RT
RT --> GE
GE --> EV
GE --> MD
GE --> ED
GE --> TL
GE --> MD
```

**Diagram sources**
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [main.py:1-26](file://backend/app/main.py#L1-L26)
- [all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)
- [endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)

**Section sources**
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [main.py:1-26](file://backend/app/main.py#L1-L26)
- [all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)
- [endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)

## Core Components
This section outlines the primary components that drive the simulation loop and communicate results to the frontend.

- Advance Year Driver (advance_year):
  - Orchestrates the yearly simulation cycle, enforcing chronological order: death checks, cultivation gain, event selection and application, breakthrough verification, and state updates.
  - Returns a NextYearResponse object containing the updated state and events for the year.

- NextYearResponse:
  - A Pydantic model that serializes the simulation results for the frontend. It includes age, realm, realm_name, cultivation progress, cultivation_max threshold, events array, attributes, and flags for death/ascension.

- Event System Integration:
  - Events are loaded from all_events.json and filtered by conditions (age, realm, attributes, talents, tags).
  - Event selection weights are adjusted by attributes (e.g., fortune) and event types (fortune/danger).

- Death and Ascension Logic:
  - Death checks occur first and can terminate the simulation early.
  - Ascension occurs upon reaching the highest realm with a special breakthrough event.

- Real-time State Updates:
  - The frontend receives a complete snapshot of the state each year, enabling immediate UI updates.

**Section sources**
- [game_engine.py:311-394](file://backend/app/game_engine.py#L311-L394)
- [models.py:137-151](file://backend/app/models.py#L137-L151)
- [router.py:47-59](file://backend/app/router.py#L47-L59)
- [all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)

## Architecture Overview
The simulation loop follows a strict chronological order within advance_year(). The following sequence diagram maps the backend flow and the frontend consumption of results.

```mermaid
sequenceDiagram
participant FE as "Frontend"
participant API as "router.py"
participant GE as "game_engine.py"
participant EV as "all_events.json"
participant MD as "models.py"
FE->>API : POST /api/game/next-year {game_id}
API->>GE : advance_year(game_id)
GE->>GE : Check death (first)
alt Player died
GE-->>API : NextYearResponse(is_dead=true)
API-->>FE : NextYearResponse
else Continue
GE->>GE : Calculate cultivation gain
GE->>EV : Select eligible events (weighted)
EV-->>GE : Selected events
GE->>GE : Apply event effects
GE->>GE : Check breakthrough
alt Ascended
GE-->>API : NextYearResponse(is_ascended=true)
API-->>FE : NextYearResponse
else Normal update
GE-->>API : NextYearResponse
API-->>FE : NextYearResponse
end
end
```

**Diagram sources**
- [router.py:47-59](file://backend/app/router.py#L47-L59)
- [game_engine.py:311-394](file://backend/app/game_engine.py#L311-L394)
- [models.py:137-151](file://backend/app/models.py#L137-L151)
- [all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)

## Detailed Component Analysis

### Advance Year Function (Core Simulation Driver)
The advance_year() function is the central orchestrator of the yearly simulation. It enforces a strict order of operations and returns a NextYearResponse object.

- Chronological Order of Operations:
  1) Death Check: Early termination if death conditions are met.
  2) Cultivation Gain: Computes and applies base cultivation gain for non-mortal realms.
  3) Event Selection: Selects 1–3 events depending on age progression.
  4) Event Application: Applies effects from selected events to state.
  5) Breakthrough Verification: Checks realm breakthrough with probability influenced by attributes.
  6) State Updates: Updates logs, flags, and returns a consolidated response.

- Age-Based Event Selection:
  - Age ≤ 3: 1 event
  - Age 4–12: 2 events
  - Age > 12: Randomly selects 1–3 events

- Real-time State Updates:
  - The function updates the in-memory GameState and returns a NextYearResponse with the latest state and events for the year.

- Edge Cases:
  - Dead or Ascended games: advance_year() raises an error to prevent further advancement.
  - Death: Returns a response with is_dead=True and death_reason populated.
  - Ascension: Returns a response with is_ascended=True and special realm_name.

```mermaid
flowchart TD
Start(["advance_year(game_id)"]) --> LoadState["Load GameState"]
LoadState --> CheckOver{"is_dead or is_ascended?"}
CheckOver --> |Yes| RaiseErr["Raise ValueError"]
CheckOver --> |No| IncAge["state.age += 1"]
IncAge --> DeathCheck["check_death(state)"]
DeathCheck --> Died{"Death occurred?"}
Died --> |Yes| BuildDeathResp["Build NextYearResponse(is_dead=true)"]
Died --> |No| Gain["process_cultivation_gain(state)"]
Gain --> AddGain{"Gain > 0?"}
AddGain --> |Yes| ApplyGain["state.cultivation += gain"]
AddGain --> |No| SkipGain["Skip gain"]
ApplyGain --> SelectCount["Compute event count by age"]
SkipGain --> SelectCount
SelectCount --> SelectEvents["select_events(state, count)"]
SelectEvents --> ForEachEvent{"For each selected event"}
ForEachEvent --> |Yes| ApplyEffect["apply_event_effects(event, state)"]
ForEachEvent --> |No| BreakSel["Break selection"]
ApplyEffect --> AppendLog["Append to events_log"]
AppendLog --> BreakCheck["check_realm_breakthrough(state)"]
BreakCheck --> Ascended{"Ascended?"}
Ascended --> |Yes| BuildAscResp["Build NextYearResponse(is_ascended=true)"]
Ascended --> |No| BuildNormResp["Build NextYearResponse"]
BuildDeathResp --> End(["Return"])
BuildAscResp --> End
BuildNormResp --> End
RaiseErr --> End
```

**Diagram sources**
- [game_engine.py:311-394](file://backend/app/game_engine.py#L311-L394)

**Section sources**
- [game_engine.py:311-394](file://backend/app/game_engine.py#L311-L394)

### Death Check Mechanism
The check_death() function determines whether the player dies during the year. It considers:

- Maximum Age Calculation: Base maximum age varies by realm and is increased by the lifespan attribute.
- Guaranteed Death: If the player’s age reaches or exceeds max_age, a death event is chosen from eligible death events.
- Random Death Chance: For ages below max_age, a chance increases with age ratio and decreases with fortune. Certain conditions (e.g., mortal after age 30) increase risk.

```mermaid
flowchart TD
DStart(["check_death(state)"]) --> MaxAge["Compute max_age"]
MaxAge --> AtMax{"age >= max_age?"}
AtMax --> |Yes| ChooseDeath["Pick random death event"]
ChooseDeath --> MarkDead["Set is_dead=True<br/>Set death_reason"]
AtMax --> |No| AgeRatio["Compute age/max_age"]
AgeRatio --> MortalCheck{"realm==0 and age>30?"}
MortalCheck --> |Yes| DeathChanceM["Death chance for mortals"]
MortalCheck --> |No| DeathChanceN["Death chance for cultivators"]
DeathChanceM --> LuckAdj["Adjust by fortune"]
DeathChanceN --> LuckAdj
LuckAdj --> Roll{"Random roll < chance?"}
Roll --> |Yes| ChooseDeath2["Pick random death event"]
ChooseDeath2 --> MarkDead
Roll --> |No| NoDeath["No death this year"]
MarkDead --> DEnd(["Return death event"])
NoDeath --> DEnd
```

**Diagram sources**
- [game_engine.py:207-253](file://backend/app/game_engine.py#L207-L253)

**Section sources**
- [game_engine.py:207-253](file://backend/app/game_engine.py#L207-L253)

### Cultivation Gain Calculation
Base cultivation gain is computed per year for non-mortal realms and scaled by realm and attributes.

- Formula Highlights:
  - Base gain depends on comprehension and constitution.
  - Realm modifier increases gain for higher realms.
  - Mortals (realm 0) do not gain cultivation.

```mermaid
flowchart TD
CGStart(["process_cultivation_gain(state)"]) --> IsMortal{"realm == 0?"}
IsMortal --> |Yes| Zero["Return 0"]
IsMortal --> |No| Base["Base = 5 + comprehension*2 + constitution"]
Base --> RealmMod["Realm modifier = 1 + realm*0.3"]
RealmMod --> CGOut["Return int(Base * RealmMod)"]
```

**Diagram sources**
- [game_engine.py:298-308](file://backend/app/game_engine.py#L298-L308)

**Section sources**
- [game_engine.py:298-308](file://backend/app/game_engine.py#L298-L308)

### Event Selection and Application
Event selection is governed by eligibility and weighting:

- Eligibility Filtering:
  - Exclude death events.
  - Filter by conditions: min/max age, min/max realm, min cultivation, required/excluded talents/tags, and minimum attribute thresholds.

- Weighting:
  - Weighted by event weight and adjusted by attributes (e.g., fortune increases fortune event weight, decreases danger event weight).
  - Selection without replacement using weighted random draw.

- Application:
  - apply_event_effects() updates cultivation, attributes, tags, and can trigger realm_up.

```mermaid
flowchart TD
ESStart(["select_events(state, count)"]) --> Filter["Filter eligible events"]
Filter --> Weight["Compute weights (event.weight + attribute modifiers)"]
Weight --> Loop{"Repeat min(count, len(weighted)) times"}
Loop --> |Draw| Total["Sum weights"]
Total --> Uniform["Random uniform draw"]
Uniform --> Cumulative["Accumulate weights"]
Cumulative --> Pick["Pick event at cumulative threshold"]
Pick --> AppendSel["Append to selected"]
AppendSel --> Remove["Remove picked event from weighted list"]
Remove --> Loop
Loop --> |Done| ESEnd(["Return selected events"])
```

**Diagram sources**
- [game_engine.py:256-295](file://backend/app/game_engine.py#L256-L295)
- [game_engine.py:119-153](file://backend/app/game_engine.py#L119-L153)

**Section sources**
- [game_engine.py:256-295](file://backend/app/game_engine.py#L256-L295)
- [game_engine.py:119-153](file://backend/app/game_engine.py#L119-L153)

### Breakthrough Verification
Breakthrough checks occur after events and before returning the response:

- Threshold Check:
  - Compares current cultivation against realm thresholds.
  - If threshold reached, computes breakthrough chance based on comprehension and fortune.

- Outcome:
  - Successful breakthrough advances realm and resets cultivation.
  - Special handling for Ascension (realm 9) sets is_ascended flag and returns a special event.

```mermaid
flowchart TD
BTStart(["check_realm_breakthrough(state)"]) --> Reach{"cultivation >= threshold?"}
Reach --> |No| NoBT["Return None"]
Reach --> |Yes| Chance["Compute chance = min(0.3 + comp*0.05 + fort*0.03, 0.85)"]
Chance --> Roll{"Random roll < chance?"}
Roll --> |No| NoBT
Roll --> |Yes| Advance["state.realm += 1<br/>state.cultivation = 0"]
Advance --> IsAsc{"realm == 9?"}
IsAsc --> |Yes| AscEvent["Return ascension event"]
IsAsc --> |No| NormalEvent["Return breakthrough event"]
```

**Diagram sources**
- [game_engine.py:166-204](file://backend/app/game_engine.py#L166-L204)

**Section sources**
- [game_engine.py:166-204](file://backend/app/game_engine.py#L166-L204)

### NextYearResponse Structure and Frontend Communication
NextYearResponse is the canonical response model returned by advance_year() and consumed by the frontend.

- Fields:
  - age, realm, realm_name, cultivation, cultivation_max, events, attributes
  - Flags: is_dead, death_reason, is_ascended
  - Optional: has_choice, choice_event (for branching events)

- Frontend Consumption:
  - GameScreen.tsx calls nextYear() from api.ts, updates local state, and renders events.
  - Auto-play mode triggers rapid successive calls with short delays.

```mermaid
classDiagram
class NextYearResponse {
+int age
+int realm
+string realm_name
+int cultivation
+int cultivation_max
+dict[] events
+Attributes attributes
+bool is_dead
+string death_reason
+bool is_ascended
+bool has_choice
+dict choice_event
}
class Attributes {
+int lifespan
+int constitution
+int comprehension
+int fortune
+int charisma
+int willpower
}
NextYearResponse --> Attributes : "includes"
```

**Diagram sources**
- [models.py:137-151](file://backend/app/models.py#L137-L151)
- [models.py:48-56](file://backend/app/models.py#L48-L56)

**Section sources**
- [models.py:137-151](file://backend/app/models.py#L137-L151)
- [types.ts:40-51](file://frontend/src/utils/types.ts#L40-L51)
- [GameScreen.tsx:40-65](file://frontend/src/pages/GameScreen.tsx#L40-L65)
- [api.ts:36-47](file://frontend/src/utils/api.ts#L36-L47)

### Complete Simulation Cycle Examples
Below are two representative end-to-end cycles:

- Example A: Normal Cycle (no death, no ascension)
  - Advance Year: Death check passes, cultivation gain applied, 2–3 events selected and applied, breakthrough check performed, state updated, NextYearResponse returned.

- Example B: Death Cycle
  - Advance Year: Death check triggers, death event selected, is_dead flag set, death_reason recorded, NextYearResponse returned immediately.

- Example C: Ascension Cycle
  - Advance Year: Breakthrough check succeeds at realm 8, realm advances to 9, is_ascended flag set, ascension event returned, NextYearResponse with is_ascended=True.

These examples illustrate the strict order and early termination semantics enforced by advance_year().

**Section sources**
- [game_engine.py:311-394](file://backend/app/game_engine.py#L311-L394)
- [router.py:47-59](file://backend/app/router.py#L47-L59)

## Dependency Analysis
The simulation loop integrates several modules and external resources:

- Backend Dependencies:
  - game_engine.py depends on models.py for data structures, events/all_events.json for event data, and endings.py for scoring/title logic.
  - router.py exposes advance_year() via a REST endpoint.
  - main.py wires the router into the FastAPI application.

- Frontend Dependencies:
  - GameScreen.tsx consumes NextYearResponse and drives UI updates.
  - api.ts encapsulates HTTP calls to the backend.
  - types.ts mirrors backend models for type safety.

```mermaid
graph TB
GE["game_engine.py"] --> MD["models.py"]
GE --> EV["events/all_events.json"]
GE --> ED["endings.py"]
GE --> TL["talents.py"]
RT["router.py"] --> GE
MN["main.py"] --> RT
GS["GameScreen.tsx"] --> AP["api.ts"]
AP --> RT
GS --> TY["types.ts"]
```

**Diagram sources**
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [main.py:1-26](file://backend/app/main.py#L1-L26)
- [GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)

**Section sources**
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [main.py:1-26](file://backend/app/main.py#L1-L26)
- [GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)

## Performance Considerations
Rapid simulation modes (auto-play) can significantly increase throughput but require careful handling:

- Backend:
  - advance_year() is deterministic and lightweight; however, repeated rapid calls can overwhelm the server if not rate-limited.
  - Consider adding server-side throttling or batched simulation endpoints for extreme auto-play scenarios.

- Frontend:
  - Auto-play in GameScreen.tsx schedules successive calls with minimal delay. This can lead to rapid UI updates and potential race conditions if not coordinated carefully.
  - Recommended improvements:
    - Debounce rapid button clicks.
    - Use a queue to serialize requests and avoid overlapping calls.
    - Implement a maximum simulation speed cap.

- Event Selection:
  - Weighted selection uses a linear scan over eligible events. For very large event sets, consider precomputing cumulative weights or using a heap-based selection to reduce complexity.

- Memory:
  - GAME_STATES is an in-memory dictionary keyed by game_id. For production, consider persistence and eviction policies to manage long-running sessions.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:

- Game Not Found:
  - Symptom: HTTP 404 when calling /api/game/next-year.
  - Cause: advance_year() raises ValueError for missing game_id or ended games.
  - Resolution: Ensure game_id is valid and the game is still active.

- Game Already Over:
  - Symptom: Error indicating the game is already over.
  - Cause: advance_year() prevents advancing dead or ascended games.
  - Resolution: Retrieve life summary via /api/game/summary/{game_id}.

- No Events Available:
  - Symptom: Single “nothing” event returned.
  - Cause: No eligible events meet conditions for the current state.
  - Resolution: Adjust attributes, talents, or wait for future ages when more events become eligible.

- Death Occurrence:
  - Symptom: Immediate termination with is_dead=True.
  - Cause: Age exceeded max_age or random death chance triggered.
  - Resolution: Review attributes (e.g., increase lifespan/fortune) or adjust playstyle to reduce risk.

- Ascension:
  - Symptom: is_ascended=True returned.
  - Cause: Successful breakthrough at realm 9.
  - Resolution: Retrieve life summary to see title and score.

**Section sources**
- [router.py:47-59](file://backend/app/router.py#L47-L59)
- [game_engine.py:311-394](file://backend/app/game_engine.py#L311-L394)

## Conclusion
The simulation loop centers on advance_year(), which enforces a strict chronological order: death checks, cultivation gain, event selection and application, breakthrough verification, and state updates. The NextYearResponse structure provides a complete, real-time snapshot of the game state to the frontend, enabling responsive UI updates and seamless auto-play experiences. The event system integrates deeply with state conditions and attributes, while death and ascension logic provide meaningful end-of-life outcomes. For high-throughput scenarios, consider backend throttling and frontend request queuing to maintain stability and responsiveness.