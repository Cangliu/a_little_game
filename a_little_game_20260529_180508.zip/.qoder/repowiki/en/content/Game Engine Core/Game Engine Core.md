# Game Engine Core

<cite>
**Referenced Files in This Document**
- [game_engine.py](file://backend/app/game_engine.py)
- [models.py](file://backend/app/models.py)
- [talents.py](file://backend/app/talents.py)
- [router.py](file://backend/app/router.py)
- [main.py](file://backend/app/main.py)
- [endings.py](file://backend/app/endings.py)
- [event_generator.py](file://backend/app/event_generator.py)
- [all_events.json](file://backend/app/events/all_events.json)
- [cultivation.json](file://backend/app/events/cultivation.json)
- [death.json](file://backend/app/events/death.json)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the game engine core responsible for the central simulation logic and state management of the cultivation life simulator. It covers in-memory state storage, state transitions across game phases, integration with the talent and event systems, cultivation progression mechanics (realm advancement, breakthrough probabilities, and age-based mortality), and the engine’s role as the coordinator for all mechanics. It also documents the simulation loop, event processing pipeline, real-time state updates, and practical guidance for concurrency and persistence.

## Project Structure
The backend is organized around a FastAPI application with a clear separation of concerns:
- API entrypoint and routing
- Game engine core logic
- Data models and enums
- Talents and events subsystems
- Endings and scoring
- Event generation and storage

```mermaid
graph TB
subgraph "Backend"
A["main.py<br/>FastAPI app"]
B["router.py<br/>API routes"]
C["game_engine.py<br/>Core simulation"]
D["models.py<br/>Data models & enums"]
E["talents.py<br/>Talent definitions"]
F["endings.py<br/>Titles & scoring"]
G["event_generator.py<br/>Event generation"]
H["events/*.json<br/>Event catalogs"]
end
A --> B
B --> C
C --> D
C --> E
C --> F
C --> H
G --> H
```

**Diagram sources**
- [main.py:1-26](file://backend/app/main.py#L1-L26)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [event_generator.py:1-800](file://backend/app/event_generator.py#L1-L800)

**Section sources**
- [main.py:1-26](file://backend/app/main.py#L1-L26)
- [router.py:1-69](file://backend/app/router.py#L1-L69)

## Core Components
- In-memory state store: a dictionary keyed by game identifiers holding GameState instances.
- Simulation loop: year advancement that checks death, applies cultivation gains, selects and applies events, and evaluates breakthrough attempts.
- Event system: condition checking and effect application, with weighted selection influenced by attributes.
- Talent system: initial attribute bonuses and tags applied at game start.
- Endings and scoring: title assignment and score calculation based on age, realm, and attributes.

Key implementation references:
- State store and thresholds: [game_engine.py:31-45](file://backend/app/game_engine.py#L31-L45)
- Year advancement: [game_engine.py:311-394](file://backend/app/game_engine.py#L311-L394)
- Event selection and weighting: [game_engine.py:256-295](file://backend/app/game_engine.py#L256-L295)
- Attribute application from talents: [game_engine.py:52-61](file://backend/app/game_engine.py#L52-L61)
- Death and breakthrough logic: [game_engine.py:207-253](file://backend/app/game_engine.py#L207-L253), [game_engine.py:166-204](file://backend/app/game_engine.py#L166-L204)

**Section sources**
- [game_engine.py:31-45](file://backend/app/game_engine.py#L31-L45)
- [game_engine.py:256-295](file://backend/app/game_engine.py#L256-L295)
- [game_engine.py:311-394](file://backend/app/game_engine.py#L311-L394)
- [game_engine.py:52-61](file://backend/app/game_engine.py#L52-L61)
- [game_engine.py:166-204](file://backend/app/game_engine.py#L166-L204)
- [game_engine.py:207-253](file://backend/app/game_engine.py#L207-L253)

## Architecture Overview
The engine orchestrates state transitions and integrates with external systems:
- API layer validates requests and delegates to the engine.
- Engine updates GameState and returns structured responses.
- Events are loaded from JSON catalogs and filtered by conditions.
- Endings and scoring are computed post-mortem or upon ascension.

```mermaid
sequenceDiagram
participant Client as "Client"
participant API as "Router"
participant Engine as "GameEngine"
participant Events as "Events Catalog"
participant Endings as "Endings"
Client->>API : POST /api/game/start
API->>Engine : create_game(attributes, talents)
Engine-->>API : GameState
API-->>Client : {game_id, ...}
Client->>API : POST /api/game/next-year
API->>Engine : advance_year(game_id)
Engine->>Engine : check_death()
Engine->>Engine : process_cultivation_gain()
Engine->>Events : select_events()
Engine->>Engine : apply_event_effects()
Engine->>Engine : check_realm_breakthrough()
Engine-->>API : NextYearResponse
API-->>Client : {age, realm, events, ...}
Client->>API : GET /api/game/summary/{game_id}
API->>Engine : get_life_summary(game_id)
Engine->>Endings : get_title(), calculate_score()
Engine-->>API : LifeSummary
API-->>Client : {title, score, key_events, ...}
```

**Diagram sources**
- [router.py:18-44](file://backend/app/router.py#L18-L44)
- [router.py:47-58](file://backend/app/router.py#L47-L58)
- [router.py:61-68](file://backend/app/router.py#L61-L68)
- [game_engine.py:48-77](file://backend/app/game_engine.py#L48-L77)
- [game_engine.py:311-394](file://backend/app/game_engine.py#L311-L394)
- [endings.py:29-55](file://backend/app/endings.py#L29-L55)

## Detailed Component Analysis

### In-Memory State Storage and Persistence Strategy
- The engine maintains an in-memory dictionary keyed by game identifiers for all active games.
- Persistence is not implemented in the engine; state is ephemeral and lost on server restart.
- Recommended persistence strategies:
  - Store GameState in a database keyed by game_id.
  - Serialize/deserialize using Pydantic model dump/load patterns.
  - Use a queue/job system to persist state after each year tick.
  - Implement snapshotting for long-running sessions.

Implementation references:
- State store declaration: [game_engine.py:32](file://backend/app/game_engine.py#L32)
- Game creation and insertion: [game_engine.py:76](file://backend/app/game_engine.py#L76)

**Section sources**
- [game_engine.py:32](file://backend/app/game_engine.py#L32)
- [game_engine.py:76](file://backend/app/game_engine.py#L76)

### Simulation Loop and Real-Time State Updates
- Year advancement increments age and triggers:
  - Death check (including random chance and guaranteed death at max age)
  - Cultivation gain calculation
  - Event selection and application
  - Realm breakthrough evaluation
- Events are selected without replacement and weighted by attributes and event type.

```mermaid
flowchart TD
Start(["advance_year(game_id)"]) --> Load["Load GameState"]
Load --> Over{"is_dead or is_ascended?"}
Over --> |Yes| Error["Raise error"]
Over --> |No| Age["state.age += 1"]
Age --> DeathCheck["check_death()"]
DeathCheck --> Dead{"Died?"}
Dead --> |Yes| LogDeath["Append death event<br/>Return NextYearResponse(is_dead=True)"]
Dead --> |No| Gain["process_cultivation_gain()"]
Gain --> AddGain{"Gain > 0?"}
AddGain --> |Yes| ApplyGain["state.cultivation += gain"]
AddGain --> |No| SkipGain["Skip"]
ApplyGain --> Select["select_events(count)"]
SkipGain --> Select
Select --> ForEach["For each selected event"]
ForEach --> Apply["apply_event_effects()"]
Apply --> Log["Append to events_log"]
Log --> BreakCheck["check_realm_breakthrough()"]
BreakCheck --> Asc{"Ascended?"}
Asc --> |Yes| ReturnAsc["Return NextYearResponse(is_ascended=True)"]
Asc --> |No| Return["Return NextYearResponse"]
```

**Diagram sources**
- [game_engine.py:311-394](file://backend/app/game_engine.py#L311-L394)
- [game_engine.py:207-253](file://backend/app/game_engine.py#L207-L253)
- [game_engine.py:298-308](file://backend/app/game_engine.py#L298-L308)
- [game_engine.py:256-295](file://backend/app/game_engine.py#L256-L295)
- [game_engine.py:119-153](file://backend/app/game_engine.py#L119-L153)

**Section sources**
- [game_engine.py:311-394](file://backend/app/game_engine.py#L311-L394)
- [game_engine.py:207-253](file://backend/app/game_engine.py#L207-L253)
- [game_engine.py:298-308](file://backend/app/game_engine.py#L298-L308)
- [game_engine.py:256-295](file://backend/app/game_engine.py#L256-L295)
- [game_engine.py:119-153](file://backend/app/game_engine.py#L119-L153)

### State Transition Logic Between Game Phases
- Creation phase: Game starts with attributes and talents applied; initial tags recorded.
- Living phase: Repeated yearly cycles until death or ascension.
- Death/Ascension phase: Final summary computed and returned.

```mermaid
stateDiagram-v2
[*] --> Created
Created --> Living : "advance_year()"
Living --> Living : "advance_year()"
Living --> Died : "check_death() -> is_dead"
Living --> Ascended : "check_realm_breakthrough() -> is_ascended"
Died --> Summary : "get_life_summary()"
Ascended --> Summary : "get_life_summary()"
Summary --> [*]
```

**Diagram sources**
- [game_engine.py:48-77](file://backend/app/game_engine.py#L48-L77)
- [game_engine.py:311-394](file://backend/app/game_engine.py#L311-L394)
- [game_engine.py:396-424](file://backend/app/game_engine.py#L396-L424)

**Section sources**
- [game_engine.py:48-77](file://backend/app/game_engine.py#L48-L77)
- [game_engine.py:311-394](file://backend/app/game_engine.py#L311-L394)
- [game_engine.py:396-424](file://backend/app/game_engine.py#L396-L424)

### Integration With Talent System
- Talents modify initial attributes and add tags.
- Tags influence event eligibility and gameplay flavor.

Implementation references:
- Talent application during creation: [game_engine.py:52-61](file://backend/app/game_engine.py#L52-L61)
- Talent definitions: [talents.py:3-48](file://backend/app/talents.py#L3-L48)

**Section sources**
- [game_engine.py:52-61](file://backend/app/game_engine.py#L52-L61)
- [talents.py:3-48](file://backend/app/talents.py#L3-L48)

### Integration With Event System
- Events are loaded from JSON catalogs and filtered by conditions.
- Conditions include age, realm, cultivation, required/excluded talents/tags, and attribute thresholds.
- Effects modify attributes, tags, cultivation, and can trigger realm advancement.

Implementation references:
- Event loading and filtering: [game_engine.py:19-29](file://backend/app/game_engine.py#L19-L29), [game_engine.py:80-116](file://backend/app/game_engine.py#L80-L116)
- Effect application: [game_engine.py:119-153](file://backend/app/game_engine.py#L119-L153)
- Event catalog structure: [all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200), [cultivation.json:1-200](file://backend/app/events/cultivation.json#L1-L200), [death.json:1-200](file://backend/app/events/death.json#L1-L200)

**Section sources**
- [game_engine.py:19-29](file://backend/app/game_engine.py#L19-L29)
- [game_engine.py:80-116](file://backend/app/game_engine.py#L80-L116)
- [game_engine.py:119-153](file://backend/app/game_engine.py#L119-L153)
- [all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)
- [cultivation.json:1-200](file://backend/app/events/cultivation.json#L1-L200)
- [death.json:1-200](file://backend/app/events/death.json#L1-L200)

### Cultivation Progression Mechanics
- Realm thresholds define progression targets per realm.
- Base cultivation gain depends on realm and attributes.
- Breakthrough probability increases with comprehension and fortune, capped at a maximum.

Formulas and mechanics:
- Realm thresholds: [game_engine.py:35-45](file://backend/app/game_engine.py#L35-L45)
- Base cultivation gain: [game_engine.py:298-308](file://backend/app/game_engine.py#L298-L308)
- Breakthrough chance: [game_engine.py:174-178](file://backend/app/game_engine.py#L174-L178)
- Breakthrough effect: [game_engine.py:180-183](file://backend/app/game_engine.py#L180-L183)

```mermaid
flowchart TD
A["Base Gain = f(comprehension, constitution, realm)"] --> B["Add realm modifier"]
B --> C["state.cultivation += gain"]
C --> D{"cultivation >= threshold?"}
D --> |No| E["Wait for next year"]
D --> |Yes| F["Compute chance = base + comp_bonus + fort_bonus"]
F --> G{"Random() < chance?"}
G --> |No| H["Remain in current realm"]
G --> |Yes| I["state.realm += 1<br/>state.cultivation = 0"]
```

**Diagram sources**
- [game_engine.py:298-308](file://backend/app/game_engine.py#L298-L308)
- [game_engine.py:174-183](file://backend/app/game_engine.py#L174-L183)

**Section sources**
- [game_engine.py:35-45](file://backend/app/game_engine.py#L35-L45)
- [game_engine.py:298-308](file://backend/app/game_engine.py#L298-L308)
- [game_engine.py:174-183](file://backend/app/game_engine.py#L174-L183)

### Age-Based Mortality System
- Maximum age varies by realm; higher realms grant extended lifespans.
- Mortality has two components:
  - Guaranteed death at or beyond maximum age.
  - Increasing random death chance approaching maximum age.
- Fortune reduces death chance; special modifiers for early adult ages.

Mechanics:
- Max age calculation: [game_engine.py:155-163](file://backend/app/game_engine.py#L155-L163)
- Random death chance: [game_engine.py:231-241](file://backend/app/game_engine.py#L231-L241)
- Death event selection: [game_engine.py:213-229](file://backend/app/game_engine.py#L213-L229)

**Section sources**
- [game_engine.py:155-163](file://backend/app/game_engine.py#L155-L163)
- [game_engine.py:231-241](file://backend/app/game_engine.py#L231-L241)
- [game_engine.py:213-229](file://backend/app/game_engine.py#L213-L229)

### Endings and Scoring
- Titles depend on age and realm ranges.
- Final score combines title score, attribute sum bonus, and age bonus.

References:
- Titles and scoring: [endings.py:3-19](file://backend/app/endings.py#L3-L19), [endings.py:46-55](file://backend/app/endings.py#L46-L55)

**Section sources**
- [endings.py:3-19](file://backend/app/endings.py#L3-L19)
- [endings.py:46-55](file://backend/app/endings.py#L46-L55)

## Dependency Analysis
The engine depends on models, talents, and event catalogs. Router and main glue the API to the engine.

```mermaid
graph LR
Router["router.py"] --> Engine["game_engine.py"]
Engine --> Models["models.py"]
Engine --> Talents["talents.py"]
Engine --> Events["events/*.json"]
Engine --> Endings["endings.py"]
Main["main.py"] --> Router
```

**Diagram sources**
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [game_engine.py:1-14](file://backend/app/game_engine.py#L1-L14)
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [main.py:1-26](file://backend/app/main.py#L1-L26)

**Section sources**
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [game_engine.py:1-14](file://backend/app/game_engine.py#L1-L14)
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [main.py:1-26](file://backend/app/main.py#L1-L26)

## Performance Considerations
- Event selection uses weighted sampling without replacement; complexity grows with eligible events. For large catalogs, consider precomputing weights and using reservoir sampling or binary search over cumulative weights.
- Death and breakthrough checks are O(1); negligible overhead.
- Attribute-based modifiers scale linearly with event count per year.
- Concurrency:
  - Current in-memory store is not thread-safe; use locks or separate stores per session.
  - Consider async-friendly patterns if scaling to many concurrent sessions.
- Persistence:
  - Replace in-memory store with a persistent store (e.g., Redis or Postgres) keyed by game_id.
  - Batch writes and use transactions for atomic updates.
- Caching:
  - Cache event catalogs and talent pools to reduce disk I/O.
  - Cache realm thresholds and max age computations if frequently accessed.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and remedies:
- Game not found or already ended:
  - Symptoms: 404 errors when advancing year or retrieving summary.
  - Causes: Using invalid game_id or calling after death/ascension.
  - Fixes: Validate game_id and handle end-of-life states in client.
  - References: [router.py:54-58](file://backend/app/router.py#L54-L58), [router.py:64-68](file://backend/app/router.py#L64-L68), [game_engine.py:314-318](file://backend/app/game_engine.py#L314-L318)
- Attribute validation failures:
  - Symptoms: 400 errors on start.
  - Causes: Exceeded attribute point cap or too many talents.
  - Fixes: Enforce limits in client or adjust validation.
  - References: [router.py:21-31](file://backend/app/router.py#L21-L31)
- No eligible events:
  - Symptoms: “Nothing happens” events logged.
  - Causes: Strict conditions or low fortune reducing selection.
  - Fixes: Adjust conditions or increase fortune modifier.
  - References: [game_engine.py:256-268](file://backend/app/game_engine.py#L256-L268), [game_engine.py:270-280](file://backend/app/game_engine.py#L270-L280)

**Section sources**
- [router.py:54-58](file://backend/app/router.py#L54-L58)
- [router.py:64-68](file://backend/app/router.py#L64-L68)
- [game_engine.py:314-318](file://backend/app/game_engine.py#L314-L318)
- [router.py:21-31](file://backend/app/router.py#L21-L31)
- [game_engine.py:256-268](file://backend/app/game_engine.py#L256-L268)
- [game_engine.py:270-280](file://backend/app/game_engine.py#L270-L280)

## Conclusion
The game engine core provides a robust, modular simulation framework centered on a simple in-memory state model. It integrates tightly with the talent and event systems, implements realistic cultivation progression with probabilistic breakthroughs, and enforces age-based mortality. For production, replace the in-memory store with a persistent solution, add concurrency controls, and optimize event selection for large catalogs. The provided APIs and data models offer a clear path to scaling and extending the simulation.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### API Definitions
- POST /api/game/start
  - Request: StartGameRequest (attributes, talents)
  - Response: Initial game state including game_id, age, realm, attributes, talents, tags
  - Validation: Total attributes ≤ 20; talents ≤ 3
  - References: [router.py:18-44](file://backend/app/router.py#L18-L44)

- POST /api/game/next-year
  - Request: { game_id }
  - Response: NextYearResponse (age, realm, events, attributes, is_dead, death_reason, is_ascended)
  - References: [router.py:47-58](file://backend/app/router.py#L47-L58)

- GET /api/game/summary/{game_id}
  - Response: LifeSummary (title, score, key_events, final_attributes)
  - References: [router.py:61-68](file://backend/app/router.py#L61-L68)

**Section sources**
- [router.py:18-44](file://backend/app/router.py#L18-L44)
- [router.py:47-58](file://backend/app/router.py#L47-L58)
- [router.py:61-68](file://backend/app/router.py#L61-L68)

### Data Models Overview
- GameState: game_id, age, realm, cultivation, attributes, talents, tags, events_log, is_dead, death_reason, is_ascended
- Attributes: lifespan, constitution, comprehension, fortune, charisma, willpower
- Realm: Enum with 10 stages (Mortal to Ascension)
- NextYearResponse: Yearly state snapshot plus events
- LifeSummary: Final title, score, key events, final attributes

**Section sources**
- [models.py:116-171](file://backend/app/models.py#L116-L171)