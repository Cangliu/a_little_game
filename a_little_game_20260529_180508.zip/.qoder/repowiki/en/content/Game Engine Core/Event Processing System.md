# Event Processing System

<cite>
**Referenced Files in This Document**
- [event_generator.py](file://backend/app/event_generator.py)
- [game_engine.py](file://backend/app/game_engine.py)
- [models.py](file://backend/app/models.py)
- [talents.py](file://backend/app/talents.py)
- [all_events.json](file://backend/app/events/all_events.json)
- [common.json](file://backend/app/events/common.json)
- [cultivation.json](file://backend/app/events/cultivation.json)
- [fortune.json](file://backend/app/events/fortune.json)
- [calamity.json](file://backend/app/events/calamity.json)
- [social.json](file://backend/app/events/social.json)
- [world.json](file://backend/app/events/world.json)
- [death.json](file://backend/app/events/death.json)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction

The Event Processing System is a core component of the cultivation life simulator that manages dynamic storytelling through randomized events. This system generates thousands of unique events across multiple categories, evaluates complex conditional requirements, applies weighted selection mechanisms, and executes meaningful consequences that shape character development throughout the game lifecycle.

The system operates on a sophisticated event-driven architecture where events are categorized into distinct themes (common, calamity, fortune, social, world, cultivation, death) and processed through a multi-stage pipeline involving condition evaluation, weighted selection, and effect application.

## Project Structure

The event processing system is organized around several key architectural layers:

```mermaid
graph TB
subgraph "Event Generation Layer"
EG[event_generator.py]
EV[Event Templates]
end
subgraph "Event Storage Layer"
AJ[all_events.json]
CJ[common.json]
FJ[fortune.json]
C1[cultivation.json]
SJ[social.json]
WJ[world.json]
DJ[death.json]
CJJ[calamity.json]
end
subgraph "Runtime Engine Layer"
GE[game_engine.py]
TM[talents.py]
MD[models.py]
end
subgraph "Data Models Layer"
AM[Attributes Model]
GM[GameState Model]
EM[Event Model]
end
EG --> EV
EV --> AJ
AJ --> GE
TM --> GE
MD --> GE
GE --> AM
GE --> GM
GE --> EM
```

**Diagram sources**
- [event_generator.py:1-879](file://backend/app/event_generator.py#L1-L879)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [models.py:1-171](file://backend/app/models.py#L1-L171)

**Section sources**
- [event_generator.py:1-879](file://backend/app/event_generator.py#L1-L879)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [models.py:1-171](file://backend/app/models.py#L1-L171)

## Core Components

### Event Loading Mechanism

The system employs a dual-loading strategy combining pre-generated JSON files with runtime generation capabilities:

```mermaid
sequenceDiagram
participant Loader as "Event Loader"
participant JSON as "JSON Files"
participant Memory as "Memory Store"
participant Engine as "Game Engine"
Loader->>JSON : Load all_events.json
JSON-->>Loader : Event Array
Loader->>Memory : Store ALL_EVENTS
Memory-->>Engine : Ready Events
Engine->>Engine : Initialize GAME_STATES
Engine-->>Engine : Ready for processing
```

**Diagram sources**
- [game_engine.py:19-29](file://backend/app/game_engine.py#L19-L29)

The loading mechanism supports both bulk loading from pre-generated JSON files and dynamic generation from templates, enabling scalability and maintainability.

### Condition Evaluation System

The condition evaluation system implements comprehensive filtering logic:

```mermaid
flowchart TD
Start([Event Selection]) --> CheckAge["Check Age Conditions<br/>min_age/max_age"]
CheckAge --> AgeValid{"Age Within Range?"}
AgeValid --> |No| Reject["Reject Event"]
AgeValid --> |Yes| CheckRealm["Check Realm Conditions<br/>min_realm/max_realm"]
CheckRealm --> RealmValid{"Realm Within Range?"}
RealmValid --> |No| Reject
RealmValid --> |Yes| CheckCultivation["Check Cultivation Level<br/>min_cultivation"]
CheckCultivation --> CultValid{"Cultivation ≥ Threshold?"}
CultValid --> |No| Reject
CultValid --> CheckTalents["Check Required Talents<br/>required_talents"]
CheckTalents --> TalentValid{"Has Required Talents?"}
TalentValid --> |No| Reject
TalentValid --> CheckTags["Check Tag Conditions<br/>required_tags/excluded_tags"]
CheckTags --> TagValid{"Tag Requirements Met?"}
TagValid --> |No| Reject
TagValid --> CheckAttributes["Check Attribute Minimums<br/>min_attribute"]
CheckAttributes --> AttrValid{"Attribute Requirements Met?"}
AttrValid --> |No| Reject
AttrValid --> Accept["Accept Event"]
Reject --> End([End])
Accept --> End
```

**Diagram sources**
- [game_engine.py:80-116](file://backend/app/game_engine.py#L80-L116)

### Weighted Selection Algorithm

The weighted selection system implements a sophisticated probability mechanism:

```mermaid
flowchart TD
Start([Event Selection]) --> FilterEligible["Filter Eligible Events<br/>by conditions"]
FilterEligible --> CheckEmpty{"Any Eligible Events?"}
CheckEmpty --> |No| DefaultEvent["Return Default Event"]
CheckEmpty --> |Yes| CalculateWeights["Calculate Weighted Scores<br/>Base Weight × Modifier"]
CalculateWeights --> ModifierCalc["Apply Fortune Modifier<br/>Fortune: ×(1+0.05×fortune)<br/>Danger: ×max(0.5, 1-0.02×fortune)"]
ModifierCalc --> NormalizeWeights["Normalize Weights<br/>Sum = Total Weight"]
NormalizeWeights --> SelectEvent["Weighted Random Selection<br/>Cumulative Probability"]
SelectEvent --> RemoveSelected["Remove Selected Event<br/>Without Replacement"]
RemoveSelected --> CheckCount{"More Selections Needed?"}
CheckCount --> |Yes| CalculateWeights
CheckCount --> |No| ReturnEvents["Return Selected Events"]
DefaultEvent --> ReturnEvents
```

**Diagram sources**
- [game_engine.py:256-295](file://backend/app/game_engine.py#L256-L295)

### Effect Application System

The effect application system processes event consequences through a structured pipeline:

```mermaid
sequenceDiagram
participant Event as "Event"
participant Engine as "Game Engine"
participant State as "GameState"
participant Effects as "Effect Handler"
Event->>Engine : apply_event_effects()
Engine->>Effects : Parse Effects Dictionary
Effects->>State : Update Attributes<br/>cultivation, lifespan, constitution, etc.
Effects->>State : Manage Tags<br/>add_tag/remove_tag
Effects->>State : Check Realm Advancement<br/>realm_up
Effects->>State : Handle Death Conditions<br/>death flag
State-->>Engine : Updated GameState
Engine-->>Engine : Apply Realm Thresholds
```

**Diagram sources**
- [game_engine.py:119-153](file://backend/app/game_engine.py#L119-L153)

**Section sources**
- [game_engine.py:80-153](file://backend/app/game_engine.py#L80-L153)

## Architecture Overview

The event processing system follows a modular architecture with clear separation of concerns:

```mermaid
graph TB
subgraph "Event Generation Pipeline"
TG[Template Generator]
VG[Variation Generator]
LG[Legacy Generator]
end
subgraph "Event Storage"
PJ[Pre-generated JSON]
DJ[Dynamic JSON]
end
subgraph "Runtime Processing"
CE[Condition Evaluator]
WS[Weighted Selector]
EA[Effect Applier]
RT[Realm Tracker]
end
subgraph "Integration Layer"
TL[Talent System]
AT[Attribute Manager]
TS[Tag System]
end
TG --> PJ
VG --> PJ
LG --> PJ
PJ --> CE
DJ --> CE
CE --> WS
WS --> EA
EA --> RT
TL --> CE
AT --> EA
TS --> EA
```

**Diagram sources**
- [event_generator.py:14-879](file://backend/app/event_generator.py#L14-L879)
- [game_engine.py:19-29](file://backend/app/game_engine.py#L19-L29)

## Detailed Component Analysis

### Event Categories and Structure

The system organizes events into seven primary categories, each serving distinct narrative purposes:

#### Common Events
Common events form the foundation of character development, covering life milestones and everyday experiences:

| Category | Purpose | Examples | Typical Effects |
|----------|---------|----------|-----------------|
| Birth | Origin stories | Family background, early life circumstances | Attribute bonuses, initial tags |
| Childhood | Formative years | Learning experiences, social interactions | Comprehension, charisma, willpower |
| Mortal Life | Pre-cultivation existence | Work, relationships, daily struggles | Fortune, basic attributes |
| Aging | Later life stages | Physical decline, wisdom accumulation | Constitution, lifespan |

#### Cultivation Events
Cultivation events drive spiritual progression through structured advancement:

```mermaid
graph LR
subgraph "Cultivation Stages"
MR[0: Mortal] --> QR[1: Qi Refining]
QR --> FB[2: Foundation Building]
FB --> GC[3: Golden Core]
GC --> NS[4: Nascent Soul]
NS --> HD[5+: High Realms]
end
subgraph "Event Types"
CE[Cultivation Events]
SE[Skill Events]
BE[Breakthrough Events]
TE[Training Events]
end
CE --> SE
CE --> BE
CE --> TE
SE --> QR
BE --> FB
TE --> GC
```

**Diagram sources**
- [cultivation.json:1-22088](file://backend/app/events/cultivation.json#L1-L22088)

#### Fortune Events
Fortune events represent positive encounters and discoveries:

| Event Type | Frequency | Typical Outcomes |
|------------|-----------|------------------|
| Treasures | High | Immediate attribute gains, resource acquisition |
| Encounters | Medium | Social interactions, mentorship opportunities |
| Discoveries | Low | Unique items, knowledge, abilities |
| Dreams/Visions | Very Low | Insightful revelations, future hints |

#### Calamity Events
Calamity events introduce challenges and obstacles:

| Calamity Type | Risk Level | Typical Consequences |
|---------------|------------|---------------------|
| Natural Disasters | High | Attribute penalties, temporary setbacks |
| Combat Encounters | Medium | Health damage, resource loss |
| Spiritual Hazards | High | Cultivation regression, mental strain |
| Social Conflicts | Medium | Relationship damage, reputation loss |

#### Social Events
Social events manage interpersonal relationships and community dynamics:

| Social Category | Focus | Impact Areas |
|----------------|-------|--------------|
| Sect Events | Organization | Cultivation progress, social status |
| Master Events | Mentorship | Skill development, emotional growth |
| Romance Events | Relationships | Charisma, emotional bonds |
| Rival Events | Competition | Willpower, competitive spirit |

#### World Events
World events reflect broader environmental and societal changes:

| World Event Type | Scope | Impact |
|------------------|-------|--------|
| Natural Phenomena | Local | Environmental effects, resource availability |
| Seasonal Changes | Regional | Periodic benefits/penalties |
| Historical Events | Global | Cultural knowledge, historical context |
| Celestial Events | Universal | Rare, powerful effects |

#### Death Events
Death events provide narrative closure and meaningful endings:

| Death Cause | Realm Threshold | Narrative Significance |
|-------------|-----------------|----------------------|
| Natural Causes | Any | Life completion, legacy |
| Accidents | Early stages | Suddenness, fragility |
| Spiritual Failure | Advanced stages | Consequences of choices |
| Cosmic Events | Highest stages | Transcendence, achievement |

**Section sources**
- [common.json:1-3633](file://backend/app/events/common.json#L1-L3633)
- [cultivation.json:1-22088](file://backend/app/events/cultivation.json#L1-L22088)
- [fortune.json:1-9512](file://backend/app/events/fortune.json#L1-L9512)
- [calamity.json:1-5603](file://backend/app/events/calamity.json#L1-L5603)
- [social.json:1-8183](file://backend/app/events/social.json#L1-L8183)
- [world.json:1-1368](file://backend/app/events/world.json#L1-L1368)
- [death.json:1-427](file://backend/app/events/death.json#L1-L427)

### Conditional Event Triggering

The condition system implements multi-layered filtering for precise event targeting:

#### Age-Based Conditions
Age restrictions ensure events align with character life stages:
- **Childhood (1-11 years)**: Focus on learning and development
- **Adolescence (12-17 years)**: Social interactions and preparation
- **Young adulthood (18-29 years)**: Career and relationship formation
- **Maturity (30+ years)**: Established life paths and responsibilities

#### Realm-Based Conditions
Realm restrictions control spiritual progression timing:
- **Mortal (0)**: No cultivation events
- **Qi Refining (1)**: Basic spiritual awareness
- **Foundation (2)**: Initial spiritual development
- **Golden Core (3)**: Advanced spiritual capabilities
- **Nascent Soul (4)**: Higher spiritual understanding
- **High Realms (5+)**: Mastery and transcendence

#### Attribute-Based Conditions
Attribute requirements ensure meaningful challenge scaling:
- **Minimum Attributes**: Prevent trivial events for powerful characters
- **Attribute Bonuses**: Reward character development
- **Balance Mechanisms**: Prevent overpowered combinations

#### Talent Integration
Talent systems integrate with event conditions:
- **Required Talents**: Unlock specialized events
- **Talent-Specific Effects**: Modify event outcomes
- **Talent-Based Weighting**: Influence event probability

**Section sources**
- [game_engine.py:80-116](file://backend/app/game_engine.py#L80-L116)
- [talents.py:1-85](file://backend/app/talents.py#L1-L85)

### Weighted Selection Implementation

The weighted selection algorithm ensures balanced event distribution:

#### Base Weighting System
Each event maintains a base weight reflecting rarity and impact:
- **Common Events**: 40-60 weight
- **Uncommon Events**: 20-40 weight  
- **Rare Events**: 10-25 weight
- **Legendary Events**: 5-15 weight

#### Dynamic Modifier System
Fortune attribute influences event probability:
- **Fortune Bonus**: Events become more likely (+5% per fortune point)
- **Danger Penalty**: Dangerous events become less likely (-2% per fortune point)
- **Balanced Distribution**: Prevents excessive risk-taking

#### Selection Without Replacement
The algorithm prevents event repetition within selection rounds:
- **Event Removal**: Selected events removed from pool
- **Probability Recalculation**: Remaining events adjusted proportionally
- **Guaranteed Diversity**: Ensures varied experience

**Section sources**
- [game_engine.py:256-295](file://backend/app/game_engine.py#L256-L295)

### Effect Application Processing

The effect application system handles complex consequence chains:

#### Attribute Modification
Direct attribute adjustments follow strict rules:
- **Cultivation**: Primary progression metric
- **Lifespan**: Maximum age modifier
- **Constitution**: Physical strength and health
- **Comprehension**: Learning and understanding speed
- **Fortune**: Luck and opportunity
- **Charisma**: Social influence
- **Willpower**: Mental resilience

#### Tag Management System
Tags control event eligibility and story progression:
- **Add Tags**: Unlock new event categories
- **Remove Tags**: Close off previous paths
- **Conditional Access**: Require specific tags for events
- **Narrative Consistency**: Maintain story coherence

#### Realm Advancement Triggers
Breakthrough events initiate spiritual progression:
- **Threshold Checking**: Compare cultivation against realm requirements
- **Chance Calculation**: Base chance modified by attributes
- **Success Effects**: Automatic realm advancement
- **Failure Consequences**: Potential penalties

#### Death Event Integration
Death events provide meaningful narrative conclusions:
- **Cause Tracking**: Record death reason for summary
- **Early Death Prevention**: Ensure minimum lifespan
- **Legacy Preservation**: Maintain character achievements
- **Narrative Closure**: Provide satisfying endings

**Section sources**
- [game_engine.py:119-153](file://backend/app/game_engine.py#L119-L153)

## Dependency Analysis

The event processing system exhibits well-managed dependencies:

```mermaid
graph TD
subgraph "External Dependencies"
PY[Python Standard Library]
JSON[JSON Processing]
RANDOM[Random Number Generation]
OS[File System Operations]
end
subgraph "Internal Dependencies"
GE[game_engine.py]
EG[event_generator.py]
TM[talents.py]
MD[models.py]
end
subgraph "Event Data Dependencies"
AJ[all_events.json]
CJ[common.json]
FJ[fortune.json]
C1[cultivation.json]
SJ[social.json]
WJ[world.json]
DJ[death.json]
CJJ[calamity.json]
end
PY --> GE
JSON --> GE
RANDOM --> GE
OS --> GE
GE --> TM
GE --> MD
GE --> AJ
EG --> AJ
TM --> GE
MD --> GE
AJ --> GE
CJ --> GE
FJ --> GE
C1 --> GE
SJ --> GE
WJ --> GE
DJ --> GE
CJJ --> GE
```

**Diagram sources**
- [game_engine.py:1-14](file://backend/app/game_engine.py#L1-L14)
- [event_generator.py:1-11](file://backend/app/event_generator.py#L1-L11)

### Data Flow Dependencies

The system maintains clear data flow patterns:

```mermaid
sequenceDiagram
participant Template as "Template Generator"
participant JSON as "JSON Storage"
participant Engine as "Game Engine"
participant Player as "Player State"
Template->>JSON : Generate Event Templates
JSON->>Engine : Load Events
Engine->>Player : Initialize State
Player->>Engine : Request Events
Engine->>Engine : Evaluate Conditions
Engine->>Engine : Apply Weighting
Engine->>Player : Return Events
Player->>Engine : Apply Effects
Engine->>Player : Update State
```

**Diagram sources**
- [event_generator.py:14-879](file://backend/app/event_generator.py#L14-L879)
- [game_engine.py:19-29](file://backend/app/game_engine.py#L19-L29)

**Section sources**
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [event_generator.py:1-879](file://backend/app/event_generator.py#L1-L879)

## Performance Considerations

### Event Loading Optimization
- **Lazy Loading**: Events loaded only when needed
- **Memory Management**: Efficient JSON parsing and storage
- **Caching Strategy**: In-memory event cache for frequent access

### Selection Algorithm Efficiency
- **Weight Normalization**: Pre-calculated weight sums
- **Cumulative Probability**: Single pass selection algorithm
- **Replacement Strategy**: Efficient removal without reindexing

### Condition Evaluation Optimization
- **Short-Circuit Logic**: Early rejection of invalid events
- **Batch Processing**: Multiple events evaluated simultaneously
- **Indexing Strategy**: Pre-filtered event categories

### Memory Usage Patterns
- **Event Pool Management**: Controlled memory footprint
- **State Tracking**: Minimal state duplication
- **Garbage Collection**: Efficient cleanup of unused data

## Troubleshooting Guide

### Common Issues and Solutions

#### Event Not Appearing
**Symptoms**: Expected events never trigger
**Causes**: 
- Age/realm conditions not met
- Required talents missing
- Attribute requirements too high
- Weight too low

**Solutions**:
- Verify character state meets conditions
- Check talent requirements
- Adjust attribute levels
- Increase event weight

#### Excessive Danger Events
**Symptoms**: Too many negative events
**Causes**:
- High fortune attribute reducing danger penalty
- Low fortune attribute increasing danger likelihood
- Event weighting imbalance

**Solutions**:
- Reduce fortune attribute impact
- Adjust danger event weights
- Implement event diversity checks

#### Balanced Event Distribution
**Symptoms**: Repetitive event types
**Causes**:
- Selection without replacement exhausted
- Weighting favoring specific categories
- Insufficient event variety

**Solutions**:
- Implement fallback event pools
- Adjust weight distributions
- Add event variation mechanisms

### Debugging Tools and Techniques

#### Event Logging
Enable detailed logging for event processing:
- Condition evaluation results
- Weight calculation details
- Selection outcomes
- Effect application results

#### State Monitoring
Track character state changes:
- Attribute modifications
- Tag additions/removals
- Realm advancement timing
- Death event triggers

#### Performance Profiling
Monitor system performance:
- Event loading times
- Selection algorithm efficiency
- Memory usage patterns
- CPU utilization during processing

**Section sources**
- [game_engine.py:19-29](file://backend/app/game_engine.py#L19-L29)

## Conclusion

The Event Processing System represents a sophisticated approach to dynamic storytelling in the cultivation life simulator. Through careful organization of event categories, robust condition evaluation, intelligent weighted selection, and comprehensive effect application, the system creates engaging, personalized experiences that evolve with character development.

The modular architecture ensures maintainability while the integration with the talent system and attribute management provides deep strategic depth. The system's ability to balance randomness with meaningful consequences creates compelling narratives that adapt to player choices and character progression.

Future enhancements could include dynamic event difficulty scaling, more sophisticated narrative branching, and expanded integration with external storytelling systems. The current architecture provides a solid foundation for these extensions while maintaining the core principles of balanced randomness and meaningful character development.