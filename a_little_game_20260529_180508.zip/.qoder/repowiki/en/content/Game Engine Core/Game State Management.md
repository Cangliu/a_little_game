# Game State Management

<cite>
**Referenced Files in This Document**
- [models.py](file://backend/app/models.py)
- [game_engine.py](file://backend/app/game_engine.py)
- [router.py](file://backend/app/router.py)
- [main.py](file://backend/app/main.py)
- [talents.py](file://backend/app/talents.py)
- [endings.py](file://backend/app/endings.py)
- [all_events.json](file://backend/app/events/all_events.json)
- [api.ts](file://frontend/src/utils/api.ts)
- [types.ts](file://frontend/src/utils/types.ts)
- [GameScreen.tsx](file://frontend/src/pages/GameScreen.tsx)
- [requirements.txt](file://backend/requirements.txt)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the game state management subsystem for the cultivation life simulator. It covers in-memory state storage via a global dictionary, UUID-based short identifiers, state transitions across game phases (creation, playing, completion), validation and constraints, concurrent session handling, and practical considerations for production deployments such as persistence and memory management. It also documents the GameState data model, state creation and retrieval patterns, and the serialization/deserialization pipeline used by the API.

## Project Structure
The game state management spans backend Python modules and frontend TypeScript utilities:
- Backend:
  - Data models and Pydantic schemas define the GameState and supporting structures.
  - Game engine manages state lifecycle, event selection, and realm progression.
  - Router exposes REST endpoints for game creation, progression, and summaries.
  - Endpoints and event data are loaded at startup.
- Frontend:
  - TypeScript types mirror backend models for type safety.
  - API utilities encapsulate HTTP calls to the backend.

```mermaid
graph TB
subgraph "Backend"
M["main.py"]
R["router.py"]
GE["game_engine.py"]
MD["models.py"]
TL["talents.py"]
ED["endings.py"]
EV["events/all_events.json"]
end
subgraph "Frontend"
AT["api.ts"]
TT["types.ts"]
GS["GameScreen.tsx"]
end
AT --> R
TT --> AT
GS --> AT
M --> R
R --> GE
GE --> MD
GE --> TL
GE --> ED
GE --> EV
```

**Diagram sources**
- [main.py:1-26](file://backend/app/main.py#L1-L26)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)
- [GameScreen.tsx:1-87](file://frontend/src/pages/GameScreen.tsx#L1-L87)

**Section sources**
- [main.py:1-26](file://backend/app/main.py#L1-L26)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)
- [GameScreen.tsx:1-87](file://frontend/src/pages/GameScreen.tsx#L1-L87)

## Core Components
- GameState: The central in-memory representation of a player’s life, including identity, age, realm, cultivation progress, attributes, talents, tags, event log, and end-state flags.
- GAME_STATES: An in-memory dictionary keyed by game_id that stores active GameState instances.
- UUID-based IDs: Shortened UUIDs are used as game identifiers for compact keys.
- Event system: Events are loaded from JSON and filtered/weighted based on state conditions.
- REST API: Endpoints expose game creation, annual progression, and summary retrieval.

Key implementation references:
- GameState definition and related models: [models.py:116-171](file://backend/app/models.py#L116-L171)
- In-memory store and constants: [game_engine.py:31-46](file://backend/app/game_engine.py#L31-L46)
- Game creation and ID generation: [game_engine.py:48-77](file://backend/app/game_engine.py#L48-L77)
- Event loading and selection: [game_engine.py:19-29](file://backend/app/game_engine.py#L19-L29), [game_engine.py:256-295](file://backend/app/game_engine.py#L256-L295)
- API exposure: [router.py:18-68](file://backend/app/router.py#L18-L68)

**Section sources**
- [models.py:116-171](file://backend/app/models.py#L116-L171)
- [game_engine.py:31-77](file://backend/app/game_engine.py#L31-L77)
- [router.py:18-68](file://backend/app/router.py#L18-L68)

## Architecture Overview
The system follows a thin-client architecture:
- Frontend sends requests to backend endpoints.
- Backend validates inputs, updates in-memory state, selects and applies events, and returns structured responses.
- Responses conform to Pydantic models, ensuring consistent serialization.

```mermaid
sequenceDiagram
participant FE as "Frontend"
participant API as "router.py"
participant GE as "game_engine.py"
participant ST as "GAME_STATES"
FE->>API : "POST /api/game/start"
API->>GE : "create_game(attributes, talents)"
GE->>ST : "store GameState by game_id"
GE-->>API : "GameState"
API-->>FE : "JSON response"
loop Annual progression
FE->>API : "POST /api/game/next-year"
API->>GE : "advance_year(game_id)"
GE->>ST : "retrieve GameState"
GE->>GE : "check_death/select_events/apply effects"
GE-->>API : "NextYearResponse"
API-->>FE : "JSON response"
end
FE->>API : "GET /api/game/summary/{game_id}"
API->>GE : "get_life_summary(game_id)"
GE-->>API : "LifeSummary"
API-->>FE : "JSON response"
```

**Diagram sources**
- [router.py:18-68](file://backend/app/router.py#L18-L68)
- [game_engine.py:48-77](file://backend/app/game_engine.py#L48-L77)
- [game_engine.py:311-393](file://backend/app/game_engine.py#L311-L393)
- [game_engine.py:396-423](file://backend/app/game_engine.py#L396-L423)

## Detailed Component Analysis

### GameState Data Model
GameState captures the complete state of a player’s life:
- Identity: game_id
- Lifecycle: age, realm, cultivation
- Attributes: six core stats (lifespan, constitution, comprehension, fortune, charisma, willpower)
- Talents and Tags: tracked lists influencing gameplay
- Logs and end-state: events_log, is_dead, death_reason, is_ascended

```mermaid
classDiagram
class Attributes {
+int lifespan
+int constitution
+int comprehension
+int fortune
+int charisma
+int willpower
}
class GameState {
+string game_id
+int age
+int realm
+int cultivation
+Attributes attributes
+string[] talents
+string[] tags
+dict[] events_log
+bool is_dead
+string death_reason
+bool is_ascended
}
class NextYearResponse {
+int age
+int realm
+string realm_name
+int cultivation
+int cultivation_max
+dict[] events
+Attributes attributes
+bool is_dead
+string death_reason
+bool is_ascended
+bool has_choice
+dict choice_event
}
class LifeSummary {
+int total_age
+int max_realm
+string max_realm_name
+string death_reason
+string[] key_events
+string[] talents
+Attributes final_attributes
+int score
+string title
}
GameState --> Attributes : "has"
NextYearResponse --> Attributes : "has"
LifeSummary --> Attributes : "has"
```

**Diagram sources**
- [models.py:48-171](file://backend/app/models.py#L48-L171)

**Section sources**
- [models.py:48-171](file://backend/app/models.py#L48-L171)

### State Creation: create_game()
- Generates a short UUID-based game_id.
- Applies selected talents’ effects to attributes and accumulates tags.
- Initializes state with baseline values and stores it in GAME_STATES under game_id.
- Returns the new GameState.

```mermaid
flowchart TD
Start(["Call create_game"]) --> GenID["Generate short UUID"]
GenID --> ApplyTalents["Apply talent effects to attributes<br/>and collect tags"]
ApplyTalents --> BuildState["Construct GameState with defaults"]
BuildState --> Store["Store in GAME_STATES by game_id"]
Store --> Return(["Return GameState"])
```

**Diagram sources**
- [game_engine.py:48-77](file://backend/app/game_engine.py#L48-L77)
- [talents.py:3-48](file://backend/app/talents.py#L3-L48)

**Section sources**
- [game_engine.py:48-77](file://backend/app/game_engine.py#L48-L77)
- [talents.py:3-48](file://backend/app/talents.py#L3-L48)

### State Retrieval and Annual Progression: advance_year()
- Retrieves GameState by game_id from GAME_STATES.
- Enforces game-over constraints (dead or ascended).
- Increments age and checks for death.
- Gains cultivation (non-zero for realms beyond MORTAL).
- Selects weighted events based on state and fortune.
- Applies event effects to state.
- Checks for realm breakthrough and handles ascension.
- Returns a NextYearResponse containing the year’s changes and current state.

```mermaid
sequenceDiagram
participant API as "router.py"
participant GE as "game_engine.py"
participant ST as "GAME_STATES"
API->>GE : "advance_year(game_id)"
GE->>ST : "get GameState"
GE->>GE : "check_death()"
alt died
GE-->>API : "NextYearResponse(is_dead=true)"
else alive
GE->>GE : "process_cultivation_gain()"
GE->>GE : "select_events(count)"
GE->>GE : "apply_event_effects()"
GE->>GE : "check_realm_breakthrough()"
GE-->>API : "NextYearResponse"
end
```

**Diagram sources**
- [router.py:47-58](file://backend/app/router.py#L47-L58)
- [game_engine.py:311-393](file://backend/app/game_engine.py#L311-L393)

**Section sources**
- [router.py:47-58](file://backend/app/router.py#L47-L58)
- [game_engine.py:311-393](file://backend/app/game_engine.py#L311-L393)

### State Completion and Summary: get_life_summary()
- Retrieves GameState by game_id.
- Computes achievement title and score based on age, realm, and attributes.
- Builds a concise key-events summary from events_log.
- Returns a LifeSummary for rendering post-game screens.

```mermaid
flowchart TD
S(["Call get_life_summary"]) --> Fetch["Retrieve GameState"]
Fetch --> Title["Compute title and score"]
Title --> KeyEvents["Select key events from events_log"]
KeyEvents --> Build["Build LifeSummary"]
Build --> R(["Return LifeSummary"])
```

**Diagram sources**
- [game_engine.py:396-423](file://backend/app/game_engine.py#L396-L423)
- [endings.py:29-55](file://backend/app/endings.py#L29-L55)

**Section sources**
- [game_engine.py:396-423](file://backend/app/game_engine.py#L396-L423)
- [endings.py:29-55](file://backend/app/endings.py#L29-L55)

### State Validation and Constraints
- Attribute point cap enforced during game start.
- Talent selection limit enforced during game start.
- Game progression validates game existence and end-state before advancing.

```mermaid
flowchart TD
Start(["Start Game Request"]) --> Sum["Sum attributes <= 20?"]
Sum --> |No| Err(["HTTP 400: invalid attribute total"])
Sum --> |Yes| Count["Selected talents <= 3?"]
Count --> |No| Err
Count --> |Yes| Create["create_game()"]
Create --> OK(["Game ready"])
```

**Diagram sources**
- [router.py:21-31](file://backend/app/router.py#L21-L31)

**Section sources**
- [router.py:21-31](file://backend/app/router.py#L21-L31)

### Concurrent Session Handling
- GAME_STATES is a process-local dictionary. Concurrency within a single process is safe for reads/writes keyed by game_id, but there is no inter-process synchronization.
- No built-in cleanup or eviction policy exists; long-running processes accumulate state indefinitely.

Operational implications:
- For multi-instance deployments, separate processes will not share state.
- To support horizontal scaling, external persistence is required.

**Section sources**
- [game_engine.py:31-32](file://backend/app/game_engine.py#L31-L32)

### Persistence Strategies
- Current implementation: in-memory only.
- Recommended strategies for production:
  - File-based persistence: serialize GAME_STATES periodically to disk.
  - Database persistence: store GameState rows with TTL and periodic cleanup.
  - Hybrid: keep active sessions in memory with periodic snapshots to durable storage.
- Serialization/deserialization:
  - Pydantic models support automatic serialization to dictionaries and JSON.
  - Use model_dump() for JSON transport and model_validate() for reconstruction.

[No sources needed since this section provides general guidance]

### Memory Management Considerations
- Unbounded growth: GAME_STATES grows with active games; no eviction.
- Mitigation strategies:
  - Implement TTL-based cleanup routines.
  - Periodic snapshot and pruning of inactive sessions.
  - Monitor memory usage and scale vertically or horizontally accordingly.

[No sources needed since this section provides general guidance]

## Dependency Analysis
The backend modules depend on each other as follows:
- router.py depends on game_engine.py for business logic.
- game_engine.py depends on models.py for data structures, talents.py for talent definitions, endings.py for scoring/title computation, and all_events.json for event data.
- main.py wires the router into the FastAPI app.

```mermaid
graph LR
MD["models.py"] --> GE["game_engine.py"]
TL["talents.py"] --> GE
ED["endings.py"] --> GE
EV["events/all_events.json"] --> GE
GE --> R["router.py"]
R --> M["main.py"]
```

**Diagram sources**
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [main.py:1-26](file://backend/app/main.py#L1-L26)

**Section sources**
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [main.py:1-26](file://backend/app/main.py#L1-L26)

## Performance Considerations
- Event selection uses weighted random sampling; performance scales with eligible event count.
- Death and breakthrough checks are O(1) per year.
- In-memory lookups are O(1); however, unbounded growth of GAME_STATES can increase GC pressure.
- Recommendations:
  - Pre-filter events by category and conditions to reduce candidate sets.
  - Cache commonly accessed realm thresholds and max ages.
  - Consider pagination or streaming for very long event logs.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and remedies:
- Game not found:
  - Symptom: HTTP 404 when calling next-year or summary endpoints.
  - Cause: game_id missing or expired in GAME_STATES.
  - Action: Ensure the client passes the correct game_id returned by start.
- Game already ended:
  - Symptom: HTTP 404 when advancing year after death or ascension.
  - Cause: advance_year() rejects end-of-life states.
  - Action: Redirect to summary endpoint or prompt restart.
- Invalid attribute totals:
  - Symptom: HTTP 400 on start.
  - Cause: Total attributes exceed 20 or more than 3 talents selected.
  - Action: Adjust selections to meet constraints.
- Unexpected behavior:
  - Verify event weights and conditions in all_events.json.
  - Confirm talent effects in talents.py are applied during creation.

**Section sources**
- [router.py:21-31](file://backend/app/router.py#L21-L31)
- [router.py:54-58](file://backend/app/router.py#L54-L58)
- [game_engine.py:311-318](file://backend/app/game_engine.py#L311-L318)

## Conclusion
The game state management subsystem centers on a clean, in-memory GameState model and straightforward state transitions driven by events. UUID-based identifiers and Pydantic models enable robust serialization and API contracts. For production, the primary requirement is replacing in-memory storage with durable persistence and implementing cleanup policies to manage memory footprint and scalability.

## Appendices

### API Definitions
- POST /api/game/start
  - Request: StartGameRequest (attributes, talents)
  - Response: Game creation payload including game_id and initial state
- POST /api/game/next-year
  - Request: { game_id }
  - Response: NextYearResponse (yearly changes and current state)
- GET /api/game/summary/{game_id}
  - Response: LifeSummary (final outcome and statistics)

**Section sources**
- [router.py:18-68](file://backend/app/router.py#L18-L68)

### Frontend Integration Notes
- Types align with backend models for type safety.
- API utilities encapsulate network errors and return typed responses.
- GameScreen drives progression by invoking next-year repeatedly until end-state.

**Section sources**
- [types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)
- [api.ts:1-57](file://frontend/src/utils/api.ts#L1-L57)
- [GameScreen.tsx:1-87](file://frontend/src/pages/GameScreen.tsx#L1-L87)

### Dependencies
- FastAPI, Uvicorn, Pydantic, python-multipart are used by the backend.

**Section sources**
- [requirements.txt:1-5](file://backend/requirements.txt#L1-L5)