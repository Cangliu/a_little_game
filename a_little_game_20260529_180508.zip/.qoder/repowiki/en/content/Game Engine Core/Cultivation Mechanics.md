# Cultivation Mechanics

<cite>
**Referenced Files in This Document**
- [models.py](file://backend/app/models.py)
- [game_engine.py](file://backend/app/game_engine.py)
- [cultivation.json](file://backend/app/events/cultivation.json)
- [router.py](file://backend/app/router.py)
- [main.py](file://backend/app/main.py)
- [endings.py](file://backend/app/endings.py)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the cultivation mechanics subsystem of the life simulator. It covers the nine-tier progression system, realm thresholds, cultivation gain calculations, breakthrough probability algorithms, and the age-based mortality system. It also documents how events influence cultivation progress and how the system integrates with the broader game engine.

## Project Structure
The cultivation system spans several modules:
- Data models define realms, attributes, and game state.
- The game engine implements progression, breakthrough checks, mortality, and event selection.
- Events are loaded from JSON files and influence cultivation gains and attributes.
- The API exposes endpoints to start games, advance years, and retrieve summaries.

```mermaid
graph TB
A["main.py<br/>FastAPI app"] --> B["router.py<br/>API endpoints"]
B --> C["game_engine.py<br/>Core logic"]
C --> D["models.py<br/>Data models"]
C --> E["cultivation.json<br/>Events"]
C --> F["endings.py<br/>Titles & scoring"]
```

**Diagram sources**
- [main.py:1-26](file://backend/app/main.py#L1-L26)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [cultivation.json:1-800](file://backend/app/events/cultivation.json#L1-L800)
- [endings.py:1-55](file://backend/app/endings.py#L1-L55)

**Section sources**
- [main.py:1-26](file://backend/app/main.py#L1-L26)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [cultivation.json:1-800](file://backend/app/events/cultivation.json#L1-L800)
- [endings.py:1-55](file://backend/app/endings.py#L1-L55)

## Core Components
- Realm enumeration and names: Defines nine cultivation stages from mortal to ascension.
- Attributes model: Six core attributes (lifespan, constitution, comprehension, fortune, charisma, willpower).
- Game state: Tracks age, realm, cultivation progress, attributes, talents, tags, and outcomes.
- Real thresholds: Per-realm progression targets that define how much cultivation is needed to advance.
- Event system: Loads JSON-defined events that modify attributes, cultivation, tags, and trigger realm advances.

Key constants and structures:
- Realm enumeration and names: [models.py:7-32](file://backend/app/models.py#L7-L32)
- Realm max ages: [models.py:34-45](file://backend/app/models.py#L34-L45)
- Attributes model: [models.py:48-56](file://backend/app/models.py#L48-L56)
- Game state: [models.py:116-129](file://backend/app/models.py#L116-L129)
- Realm thresholds: [game_engine.py:34-45](file://backend/app/game_engine.py#L34-L45)
- Events loading: [game_engine.py:19-29](file://backend/app/game_engine.py#L19-L29)

**Section sources**
- [models.py:7-32](file://backend/app/models.py#L7-L32)
- [models.py:34-45](file://backend/app/models.py#L34-L45)
- [models.py:48-56](file://backend/app/models.py#L48-L56)
- [models.py:116-129](file://backend/app/models.py#L116-L129)
- [game_engine.py:34-45](file://backend/app/game_engine.py#L34-L45)
- [game_engine.py:19-29](file://backend/app/game_engine.py#L19-L29)

## Architecture Overview
The cultivation lifecycle is orchestrated by the game engine:
- Start game initializes attributes and applies talent effects.
- Each year:
  - Death check evaluates age vs. max age and applies random death chance influenced by fortune.
  - Base cultivation gain is computed from comprehension and constitution with realm modifier.
  - Events are selected and applied, affecting attributes and cultivation.
  - Breakthrough check compares current cultivation against the realm threshold and applies a probability based on comprehension and fortune.
- End-of-life summary computes title and score.

```mermaid
sequenceDiagram
participant Client as "Client"
participant API as "router.py"
participant Engine as "game_engine.py"
participant Model as "models.py"
participant Events as "cultivation.json"
Client->>API : POST /api/game/start
API->>Engine : create_game(attributes, talents)
Engine->>Model : GameState(...)
Engine-->>API : game_id, initial state
API-->>Client : initial state
loop Yearly progression
Client->>API : POST /api/game/next-year
API->>Engine : advance_year(game_id)
Engine->>Engine : check_death()
Engine->>Engine : process_cultivation_gain()
Engine->>Engine : select_events()
Engine->>Events : load events
Engine->>Engine : apply_event_effects()
Engine->>Engine : check_realm_breakthrough()
Engine-->>API : NextYearResponse
API-->>Client : yearly result
end
```

**Diagram sources**
- [router.py:18-44](file://backend/app/router.py#L18-L44)
- [router.py:47-58](file://backend/app/router.py#L47-L58)
- [game_engine.py:48-77](file://backend/app/game_engine.py#L48-L77)
- [game_engine.py:311-393](file://backend/app/game_engine.py#L311-L393)
- [cultivation.json:1-800](file://backend/app/events/cultivation.json#L1-L800)

## Detailed Component Analysis

### Nine-Tier Progression System and Realm Thresholds
- Realms: MORTAL, QI_REFINING, FOUNDATION, GOLDEN_CORE, NASCENT_SOUL, DEITY, INTEGRATION, MAHAYANA, TRIBULATION, ASCENSION.
- Thresholds: Each realm defines a target cultivation value required to advance. Mortal does not gain cultivation; others gain progressively faster with higher tiers.
- Max age per realm: Each realm has a base maximum age; higher realms scale with lifespan bonus differently.

Key references:
- Realm enum and names: [models.py:7-32](file://backend/app/models.py#L7-L32)
- Realm max ages: [models.py:34-45](file://backend/app/models.py#L34-L45)
- Realm thresholds: [game_engine.py:34-45](file://backend/app/game_engine.py#L34-L45)
- Max age calculation: [game_engine.py:155-164](file://backend/app/game_engine.py#L155-L164)

**Section sources**
- [models.py:7-32](file://backend/app/models.py#L7-L32)
- [models.py:34-45](file://backend/app/models.py#L34-L45)
- [game_engine.py:34-45](file://backend/app/game_engine.py#L34-L45)
- [game_engine.py:155-164](file://backend/app/game_engine.py#L155-L164)

### Cultivation Gain Formula
- Base gain: depends on comprehension and constitution, plus a small constant.
- Realm modifier: increases gain rate with higher realms.
- Mortal stage: zero gain until entering the first real realm.

Formulas and implementation:
- Base gain: [game_engine.py:298-308](file://backend/app/game_engine.py#L298-L308)
- Realm modifier: [game_engine.py:306](file://backend/app/game_engine.py#L306)
- Mortal restriction: [game_engine.py:300-301](file://backend/app/game_engine.py#L300-L301)

Breakdown:
- Base contribution from comprehension and constitution.
- Multiplicative modifier proportional to realm tier.
- Ensures meaningful progression acceleration as realms advance.

**Section sources**
- [game_engine.py:298-308](file://backend/app/game_engine.py#L298-L308)

### Breakthrough Probability Algorithm
- Threshold comparison: advancement requires reaching the realm’s threshold.
- Chance calculation: base chance plus bonuses from comprehension and fortune, capped at a maximum.
- Randomized success: if random draw succeeds, realm advances and cultivation resets.

Algorithm steps:
1. Retrieve threshold for current realm.
2. Compare current cultivation to threshold.
3. Compute chance = min(base + comp_bonus + fort_bonus, max_cap).
4. If successful, increment realm, reset cultivation, and optionally trigger ascension event.

References:
- Threshold retrieval: [game_engine.py:171](file://backend/app/game_engine.py#L171)
- Chance computation: [game_engine.py:174-178](file://backend/app/game_engine.py#L174-L178)
- Success handling: [game_engine.py:180-202](file://backend/app/game_engine.py#L180-L202)

```mermaid
flowchart TD
Start(["Start Breakthrough Check"]) --> Threshold["Get Realm Threshold"]
Threshold --> Compare{"Cultivation >= Threshold?"}
Compare --> |No| End(["No Advance"])
Compare --> |Yes| CalcChance["Compute Chance = min(0.3 + comp*0.05 + fort*0.03, 0.85)"]
CalcChance --> Roll{"Random < Chance?"}
Roll --> |No| End
Roll --> |Yes| Advance["Increment Realm<br/>Reset Cultivation"]
Advance --> Ascend{"Realm == 9?"}
Ascend --> |Yes| AscEvent["Trigger Ascension Event"]
Ascend --> |No| NormalEvent["Trigger Breakthrough Event"]
AscEvent --> End
NormalEvent --> End
```

**Diagram sources**
- [game_engine.py:166-204](file://backend/app/game_engine.py#L166-L204)

**Section sources**
- [game_engine.py:166-204](file://backend/app/game_engine.py#L166-L204)

### Age-Based Mortality System
- Max age calculation:
  - For mortal realm: base max age plus lifespan bonus.
  - For higher realms: base max age scaled by lifespan modifier.
- Random death chance:
  - Increases with age ratio approaching max age.
  - Different formulas for mortal vs. non-mortal stages.
  - Fortune attribute reduces death chance with a multiplicative cap.
- Guaranteed death upon exceeding max age.

References:
- Max age function: [game_engine.py:155-164](file://backend/app/game_engine.py#L155-L164)
- Death chance formulas: [game_engine.py:231-241](file://backend/app/game_engine.py#L231-L241)
- Fortune impact: [game_engine.py:240-241](file://backend/app/game_engine.py#L240-L241)
- Guaranteed death: [game_engine.py:211-212](file://backend/app/game_engine.py#L211-L212)

```mermaid
flowchart TD
Start(["Start Death Check"]) --> MaxAge["Compute Max Age"]
MaxAge --> Exceeded{"Age >= Max Age?"}
Exceeded --> |Yes| DeathEvent["Select Random Death Event"]
DeathEvent --> SetDead["Mark Dead<br/>Set Reason"]
SetDead --> End(["End"])
Exceeded --> |No| AgeRatio["Compute Age Ratio"]
AgeRatio --> ChanceCalc["Compute Death Chance Based on Age Ratio"]
ChanceCalc --> FortuneMod["Apply Fortune Modifier"]
FortuneMod --> Roll{"Random < Chance?"}
Roll --> |No| End
Roll --> |Yes| DeathEvent
```

**Diagram sources**
- [game_engine.py:207-253](file://backend/app/game_engine.py#L207-L253)

**Section sources**
- [game_engine.py:155-164](file://backend/app/game_engine.py#L155-L164)
- [game_engine.py:207-253](file://backend/app/game_engine.py#L207-L253)

### Event Influence on Cultivation
- Events are loaded from JSON and filtered by conditions (age, realm, attributes, talents, tags).
- Event weights are adjusted by fortune (fortune-type events become more likely; danger-type events become less likely).
- Effects can increase or decrease cultivation, modify attributes, add/remove tags, or trigger realm advances.

References:
- Event loading: [game_engine.py:19-29](file://backend/app/game_engine.py#L19-L29)
- Conditions check: [game_engine.py:80-116](file://backend/app/game_engine.py#L80-L116)
- Weighted selection: [game_engine.py:256-295](file://backend/app/game_engine.py#L256-L295)
- Effect application: [game_engine.py:119-153](file://backend/app/game_engine.py#L119-L153)
- Example events: [cultivation.json:1-800](file://backend/app/events/cultivation.json#L1-L800)

**Section sources**
- [game_engine.py:19-29](file://backend/app/game_engine.py#L19-L29)
- [game_engine.py:80-116](file://backend/app/game_engine.py#L80-L116)
- [game_engine.py:256-295](file://backend/app/game_engine.py#L256-L295)
- [game_engine.py:119-153](file://backend/app/game_engine.py#L119-L153)
- [cultivation.json:1-800](file://backend/app/events/cultivation.json#L1-L800)

### API Integration
- Start game endpoint validates attribute totals and talent counts, creates a game state, and returns initial values.
- Next year endpoint advances the simulation and returns yearly results including events and state updates.
- Summary endpoint computes final title and score.

References:
- Start endpoint: [router.py:18-44](file://backend/app/router.py#L18-L44)
- Next year endpoint: [router.py:47-58](file://backend/app/router.py#L47-L58)
- Summary endpoint: [router.py:61-69](file://backend/app/router.py#L61-L69)

**Section sources**
- [router.py:18-44](file://backend/app/router.py#L18-L44)
- [router.py:47-58](file://backend/app/router.py#L47-L58)
- [router.py:61-69](file://backend/app/router.py#L61-L69)

## Dependency Analysis
- game_engine.py depends on models.py for Realm, REALM_NAMES, REALM_MAX_AGE, and GameState.
- game_engine.py loads events from cultivation.json at runtime.
- router.py depends on game_engine.py for game logic and on models.py for type definitions.
- main.py wires router into the FastAPI app.

```mermaid
graph LR
Models["models.py"] --> Engine["game_engine.py"]
Events["cultivation.json"] --> Engine
Engine --> Router["router.py"]
Router --> Main["main.py"]
```

**Diagram sources**
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [cultivation.json:1-800](file://backend/app/events/cultivation.json#L1-L800)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [main.py:1-26](file://backend/app/main.py#L1-L26)

**Section sources**
- [models.py:1-171](file://backend/app/models.py#L1-L171)
- [game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [cultivation.json:1-800](file://backend/app/events/cultivation.json#L1-L800)
- [router.py:1-69](file://backend/app/router.py#L1-L69)
- [main.py:1-26](file://backend/app/main.py#L1-L26)

## Performance Considerations
- Event selection uses weighted sampling; ensure the number of eligible events remains reasonable to keep selection efficient.
- Realm thresholds grow exponentially; consider caching or precomputing thresholds if scaling to very high realms.
- Death chance computation is O(1); negligible overhead.
- Attribute and talent effects are applied via reflection; keep the number of effects bounded.

## Troubleshooting Guide
Common issues and resolutions:
- Game not found or already ended: The next-year endpoint raises errors if the game ID is invalid or if the game is already over. Ensure the game_id is valid and the game is still active.
  - Reference: [router.py:54-58](file://backend/app/router.py#L54-L58)
- Attribute totals exceeded: The start endpoint enforces a maximum total attribute cost. Adjust attribute distribution accordingly.
  - Reference: [router.py:22-27](file://backend/app/router.py#L22-L27)
- Talent selection limit: The start endpoint limits talents to three. Choose wisely among available options.
  - Reference: [router.py:29-30](file://backend/app/router.py#L29-L30)
- No events available: If no events meet conditions, the engine returns a neutral “nothing” event. Review conditions and attributes.
  - Reference: [game_engine.py:256-269](file://backend/app/game_engine.py#L256-L269)

**Section sources**
- [router.py:22-30](file://backend/app/router.py#L22-L30)
- [router.py:54-58](file://backend/app/router.py#L54-L58)
- [game_engine.py:256-269](file://backend/app/game_engine.py#L256-L269)

## Conclusion
The cultivation mechanics subsystem combines deterministic thresholds with probabilistic breakthroughs and stochastic mortality. Players balance attributes—especially comprehension and fortune—to accelerate progress and reduce risks. Events add variability and emergent storytelling, while the API provides a clean interface for gameplay orchestration.

## Appendices

### Example Scenarios

- Scenario A: Early breakthrough with high comprehension and moderate fortune
  - Build: comprehension high, fortune moderate, constitution balanced.
  - Outcome: higher breakthrough chance due to comprehension bonus; faster realm advancement.
  - References: [game_engine.py:174-178](file://backend/app/game_engine.py#L174-L178), [game_engine.py:180-202](file://backend/app/game_engine.py#L180-L202)

- Scenario B: Longevity-focused build with high constitution and lifespan
  - Build: constitution and lifespan high; comprehension moderate.
  - Outcome: slower breakthrough but longer lifespan; more time to accumulate cultivation.
  - References: [game_engine.py:155-164](file://backend/app/game_engine.py#L155-L164), [game_engine.py:298-308](file://backend/app/game_engine.py#L298-L308)

- Scenario C: Luck-driven build with high fortune
  - Build: fortune high; comprehension moderate.
  - Outcome: reduced death chance and increased event fortune weighting; more favorable random outcomes.
  - References: [game_engine.py:240-241](file://backend/app/game_engine.py#L240-L241), [game_engine.py:270-279](file://backend/app/game_engine.py#L270-L279)

- Scenario D: Mortality risk near max age
  - Build: low fortune; advanced realm.
  - Outcome: higher death chance due to age ratio and lower fortune modifier.
  - References: [game_engine.py:231-241](file://backend/app/game_engine.py#L231-L241), [game_engine.py:240-241](file://backend/app/game_engine.py#L240-L241)

### Probability Curves and Calculations

- Breakthrough success probability
  - Chance = min(0.3 + comp_bonus + fort_bonus, 0.85)
  - comp_bonus = comprehension × 0.05
  - fort_bonus = fortune × 0.03
  - References: [game_engine.py:174-178](file://backend/app/game_engine.py#L174-L178)

- Death chance by age ratio
  - For mortals past 30: death_chance ∝ 0.001 × (age/max_age)^2 × 10
  - For non-mortals: death_chance ∝ 0.0005 × (age/max_age)^3 × 5
  - Fortune modifier: multiply by max(0.1, 1 - fortune × 0.03)
  - References: [game_engine.py:231-241](file://backend/app/game_engine.py#L231-L241), [game_engine.py:240-241](file://backend/app/game_engine.py#L240-L241)

- Cultivation gain per year
  - Base = 5 + comprehension × 2 + constitution
  - Realm modifier = 1 + realm × 0.3
  - Reference: [game_engine.py:298-308](file://backend/app/game_engine.py#L298-L308)