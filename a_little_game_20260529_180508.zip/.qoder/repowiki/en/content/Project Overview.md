# Project Overview

<cite>
**Referenced Files in This Document**
- [backend/app/main.py](file://backend/app/main.py)
- [backend/app/router.py](file://backend/app/router.py)
- [backend/app/models.py](file://backend/app/models.py)
- [backend/app/game_engine.py](file://backend/app/game_engine.py)
- [backend/app/talents.py](file://backend/app/talents.py)
- [backend/app/endings.py](file://backend/app/endings.py)
- [backend/app/events/all_events.json](file://backend/app/events/all_events.json)
- [docker-compose.yml](file://docker-compose.yml)
- [Dockerfile.backend](file://Dockerfile.backend)
- [Dockerfile.frontend](file://Dockerfile.frontend)
- [frontend/src/App.tsx](file://frontend/src/App.tsx)
- [frontend/src/pages/StartScreen.tsx](file://frontend/src/pages/StartScreen.tsx)
- [frontend/src/pages/CharacterCreation.tsx](file://frontend/src/pages/CharacterCreation.tsx)
- [frontend/src/pages/GameScreen.tsx](file://frontend/src/pages/GameScreen.tsx)
- [frontend/src/utils/types.ts](file://frontend/src/utils/types.ts)
- [frontend/src/utils/api.ts](file://frontend/src/utils/api.ts)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction
A Little Game is a cultivation-themed life simulator that invites players to experience a complete life journey through nine cultivation realms, from mortal existence to ascension. The game blends deterministic progression with emergent storytelling via a dynamic event-driven system. Players allocate six-dimensional attributes, choose powerful talents, and navigate yearly choices that shape their path to becoming a true immortal.

At its heart, the game offers:
- Mortal-to-ascension progression across nine cultivation realms
- A six-dimensional attribute system governing longevity, constitution, comprehension, fortune, charisma, and willpower
- A talent system that grants persistent bonuses and tags affecting event eligibility
- Dynamic event-driven gameplay with weighted selection influenced by attributes and realm
- Real-time cultivation breakthrough mechanics with probabilistic checks
- Multi-service deployment using Docker for scalable development and production

This overview targets both newcomers and experienced developers, introducing core concepts like cultivation realms, breakthrough mechanics, and the talent system, while also covering the full-stack architecture and operational model.

## Project Structure
The project is organized into a backend service (FastAPI) and a frontend (React + TypeScript), orchestrated by Docker Compose. The backend encapsulates game logic, data models, and APIs. The frontend renders the user experience and communicates with the backend via typed requests and responses.

```mermaid
graph TB
subgraph "Frontend (React)"
FE_App["App.tsx"]
FE_Start["StartScreen.tsx"]
FE_Create["CharacterCreation.tsx"]
FE_Game["GameScreen.tsx"]
FE_Types["types.ts"]
FE_API["api.ts"]
end
subgraph "Backend (FastAPI)"
BE_Main["main.py"]
BE_Router["router.py"]
BE_Models["models.py"]
BE_Engine["game_engine.py"]
BE_Talents["talents.py"]
BE_Endings["endings.py"]
BE_Events["events/all_events.json"]
end
subgraph "Deployment (Docker)"
DC["docker-compose.yml"]
DF_B["Dockerfile.backend"]
DF_F["Dockerfile.frontend"]
end
FE_App --> FE_Start
FE_App --> FE_Create
FE_App --> FE_Game
FE_Game --> FE_API
FE_Create --> FE_API
FE_Start --> FE_Create
FE_API --> BE_Router
BE_Router --> BE_Engine
BE_Engine --> BE_Models
BE_Engine --> BE_Talents
BE_Engine --> BE_Endings
BE_Engine --> BE_Events
DC --> DF_B
DC --> DF_F
```

**Diagram sources**
- [frontend/src/App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)
- [frontend/src/pages/StartScreen.tsx:1-193](file://frontend/src/pages/StartScreen.tsx#L1-L193)
- [frontend/src/pages/CharacterCreation.tsx:1-249](file://frontend/src/pages/CharacterCreation.tsx#L1-L249)
- [frontend/src/pages/GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [frontend/src/utils/types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)
- [backend/app/main.py:1-26](file://backend/app/main.py#L1-L26)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/models.py:1-171](file://backend/app/models.py#L1-L171)
- [backend/app/game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [backend/app/talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [backend/app/endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [backend/app/events/all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)
- [Dockerfile.backend:1-8](file://Dockerfile.backend#L1-L8)
- [Dockerfile.frontend:1-13](file://Dockerfile.frontend#L1-L13)

**Section sources**
- [backend/app/main.py:1-26](file://backend/app/main.py#L1-L26)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/models.py:1-171](file://backend/app/models.py#L1-L171)
- [backend/app/game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [backend/app/talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [backend/app/endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [backend/app/events/all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)
- [docker-compose.yml:1-21](file://docker-compose.yml#L1-L21)
- [Dockerfile.backend:1-8](file://Dockerfile.backend#L1-L8)
- [Dockerfile.frontend:1-13](file://Dockerfile.frontend#L1-L13)
- [frontend/src/App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)
- [frontend/src/pages/StartScreen.tsx:1-193](file://frontend/src/pages/StartScreen.tsx#L1-L193)
- [frontend/src/pages/CharacterCreation.tsx:1-249](file://frontend/src/pages/CharacterCreation.tsx#L1-L249)
- [frontend/src/pages/GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [frontend/src/utils/types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)

## Core Components
This section introduces the game’s fundamental systems and how they work together.

- Cultivation Realms
  - Nine realms define the player’s journey: from mortal to ascension. Each realm has a maximum age cap and thresholds for cultivation breakthrough. The engine computes max age and breakthrough probability based on attributes and realm.

- Six-Dimensional Attribute System
  - The attributes influence longevity, physical strength, learning speed, luck, social grace, and resistance to tribulations. They directly impact growth, survival, and event weighting.

- Talent System
  - Talents grant permanent attribute bonuses and tags. They affect event eligibility and can alter the story. Talents are drawn from a weighted pool and limited to three selections during character creation.

- Dynamic Event-Driven Gameplay
  - Events are loaded from JSON and filtered by conditions (age, realm, cultivation, required/excluded talents/tags, minimum attribute values). Events are selected with weights influenced by attributes and event types.

- Breakthrough Mechanics
  - Cultivation increases yearly for non-mortal realms. When thresholds are reached, a probabilistic breakthrough check occurs, influenced by comprehension and fortune. Ascension is the terminal state.

- Endings and Titles
  - Titles and scores are derived from achieved realm and age, with bonuses from attributes and longevity. Death reasons and key events summarize the life.

Practical examples:
- A player with high fortune and comprehension has a higher chance to breakthrough and lower death risk as they age.
- Choosing a “heavenly root” talent increases both constitution and comprehension, accelerating early progress and enabling faster breakthroughs.
- An event pool weighted by fortune might present more fortune-type events, while danger-type events are downweighted by fortune.

**Section sources**
- [backend/app/models.py:7-45](file://backend/app/models.py#L7-L45)
- [backend/app/models.py:48-94](file://backend/app/models.py#L48-L94)
- [backend/app/models.py:116-150](file://backend/app/models.py#L116-L150)
- [backend/app/talents.py:3-48](file://backend/app/talents.py#L3-L48)
- [backend/app/game_engine.py:34-45](file://backend/app/game_engine.py#L34-L45)
- [backend/app/game_engine.py:166-204](file://backend/app/game_engine.py#L166-L204)
- [backend/app/game_engine.py:256-295](file://backend/app/game_engine.py#L256-L295)
- [backend/app/endings.py:29-54](file://backend/app/endings.py#L29-L54)

## Architecture Overview
The system follows a clean separation of concerns:
- Backend: FastAPI REST API exposing game lifecycle endpoints, managing state, and orchestrating events and breakthroughs.
- Frontend: React SPA handling UI phases (start, creation, playing, summary), typed communication with the backend, and rendering of stats, events, and progress.
- Deployment: Docker Compose builds and runs the backend and frontend independently, with the frontend serving static assets via Nginx.

```mermaid
graph TB
Client["Browser"]
FE["Frontend (React)"]
API["FastAPI Backend"]
Engine["Game Engine (game_engine.py)"]
Models["Models (models.py)"]
Talents["Talents (talents.py)"]
Endings["Endings (endings.py)"]
Events["Events (events/all_events.json)"]
DB["In-memory State Store"]
Client --> FE
FE --> API
API --> Engine
Engine --> Models
Engine --> Talents
Engine --> Endings
Engine --> Events
Engine --> DB
```

**Diagram sources**
- [frontend/src/App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)
- [frontend/src/pages/GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [backend/app/models.py:1-171](file://backend/app/models.py#L1-L171)
- [backend/app/talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [backend/app/endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [backend/app/events/all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)

**Section sources**
- [backend/app/main.py:1-26](file://backend/app/main.py#L1-L26)
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [frontend/src/utils/types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)
- [frontend/src/utils/api.ts](file://frontend/src/utils/api.ts)

## Detailed Component Analysis

### Backend API and Game Engine
The backend exposes endpoints for starting a game, advancing one year, and retrieving a life summary. The game engine encapsulates all logic: state management, event filtering, effect application, breakthrough checks, death checks, and progress computation.

```mermaid
sequenceDiagram
participant FE as "Frontend"
participant API as "FastAPI Router"
participant GE as "Game Engine"
participant MOD as "Models"
participant TAL as "Talents"
participant END as "Endings"
participant EVT as "Events"
FE->>API : POST /api/game/start
API->>GE : create_game(attributes, talents)
GE->>TAL : apply talent effects
GE->>MOD : initialize GameState
GE-->>API : GameState
API-->>FE : game_id, attributes, talents
loop Yearly progression
FE->>API : POST /api/game/next-year
API->>GE : advance_year(game_id)
GE->>GE : check_death()
GE->>EVT : select_events()
GE->>GE : apply_event_effects()
GE->>GE : check_realm_breakthrough()
GE->>END : compute title/score (on end)
GE-->>API : NextYearResponse
API-->>FE : events, attributes, realm, age
end
```

**Diagram sources**
- [backend/app/router.py:18-68](file://backend/app/router.py#L18-L68)
- [backend/app/game_engine.py:48-393](file://backend/app/game_engine.py#L48-L393)
- [backend/app/models.py:116-150](file://backend/app/models.py#L116-L150)
- [backend/app/talents.py:51-84](file://backend/app/talents.py#L51-L84)
- [backend/app/endings.py:29-54](file://backend/app/endings.py#L29-L54)
- [backend/app/events/all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)

**Section sources**
- [backend/app/router.py:1-69](file://backend/app/router.py#L1-L69)
- [backend/app/game_engine.py:1-424](file://backend/app/game_engine.py#L1-L424)
- [backend/app/models.py:1-171](file://backend/app/models.py#L1-L171)
- [backend/app/talents.py:1-85](file://backend/app/talents.py#L1-L85)
- [backend/app/endings.py:1-55](file://backend/app/endings.py#L1-L55)
- [backend/app/events/all_events.json:1-200](file://backend/app/events/all_events.json#L1-L200)

### Data Models and Types
The backend defines strong Pydantic models for game state, attributes, events, and responses. The frontend mirrors these types for safe communication and rendering.

```mermaid
classDiagram
class Attributes {
+int lifespan
+int constitution
+int comprehension
+int fortune
+int charisma
+int willpower
}
class EventCondition {
+int min_age
+int max_age
+int min_realm
+int max_realm
+int min_cultivation
+str[] required_talents
+str[] required_tags
+str[] excluded_tags
+dict min_attribute
}
class EventEffect {
+int cultivation
+int lifespan
+int constitution
+int comprehension
+int fortune
+int charisma
+int willpower
+bool realm_up
+string add_tag
+string remove_tag
+bool death
}
class GameEvent {
+string id
+string text
+string category
+EventCondition conditions
+int weight
+EventEffect effects
+EventBranch[] branches
+str[] tags
+string event_type
}
class GameState {
+string game_id
+int age
+int realm
+int cultivation
+Attributes attributes
+str[] talents
+str[] tags
+list events_log
+bool is_dead
+string death_reason
+bool is_ascended
}
class NextYearResponse {
+int age
+int realm
+string realm_name
+int cultivation
+int cultivation_max
+list events
+Attributes attributes
+bool is_dead
+string death_reason
+bool is_ascended
+bool has_choice
+dict choice_event
}
class LifeSummary {
+int total_age
+int max_realm
+string max_realm_name
+string death_reason
+list key_events
+list talents
+Attributes final_attributes
+int score
+string title
}
GameState --> Attributes : "has"
GameEvent --> EventCondition : "uses"
GameEvent --> EventEffect : "uses"
NextYearResponse --> Attributes : "includes"
LifeSummary --> Attributes : "final_attributes"
```

**Diagram sources**
- [backend/app/models.py:48-171](file://backend/app/models.py#L48-L171)

**Section sources**
- [backend/app/models.py:1-171](file://backend/app/models.py#L1-L171)
- [frontend/src/utils/types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)

### Frontend Lifecycle and UI
The frontend manages four phases: start screen, character creation, gameplay, and summary. It fetches talent pools, starts games, advances years, and displays events and stats.

```mermaid
flowchart TD
Start(["Start Screen"]) --> Creation["Character Creation"]
Creation --> Playing["Game Screen"]
Playing --> Summary["Summary Screen"]
Summary --> Start
Creation --> |Fetch talents| API["API"]
Creation --> |Start game| API
Playing --> |Next year| API
API --> |Responses| Playing
```

**Diagram sources**
- [frontend/src/App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)
- [frontend/src/pages/StartScreen.tsx:1-193](file://frontend/src/pages/StartScreen.tsx#L1-L193)
- [frontend/src/pages/CharacterCreation.tsx:1-249](file://frontend/src/pages/CharacterCreation.tsx#L1-L249)
- [frontend/src/pages/GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [frontend/src/utils/api.ts](file://frontend/src/utils/api.ts)

**Section sources**
- [frontend/src/App.tsx:1-72](file://frontend/src/App.tsx#L1-L72)
- [frontend/src/pages/StartScreen.tsx:1-193](file://frontend/src/pages/StartScreen.tsx#L1-L193)
- [frontend/src/pages/CharacterCreation.tsx:1-249](file://frontend/src/pages/CharacterCreation.tsx#L1-L249)
- [frontend/src/pages/GameScreen.tsx:1-261](file://frontend/src/pages/GameScreen.tsx#L1-L261)
- [frontend/src/utils/types.ts:1-113](file://frontend/src/utils/types.ts#L1-L113)

## Dependency Analysis
The backend depends on FastAPI, Pydantic, and Python’s standard libraries. The frontend depends on React, TypeScript, and a small API client. Docker Compose coordinates building and running both services.

```mermaid
graph TB
subgraph "Backend Dependencies"
F["FastAPI"]
U["Uvicorn"]
P["Pydantic"]
M["python-multipart"]
end
subgraph "Frontend Dependencies"
R["React"]
TS["TypeScript"]
AX["Axios/Fetch"]
end
subgraph "Runtime"
PY["Python 3.11"]
NO["Node 20"]
NG["Nginx"]
end
F --> PY
U --> PY
P --> PY
M --> PY
R --> NO
TS --> NO
AX --> NO
NG --> NO
```

**Diagram sources**
- [backend/requirements.txt:1-5](file://backend/requirements.txt#L1-L5)
- [Dockerfile.backend:1-8](file://Dockerfile.backend#L1-L8)
- [Dockerfile.frontend:1-13](file://Dockerfile.frontend#L1-L13)

**Section sources**
- [backend/requirements.txt:1-5](file://backend/requirements.txt#L1-L5)
- [Dockerfile.backend:1-8](file://Dockerfile.backend#L1-L8)
- [Dockerfile.frontend:1-13](file://Dockerfile.frontend#L1-L13)

## Performance Considerations
- Event Selection Weighting
  - The engine weights events by attribute modifiers and event types, reducing unnecessary computation for low-probability outcomes. Consider caching frequently accessed subsets of events if memory becomes constrained.

- Breakthrough Probability
  - Probabilistic checks are lightweight but occur yearly. Keep random generation efficient and avoid recalculating constants repeatedly.

- State Storage
  - Current in-memory storage simplifies deployment but limits horizontal scaling. For production, consider a persistent store with session eviction policies.

- Frontend Rendering
  - Large event logs can cause layout thrashing. Virtualization or pagination of the event log improves responsiveness.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and remedies:
- Game Not Found
  - Symptom: “Game not found” errors when advancing years.
  - Cause: Invalid or missing game_id.
  - Fix: Ensure the game was started successfully and the client passes the returned game_id.

- Attribute Validation
  - Symptom: “Attribute point total cannot exceed 20” errors.
  - Cause: Exceeded point cap during character creation.
  - Fix: Limit total points to the allowed cap and ensure at most three talents are selected.

- Unexpected Early Death
  - Symptom: Premature death despite high fortune.
  - Cause: Age exceeding maximum allowed by realm and attributes.
  - Fix: Review max age calculation and attribute effects; note that mortal characters face higher risks after a threshold age.

- Ascension Path
  - Symptom: No breakthrough events after reaching thresholds.
  - Cause: Breakthrough chance below random threshold.
  - Fix: Increase comprehension or fortune to improve chance; remember ascension caps the event pool.

**Section sources**
- [backend/app/router.py:21-31](file://backend/app/router.py#L21-L31)
- [backend/app/game_engine.py:311-393](file://backend/app/game_engine.py#L311-L393)
- [backend/app/game_engine.py:207-253](file://backend/app/game_engine.py#L207-L253)
- [backend/app/game_engine.py:166-204](file://backend/app/game_engine.py#L166-L204)

## Conclusion
A Little Game delivers a rich, replayable cultivation experience by blending deterministic progression with emergent storytelling. The backend’s modular design and the frontend’s clean UI enable rapid iteration and a polished user experience. With Docker-based deployment, the project is ready for local development and production scaling. By understanding the cultivation realms, breakthrough mechanics, and talent system, both new players and developers can appreciate the depth and potential of this life simulator.